# BusTrack Pro

Production-oriented GPS school-bus tracking and parent-notification platform.

A rebuild of the final-year prototype that closes the gaps that made the original
demo-only: full admin CRUD, database-persisted (restart-safe) trip state, schema
migrations, hardened auth, multi-channel notifications (in-app, email, web-push,
SMS), pickup **and** drop-off geofences, route-deviation detection, offline GPS
buffering on the driver device, multi-school tenancy, automated tests and CI, and
a Dockerised deployment.

---

## October 2026 upgrade

- Driver-initiated, parent-authorised delegated handover. A driver requests a
  child-specific code on an active afternoon trip; the parent names the receiving
  adult and shares the code privately. The driver confirms the adult present and
  verifies the code. Codes expire, are single-use and lock after five wrong guesses.
- Responsive parent, driver and school workspaces with clearer navigation,
  receiver-authorisation screens, handover records, and parent trip history.
- School and bus-access checks, afternoon departure alerts, emergency delivery
  preference overrides, and improved GPS buffering and trip-end handling.
- Eight numbered design diagrams, four interface illustrations and explicit
  figure references in [the design addendum](docs/DESIGN_ADDENDUM.md).

See [VALIDATION.md](docs/VALIDATION.md) for checks and remaining deployment work.
The original research documents have not been modified.

---

## Stack

| | |
|---|---|
| **API** | Node 20 · TypeScript · Express · Socket.IO · PostgreSQL (Knex migrations) · Zod · pino |
| **Web** | React 18 · Vite · TypeScript · TanStack Query · React Router · Tailwind · Leaflet · vite-plugin-pwa |
| **Auth** | JWT access + rotating refresh tokens · bcrypt · rate-limiting · account lockout |
| **Notifications** | Socket.IO (in-app) · Nodemailer (email) · Web Push / VAPID · pluggable SMS (`log` / Termii) |
| **Infra** | Docker Compose (Postgres + Redis + API + Nginx) · GitHub Actions CI |

---

## Quick start (local, no Docker)

Prerequisites: Node 20+, PostgreSQL 13+ (11 works too), npm 9+.

```bash
cd bustrack-pro
./db-setup.sh 'YOUR_POSTGRES_PASSWORD'   # creates DBs, .env, migrates, seeds
npm run dev                              # API :4000 + web :5173
```

Open **http://127.0.0.1:5173** and use a demo account:

| Role | Email | Password |
|---|---|---|
| Admin | `admin@graceland.edu.ng` | `admin12345` |
| Dispatcher | `dispatch@graceland.edu.ng` | `dispatch12345` |
| Driver | `driver1@graceland.edu.ng` | `driver12345` |
| Parent | `parent1@example.com` | `parent12345` |
| Super-admin | `owner@bustrack.local` | `owner12345` |

To see live tracking: sign in as the **driver**, toggle **Simulated location**, press
**START TRIP** — then open the **parent** view in another browser/profile.

## Quick start (Docker)

```bash
cp .env.example .env         # edit secrets
docker compose up -d --build
# web  → http://localhost:8080
# api  → http://localhost:4000
docker compose exec api node dist/db/seed.js   # optional demo data
```

---

## Scripts

| Command | Description |
|---|---|
| `npm run dev` | API + web with hot reload |
| `npm run build` | Build both apps |
| `npm run typecheck` / `npm run lint` | Static checks (tsc + Biome) |
| `npm test` | API test suite (Vitest + Supertest, needs the test DB) |
| `npm run test:embedded -w apps/api` | Same tests using an isolated, test-only embedded PostgreSQL adapter |
| `npm run db:migrate` / `db:rollback` / `db:seed` / `db:reset` | Database lifecycle |

---

## Feature map

### Admin / dispatcher console
- Dashboard: fleet KPIs, live fleet map, active-trip list (real-time)
- CRUD for buses, routes (map editor + stops), students (+ guardian links), drivers,
  parents, staff — all school-scoped
- Trips: live map for running trips, animated GPS replay for completed ones, event
  timeline, cancel
- Reports: completed-trip analytics + CSV export with date range
- Settings: edit school, notification preferences, change password
- Super-admin: manage schools (tenants) and bootstrap their first admin

### Parent PWA
- Live map of the child's bus, route outline and pickup/drop-off alerts
- Multiple children, per-child view
- Notification feed + browser push opt-in
- Channel preferences and quiet hours
- Authorise a receiving adult, view/share a private code and revoke it
- History of trips associated with the child's current bus assignment

### Driver PWA
- Loads the assigned bus + route
- Start/end trip, morning-pickup vs afternoon-drop-off direction
- Real device GPS (`watchPosition`) **or** a simulated route for demos
- **Screen Wake Lock** while the browser permits it; this does not guarantee background GPS
- **Offline buffering**: positions are queued in `localStorage` and flushed in
  batches. The queue is capped at 10,000 readings with a visible capacity warning;
  clearing browser storage or losing the device can still lose queued readings
- Manual "Departed"/"Arrived"/"Emergency" signals
- Request and verify delegated handover codes on afternoon trips

### Geofence engine (`apps/api/src/modules/tracking`)
- Runs on **every** ingested position (so offline batches with a leave-then-return
  are handled correctly)
- Pickup / drop-off "approaching" (ETA or 4× radius) and "arrived" (inside radius)
- School "arrived" fires only after the bus has left and returned
- Route-deviation: 3 consecutive positions beyond `ROUTE_DEVIATION_M` from the path
- Every event is written to `trip_events` with a `dedupe_key` (unique per trip) so
  it fires exactly once, **and survives an API restart** — no in-memory-only state

---

## Configuration

All configuration is environment variables, validated with Zod at boot
(`apps/api/src/config/env.ts`). See [`.env.example`](.env.example). Notable ones:

- `SMTP_*` — leave `SMTP_HOST` blank in dev to auto-use an Ethereal test inbox
- `VAPID_PUBLIC_KEY` / `VAPID_PRIVATE_KEY` — `npx web-push generate-vapid-keys`;
  also set `VITE_VAPID_PUBLIC_KEY` for the web build
- `SMS_PROVIDER=termii` + `TERMII_API_KEY` for real SMS (default `log` just prints)
- `REDIS_URL` — if set, Socket.IO uses the Redis adapter so the API can scale out
- `HANDOVER_CODE_SECRET` — a stable, separate secret of at least 32 characters;
  mandatory in production. Changing it invalidates existing handover codes
- `HANDOVER_CODE_TTL_MINUTES` — 30 by default, range 5–60
- `VITE_GPS_FLUSH_MS` — GPS upload interval; default 1000 ms, range 500–10000.
  This is an upload interval, not a guarantee of GPS fix or network latency

---

## Project layout

```
bustrack-pro/
├── apps/
│   ├── api/
│   │   └── src/
│   │       ├── config/         env validation
│   │       ├── db/             knex, migrations, seed
│   │       ├── domain/         models + Zod DTOs + shared helpers
│   │       ├── repositories/   data-access layer
│   │       ├── modules/
│   │       │   ├── auth/       tokens, login/refresh/lockout
│   │       │   ├── geo/        haversine, polyline distance, ETA
│   │       │   ├── tracking/   trip lifecycle + geofence engine
│   │       │   └── notifications/  service + email/web-push/sms channels
│   │       ├── realtime/       Socket.IO server, rooms, emit helpers
│   │       ├── http/           middleware, routers, generic CRUD router
│   │       └── test/           Vitest + Supertest suites
│   └── web/
│       └── src/
│           ├── lib/            api client, auth store, socket, react-query hooks
│           ├── components/     UI kit, maps, layout, generic CRUD page
│           ├── features/       auth · admin/* · parent/* · driver/*
│           └── sw.ts           service worker (push + precache)
├── docker-compose.yml
└── .github/workflows/ci.yml
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for the data model and request flow.

---

## What is still deliberately out of scope

- A native mobile app. The driver PWA uses Wake Lock + offline buffering to make
  browser GPS viable, but a real fleet may still want a dedicated device or native
  app for guaranteed background location.
- Billing / plan management for the multi-tenant layer.
- Live SMS delivery is behind an adapter interface (Termii implemented, others are
  a few lines each).
