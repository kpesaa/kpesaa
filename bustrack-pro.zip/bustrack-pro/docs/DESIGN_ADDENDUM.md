# BusTrack Pro — design and implementation addendum
6 October 2026

## Purpose
This addendum extends Winnie's GPS-based primary school bus tracking and parent notification project. It documents the updated BusTrack Pro code, the new delegated child handover flow and the interface changes. The original Chapters 1–3 and Chapters 4–5 remain unchanged.

## How to use the figures
Figures 3.1–3.3 retain the original use-case, class and activity references. Figures 3.4–3.8 extend the design chapter. Figures 4.3–4.5 illustrate the upgraded interfaces; Figure 4.7 adds the parent handover screen while leaving the original Figure 4.6 reference available. Each figure is introduced explicitly in the accompanying text.

## Driver-initiated, parent-authorised handover
During an active afternoon trip, the driver selects a child and requests a code. The server generates a cryptographically random six-digit code, stores it encrypted and supplies it only to linked active guardians. The parent names the receiving adult and shares the code privately. The driver checks the adult present and submits their code. Successful verification consumes the code and records the adult, driver and time. See Figures 3.6–3.8 and 4.7.

## Code lifecycle
The default lifetime is 30 minutes, configurable between 5 and 60 minutes. Codes are trip- and child-specific, single-use, revocable and locked after five incorrect attempts. Repeated taps preserve an existing valid code. Invalid-code replacement requires a driver request and a one-minute cooldown. A verified handover cannot be regenerated or revoked. Expired or ended-trip codes cannot be used.

## Scope boundary
A GPS stop-arrival event proves only that the bus reached a location. Handover confirmation is a separate driver action backed by guardian authorisation and code verification. Boarding attendance and proof of legal identity are not implemented by the code alone. The designated adult's physical identity check remains an operational responsibility.

## List of figures
| Reference | Figure |
|---|---|
| Figure 3.1 | Use-case diagram |
| Figure 3.2 | Domain class diagram |
| Figure 3.3 | GPS tracking and notification activity |
| Figure 3.4 | System architecture |
| Figure 3.5 | Core entity-relationship diagram |
| Figure 3.6 | Delegated child handover activity |
| Figure 3.7 | Handover request and verification sequence |
| Figure 3.8 | Handover code lifecycle |
| Figure 4.3 | Driver workspace |
| Figure 4.4 | Parent live-tracking workspace |
| Figure 4.5 | School administrator workspace |
| Figure 4.7 | Parent receiver-authorisation screen |

## Figure 3.1: Use-case diagram
As illustrated in Figure 3.1, five human roles interact with the platform. A shared login establishes identity; parents control receiving-adult authorisation, while drivers request and verify handover codes. Administrators monitor transport and review handover records.

![Figure 3.1: Use-case diagram](diagrams/figure-3-1.png)

## Figure 3.2: Domain class diagram
Figure 3.2 presents the logical domain classes and their associations. User roles share one user record rather than an implemented inheritance hierarchy. Processing modules operate on these domain records; they do not imply that every domain record is a runtime TypeScript class.

![Figure 3.2: Domain class diagram](diagrams/figure-3-2.png)

## Figure 3.3: GPS tracking and notification activity
Figure 3.3 traces location collection, durable buffering, HTTP batch ingestion and Socket.IO delivery. The server processes every accepted position. A bus reaching a stop produces a proximity event; it does not prove a child was received.

![Figure 3.3: GPS tracking and notification activity](diagrams/figure-3-3.png)

## Figure 3.4: System architecture
Figure 3.4 shows the three application layers. Drivers send GPS batches over HTTPS; the backend broadcasts updates over Socket.IO. Handover secrets are retrieved only through authenticated guardian endpoints and are excluded from driver/admin responses and notification messages.

![Figure 3.4: System architecture](diagrams/figure-3-4.png)

## Figure 3.5: Core entity-relationship diagram
Figure 3.5 shows the core relational model and the new child_handovers table. A unique trip/student pair holds the current code lifecycle, while audit_logs retain generation, authorisation, rejection, revocation and completed-handover actions. Supporting token, push, preference and delivery tables are omitted for clarity.

![Figure 3.5: Core entity-relationship diagram](diagrams/figure-3-5.png)

## Figure 3.6: Delegated child handover activity
As illustrated in Figure 3.6, the driver initiates a code request for one child during an active afternoon trip. The guardian names the receiving adult and shares the code privately. The driver checks the adult and verifies the code; failure keeps the handover unconfirmed.

![Figure 3.6: Delegated child handover activity](diagrams/figure-3-6.png)

## Figure 3.7: Handover request and verification sequence
Figure 3.7 gives the message order for a successful delegated handover. Code delivery to the receiving adult is a private action performed by the parent. Driver verification includes a locked database transaction so concurrent submissions cannot consume the same code twice.

![Figure 3.7: Handover request and verification sequence](diagrams/figure-3-7.png)

## Figure 3.8: Handover code lifecycle
Figure 3.8 distinguishes stored states from the derived expired state. A code works only during its active trip and after guardian authorisation. Verified handovers cannot be regenerated or revoked; regeneration of an invalid code requires the driver and a one-minute cooldown.

![Figure 3.8: Handover code lifecycle](diagrams/figure-3-8.png)

## Figure 4.3: Driver workspace
Figure 4.3 illustrates the updated driver workspace: trip controls, persistent GPS/upload status and a per-child handover panel. Verification requires the driver to confirm the receiving adult and enter the code supplied by that adult.

![Figure 4.3: Driver workspace](ui/driver-desktop.png)

## Figure 4.4: Parent live-tracking workspace
Figure 4.4 shows the parent's live bus map, planned route, stop geofences, location freshness and recent notifications. An active bus trip is deliberately presented separately from a confirmed child handover.

![Figure 4.4: Parent live-tracking workspace](ui/parent-desktop.png)

## Figure 4.5: School administrator workspace
Figure 4.5 illustrates the fleet overview, summary figures, all located active buses and navigation to handover records. Administrators can review receiving-adult and driver confirmation records without retrieving secret handover codes.

![Figure 4.5: School administrator workspace](ui/admin-desktop.png)

## Figure 4.7: Parent receiver-authorisation screen
As illustrated in Figure 4.7, the parent names a receiving adult, authorises that person and copies the one-time code for private sharing. A revoke action invalidates the code if arrangements change.

![Figure 4.7: Parent receiver-authorisation screen](ui/parent-handover.png)

## Recommended next additions
| Priority | Addition | Purpose |
|---|---|---|
| P1 | Boarding and alighting attendance | Record who actually boarded, who left the bus and who was received; link those records to each trip. |
| P1 | Not travelling today | Let guardians report absence before a trip so drivers know which stops and children to expect. |
| P1 | Acknowledged delay and emergency alerts | Add breakdown/delay reporting, staff acknowledgement and an escalation log for alerts that remain unresolved. |
| P1 | School-managed handover exceptions | Define a staff approval process for unavailable guardians, failed codes or disputed receiving adults. Keep exceptions separate from normal code verification. |
| P2 | Trusted receiving-adult directory | Allow guardians to maintain approved caregivers and choose one for a particular trip, with an auditable change history. |
| P2 | Notification outbox and retries | Queue external delivery jobs, retry transient failures and show delivered/failed states to authorised staff. |
| P2 | Route-aware arrival estimates | Use route distance and stop order rather than straight-line distance alone; measure accuracy before presenting estimates as reliable. |
| P2 | Data retention and access review | Define how long pupil location and handover records are retained, restrict exports and review account access routinely. |
| P3 | Native driver app if background tracking is required | Browser tracking still depends on page visibility and device policies. Consider a native location service when reliable background collection becomes an operational requirement. |

## Implementation and validation
### Backend changes
Added child_handovers migration and REST endpoints; encrypted code retrieval for guardians; parent receiver authorisation and revocation; driver verification with row locking and persistent failed-attempt counting; school handover records and append-only application audit actions.

### Tracking and access changes
Live bus subscriptions now check school/family/driver access. Drivers can start only their assigned bus. Afternoon departure is detected automatically; route deviations notify guardians and dispatchers. Student/guardian/driver assignments are checked against school ownership. Parent history is scoped to linked current bus assignments.

### Interface changes
Updated navy/blue navigation shell, outline icons, status hierarchy, larger touch targets, keyboard focus, mobile drawer and reduced-motion support. Added parent handover and history pages, route overlay, recent alerts and stale-position messaging. Fleet map renders every located active bus. Driver errors are persistent, GPS queues are trip-scoped and trip end requires queued locations to upload first.

### Configuration and deployment
Run npm ci, copy .env.example to .env and set database/JWT values. Set a dedicated stable HANDOVER_CODE_SECRET of at least 32 characters before production startup. Run npm run db:migrate before starting the updated server. The schema now has 17 application tables. Use HTTPS on phones and configure SMTP, Web Push and SMS credentials for external channels. Live GPS flush defaults to one second; VITE_GPS_FLUSH_MS can tune it.

### Validation results
40 backend tests pass: geometry 12, authentication/access 7, trip lifecycle/geofencing 8, handover/access additions 13. Tests use an embedded PostgreSQL engine through a test-only Knex adapter; production continues to use the normal pg driver. The production API/web build passes.

### Browser validation
Nine desktop/mobile checks pass with no JavaScript page errors: live-tracking navigation; parent receiver authorisation and code display; parent history; receiver-check gating; wrong-code feedback; successful verification; administrator secret exclusion; 390px mobile navigation/overflow; and completed trips not being resumed. These client checks use mocked API fixtures. Backend behaviours are tested separately.

### Remaining live validation
The screenshots use fictional demonstration data and intentionally unavailable external map tiles to verify fallback messaging. No live deployment, field GPS timing, actual SMTP/Web Push/SMS delivery, production PostgreSQL server run or guaranteed background location collection is claimed. Test those on the intended server and phones before operational use.

## Sources
- Winnie_Chapters_1_to_3.docx: Supplied attachment: project objectives, requirements and design.
- Winnie Chapter 4, 5.docx: https://docs.google.com/document/d/1akbsbg1S23ob8mpGg7TI3jJ_cJ4ZR0TC/edit
- BusTrack Pro source: Supplied bustrack-pro.zip and the updated code in this deliverable.
- OWASP token guidance: https://cheatsheetseries.owasp.org/cheatsheets/Forgot_Password_Cheat_Sheet.html
- W3C Screen Wake Lock explainer: https://github.com/w3c/screen-wake-lock/blob/gh-pages/explainer.md
