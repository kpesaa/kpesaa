# Validation — 6 October 2026

## Completed checks

| Check | Result | Coverage |
|---|---|---|
| API tests with embedded PostgreSQL | 40/40 passed | 12 geometry, 7 authentication/access, 8 trip/geofence and 13 handover/access tests |
| API and web production build | Passed | TypeScript compilation, Vite bundle and PWA service worker generation |
| Desktop/mobile browser checks | 9/9 passed, no page errors | Parent navigation, authorisation/code display/history, driver receiver gate/wrong-code/success, administrator records without secrets, 390px mobile layout, completed trip does not resume |

Browser checks used fictional API fixtures, separately from backend HTTP/database
tests. Screenshots and the check summary are in `docs/ui/`. Map tile requests
were deliberately unavailable during browser checks; the fallback message was
visible. This is not a live end-to-end deployment test.

## Reproduce backend checks

From the project root, install dependencies with `npm ci`, then run:

```bash
DATABASE_URL=postgres://unused/bustrack_pro_test \
JWT_ACCESS_SECRET=test-access-secret-at-least-32-characters \
JWT_REFRESH_SECRET=test-refresh-secret-at-least-32-characters \
npm run test:embedded -w apps/api

npm run build
```

The test-only adapter uses an in-memory PGlite PostgreSQL engine and is selected
only by `PGLITE_TEST=true` in the embedded test script. Normal API operation uses
the existing `pg` driver. To validate a separately deployed PostgreSQL server,
configure a dedicated database ending in `_test` and use `npm test`.

## Deployment preparation

Apply the new migration with `npm run db:migrate`. Configure a separate stable
`HANDOVER_CODE_SECRET` of at least 32 characters before running in production.
Use real school/user data rather than demo accounts, and configure the selected
notification providers and HTTPS origin. Codes default to a 30-minute expiry
and lock after five wrong attempts; the parent must authorise a receiver before
the driver can verify a code.

## Remaining live checks

- Real phones: GPS permission, weak signal, reconnect, browser sleep and local
  storage limits. Screen Wake Lock does not guarantee background GPS.
- Real email, SMS and push delivery, including emergency notifications.
- A deployed PostgreSQL server and concurrent clients under expected fleet load.
- The school's practical receiving-adult identity check and exception procedure.

The upgraded code has not been deployed. Actual notification delivery, field GPS
latency and physical child handover have not been tested in this workspace.
