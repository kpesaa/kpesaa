import L from 'leaflet';
import { useEffect, useState } from 'react';
import {
  Circle,
  MapContainer,
  Marker,
  Polyline,
  TileLayer,
  Tooltip,
  useMap,
  useMapEvents,
} from 'react-leaflet';

// Basemap providers, in fallback order. All are keyless.
//  - tile.openstreetmap.de: standard OSM style, reachable where tile.openstreetmap.org
//    is blocked; Carto's free tiles now serve an "API key required" placeholder.
//  - Esri World Street Map: global CDN, very reliable, {z}/{y}/{x} order.
const PROVIDERS = [
  {
    url: 'https://{s}.tile.openstreetmap.de/{z}/{x}/{y}.png',
    attribution: '© OpenStreetMap contributors',
    maxZoom: 18,
  },
  {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles © Esri — OpenStreetMap contributors',
    maxZoom: 19,
  },
];

/** Tile layer that advances to the next provider after repeated load errors. */
function BaseTiles() {
  const [idx, setIdx] = useState(0);
  const [errs, setErrs] = useState(0);
  const p = PROVIDERS[Math.min(idx, PROVIDERS.length - 1)] ?? PROVIDERS[0]!;
  const canFallback = idx < PROVIDERS.length - 1;

  useEffect(() => {
    if (errs >= 4 && canFallback) {
      setIdx((i) => i + 1);
      setErrs(0);
    }
  }, [errs, canFallback]);

  return (
    <>
    <TileLayer
      key={idx}
      url={p.url}
      attribution={p.attribution}
      maxZoom={p.maxZoom}
      eventHandlers={{ tileerror: () => setErrs((n) => n + 1) }}
    />
    {!canFallback && errs >= 4 && <div role="status" className="absolute bottom-7 left-3 right-3 z-[500] rounded-lg bg-white/95 px-3 py-2 text-xs text-slate-600 shadow-sm">Map background unavailable. Bus and route overlays remain visible.</div>}
    </>
  );
}

const symbolIcon = (symbol: string, size = 30) => {
  const bus = symbol === 'bus';
  const school = symbol === 'school';
  const dot = ['start', 'end', 'point'].includes(symbol);
  const colour = symbol === 'start' ? '#10b981' : symbol === 'end' ? '#ef4444' : '#2563eb';
  const path = bus ? '<rect x="4" y="3" width="16" height="16" rx="3"/><path d="M4 11h16M8 3v8m8-8v8M7 19v2m10-2v2M7 15h1m8 0h1"/>'
    : school ? '<path d="m3 9 9-6 9 6v12H3V9Zm7 12v-6h4v6M7 10h1m8 0h1"/>'
    : '<path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>';
  return L.divIcon({ className: '', html: dot
    ? `<div style="width:${size}px;height:${size}px;border-radius:50%;background:${colour};border:2px solid white;box-shadow:0 2px 6px #0f172a44"></div>`
    : `<div style="width:${size}px;height:${size}px;border-radius:12px;background:${bus ? colour : 'white'};color:${bus ? 'white' : colour};display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px #0f172a44"><svg width="${size - 10}" height="${size - 10}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${path}</svg></div>`,
    iconSize: [size, size], iconAnchor: [size / 2, size / 2] });
};
const busIcon = symbolIcon('bus', 38);
const schoolIcon = symbolIcon('school', 32);
const stopIcon = symbolIcon('stop', 30);

function Recenter({ lat, lng }: { lat?: number | null; lng?: number | null }) {
  const map = useMap();
  useEffect(() => {
    if (lat != null && lng != null) map.panTo([lat, lng], { animate: true });
  }, [lat, lng, map]);
  return null;
}

function FitBounds({ points }: { points: [number, number][] }) {
  const map = useMap();
  useEffect(() => {
    if (points.length >= 2) map.fitBounds(L.latLngBounds(points), { padding: [40, 40] });
  }, [points, map]);
  return null;
}

export interface MapStop {
  id: string;
  name: string;
  lat: number;
  lng: number;
  radius_m: number;
}

export function LiveMap({
  school,
  bus,
  stops = [],
  buses = [],
  path = [],
  height = '100%',
  follow = true,
}: {
  school?: { lat: number; lng: number; name?: string; radius_m?: number };
  bus?: { lat: number; lng: number; label?: string } | null;
  stops?: MapStop[];
  buses?: { id: string; lat: number; lng: number; label?: string }[];
  path?: [number, number][];
  height?: string | number;
  follow?: boolean;
}) {
  const center: [number, number] = bus
    ? [bus.lat, bus.lng]
    : school
      ? [school.lat, school.lng]
      : [5.0478, 7.9137];

  return (
    <div style={{ height }}>
      <MapContainer center={center} zoom={14} className="h-full w-full">
        <BaseTiles />
        {path.length >= 2 && (
          <Polyline positions={path} pathOptions={{ color: '#2563eb', weight: 4, opacity: 0.7 }} />
        )}
        {school && (
          <>
            <Marker position={[school.lat, school.lng]} icon={schoolIcon}>
              <Tooltip>{school.name ?? 'School'}</Tooltip>
            </Marker>
            {school.radius_m && (
              <Circle
                center={[school.lat, school.lng]}
                radius={school.radius_m}
                pathOptions={{ color: '#2563eb', fillOpacity: 0.05, dashArray: '4 4' }}
              />
            )}
          </>
        )}
        {stops.map((s) => (
          <div key={s.id}>
            <Marker position={[s.lat, s.lng]} icon={stopIcon}>
              <Tooltip>{s.name}</Tooltip>
            </Marker>
            <Circle
              center={[s.lat, s.lng]}
              radius={s.radius_m}
              pathOptions={{ color: '#0ea5e9', fillOpacity: 0.06, dashArray: '3 4' }}
            />
          </div>
        ))}
        {buses.map((b) => <Marker key={b.id} position={[b.lat, b.lng]} icon={busIcon}><Tooltip permanent direction="top" offset={[0, -14]}>{b.label ?? 'Bus'}</Tooltip></Marker>)}
        {bus && (
          <Marker position={[bus.lat, bus.lng]} icon={busIcon}>
            <Tooltip permanent direction="top" offset={[0, -14]}>
              {bus.label ?? 'Bus'}
            </Tooltip>
          </Marker>
        )}
        {follow && bus && <Recenter lat={bus.lat} lng={bus.lng} />}
      </MapContainer>
    </div>
  );
}

/** Click-to-add-points route editor. */
export function RouteEditorMap({
  path,
  onChange,
  stops = [],
  height = 420,
}: {
  path: [number, number][];
  onChange: (path: [number, number][]) => void;
  stops?: MapStop[];
  height?: number;
}) {
  function Clicker() {
    useMapEvents({
      click(e) {
        onChange([...path, [e.latlng.lat, e.latlng.lng]]);
      },
    });
    return null;
  }
  return (
    <div style={{ height }}>
      <MapContainer center={path[0] ?? [5.0478, 7.9137]} zoom={14} className="h-full w-full">
        <BaseTiles />
        <Clicker />
        {path.length >= 2 && (
          <Polyline positions={path} pathOptions={{ color: '#2563eb', weight: 4 }} />
        )}
        {path.map((p, i) => (
          <Marker
            key={`${p[0]},${p[1]},${i}`}
            position={p}
            icon={symbolIcon(i === 0 ? 'start' : i === path.length - 1 ? 'end' : 'point', 14)}
            eventHandlers={{ click: () => onChange(path.filter((_, idx) => idx !== i)) }}
          >
            <Tooltip>Point {i + 1} — click to remove</Tooltip>
          </Marker>
        ))}
        {stops.map((s) => (
          <Marker key={s.id} position={[s.lat, s.lng]} icon={stopIcon}>
            <Tooltip>{s.name}</Tooltip>
          </Marker>
        ))}
        <FitBounds points={path} />
      </MapContainer>
    </div>
  );
}

export function TrackReplayMap({
  track,
  index,
  school,
  height = 380,
}: {
  track: { lat: number; lng: number }[];
  index: number;
  school?: { lat: number; lng: number };
  height?: number;
}) {
  const pts = track.map((t) => [t.lat, t.lng] as [number, number]);
  const cur = track[Math.min(index, track.length - 1)];
  return (
    <div style={{ height }}>
      <MapContainer center={pts[0] ?? [5.0478, 7.9137]} zoom={14} className="h-full w-full">
        <BaseTiles />
        {pts.length >= 2 && (
          <Polyline
            positions={pts}
            pathOptions={{ color: '#cbd5e1', weight: 3, dashArray: '4 4' }}
          />
        )}
        {index > 0 && (
          <Polyline
            positions={pts.slice(0, index + 1)}
            pathOptions={{ color: '#4f46e5', weight: 4 }}
          />
        )}
        {school && <Marker position={[school.lat, school.lng]} icon={schoolIcon} />}
        {cur && <Marker position={[cur.lat, cur.lng]} icon={busIcon} />}
        <FitBounds points={pts} />
      </MapContainer>
    </div>
  );
}
