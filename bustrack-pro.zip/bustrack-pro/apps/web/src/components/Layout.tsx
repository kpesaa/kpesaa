import { type ReactNode, useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { api } from '../lib/api';
import { useUnread } from '../lib/queries';
import { disconnectSocket, getSocket, useSocketConnected, useSocketEvent } from '../lib/socket';
import { type Role, useAuth } from '../lib/store';
import { cn } from '../lib/utils';
import { Icon } from './Icon';
import { useToast } from './ui';

const adminNav = [
  { to: '/admin', label: 'Overview', icon: 'grid' },
  { to: '/admin/trips', label: 'Trips', icon: 'route' },
  { to: '/admin/handovers', label: 'Handover records', icon: 'shield' },
  { to: '/admin/buses', label: 'Buses', icon: 'bus' },
  { to: '/admin/routes', label: 'Routes & stops', icon: 'pin' },
  { to: '/admin/students', label: 'Students', icon: 'users' },
  { to: '/admin/drivers', label: 'Drivers', icon: 'users' },
  { to: '/admin/parents', label: 'Parents', icon: 'users' },
  { to: '/admin/staff', label: 'Staff', icon: 'users' },
  { to: '/admin/reports', label: 'Reports', icon: 'chart' },
  { to: '/admin/settings', label: 'Settings', icon: 'settings' },
];
const NAV: Record<Role, typeof adminNav> = {
  super_admin: [{ to: '/admin/schools', label: 'Schools', icon: 'school' }],
  admin: adminNav,
  dispatcher: adminNav.filter((n) => n.to !== '/admin/staff'),
  driver: [{ to: '/driver', label: 'My trip', icon: 'bus' }],
  parent: [
    { to: '/parent', label: 'Live tracking', icon: 'pin' },
    { to: '/parent/handovers', label: 'Child handover', icon: 'shield' },
    { to: '/parent/history', label: 'Trip history', icon: 'clock' },
    { to: '/parent/notifications', label: 'Notifications', icon: 'bell' },
    { to: '/parent/settings', label: 'Settings', icon: 'settings' },
  ],
};

export function AppShell({ children }: { children: ReactNode }) {
  const { user, clear } = useAuth();
  const nav = useNavigate();
  const location = useLocation();
  const connected = useSocketConnected();
  const unread = useUnread();
  const toast = useToast();
  const [menuOpen, setMenuOpen] = useState(false);
  const school = useQuery({ queryKey: ['my-school'], queryFn: () => api<{ name: string; lat: number; lng: number; radius_m: number } | null>('/me/school') });
  useEffect(() => { getSocket(); }, []);
  useEffect(() => { setMenuOpen(false); }, [location.pathname]);
  useEffect(() => {
    const close = (e: KeyboardEvent) => { if (e.key === 'Escape') setMenuOpen(false); };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, []);
  useSocketEvent<{ title: string; body: string }>('notification:new', (n) => { toast(`${n.title} — ${n.body}`); unread.refetch(); });
  if (!user) return null;
  const items = NAV[user.role];
  const logout = async () => {
    await api('/auth/logout', { method: 'POST', json: { refreshToken: useAuth.getState().refreshToken } }).catch(() => {});
    disconnectSocket(); clear(); nav('/login');
  };
  const brand = <div className="flex items-center gap-3 px-6 pb-7 pt-7"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-500 text-white"><Icon name="bus" size={27} /></div>
    <div><div className="text-lg font-bold tracking-tight text-white">BusTrack<span className="ml-1 text-blue-300">Pro</span></div><div className="mt-0.5 text-[10px] uppercase tracking-[.18em] text-slate-400">Every journey, connected</div></div></div>;
  const navList = <nav aria-label="Main navigation" className="flex-1 space-y-1 overflow-y-auto px-4"><p className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[.2em] text-slate-500">Your workspace</p>
    {items.map((it) => <NavLink key={it.to} to={it.to} end={it.to === '/admin' || it.to === '/parent'} onClick={() => setMenuOpen(false)}
      className={({ isActive }) => cn('flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition', isActive ? 'bg-blue-500/15 text-blue-200' : 'text-slate-400 hover:bg-white/5 hover:text-white')}>
      <Icon name={it.icon} size={18} />{it.label}{it.to.includes('notification') && (unread.data?.count ?? 0) > 0 && <span className="ml-auto rounded-full bg-blue-500 px-2 text-[10px] text-white">{unread.data?.count}</span>}</NavLink>)}
  </nav>;
  const footer = <div className="m-4 rounded-2xl border border-white/10 bg-white/5 p-4"><div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-700 text-xs font-bold text-white">{user.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}</span>
    <div className="min-w-0"><p className="truncate text-sm font-semibold text-white">{user.name}</p><p className="mt-0.5 text-[10px] capitalize text-slate-400">{user.role.replace('_', ' ')}</p></div></div>
    <button onClick={logout} className="mt-3 flex min-h-10 items-center gap-2 text-xs text-slate-400 hover:text-white" type="button"><Icon name="exit" size={16} />Sign out</button></div>;
  return <div className="flex min-h-screen">
    <a href="#main-content" className="sr-only z-50 rounded bg-white p-3 focus:not-sr-only focus:absolute">Skip to content</a>
    <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col bg-[#102035] lg:flex">{brand}{navList}{footer}</aside>
    {menuOpen && <div className="fixed inset-0 z-[1000] lg:hidden"><button aria-label="Close navigation" onClick={() => setMenuOpen(false)} className="absolute inset-0 bg-slate-950/50" type="button"/><aside className="absolute left-0 top-0 flex h-full w-72 flex-col bg-[#102035]">{brand}{navList}{footer}</aside></div>}
    <div className="min-w-0 flex-1"><header className="flex h-20 items-center justify-between gap-4 border-b border-slate-200/80 bg-white px-4 sm:px-8">
      <div className="flex min-w-0 items-center gap-3"><button type="button" aria-label="Open navigation" aria-expanded={menuOpen} onClick={() => setMenuOpen(true)} className="btn-ghost px-3 lg:hidden"><Icon name="menu" /></button>
        <div className="min-w-0"><p className="eyebrow">School transport</p><p className="mt-1 truncate text-sm font-semibold">{school.data?.name ?? (user.role === 'super_admin' ? 'Platform console' : 'Your school')}</p></div></div>
      <div className="flex items-center gap-3"><span className={cn('hidden items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium sm:inline-flex', connected ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800')}><span className={cn('h-1.5 w-1.5 rounded-full', connected ? 'bg-emerald-500' : 'bg-amber-500')} />{connected ? 'Live connection' : 'Reconnecting'}</span>
        <NavLink to={user.role === 'parent' ? '/parent/notifications' : user.role === 'driver' ? '/driver' : user.role === 'super_admin' ? '/admin/schools' : '/admin/handovers'} className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 text-slate-600" aria-label={user.role === 'parent' ? 'Notifications' : 'Open workspace'}><Icon name={user.role === 'parent' ? 'bell' : 'shield'} /></NavLink></div></header>
      <main id="main-content" className="mx-auto max-w-[1500px] p-4 pb-10 sm:p-8">{children}</main>
    </div>
  </div>;
}
