import { useQuery } from '@tanstack/react-query';
import { type ReactNode, useMemo, useState } from 'react';
import { useAuth } from '../lib/store';
import { ApiError, api } from '../lib/api';
import { type Page, usePage } from '../lib/queries';
import { useCrud } from '../lib/queries';
import { Button, Field, Input, Modal, PageHeader, Select, Spinner, Table, useToast } from './ui';

export interface FieldDef {
  name: string;
  label: string;
  type?: 'text' | 'number' | 'email' | 'tel' | 'select' | 'checkbox' | 'multiselect' | 'hidden';
  options?: { value: string; label: string }[] | (() => { value: string; label: string }[]);
  required?: boolean;
  placeholder?: string;
  help?: string;
  /** Show in the create form only. */
  createOnly?: boolean;
  default?: unknown;
}

export interface ColumnDef<T> {
  key: string;
  header: string;
  render?: (row: T) => ReactNode;
}

interface Props<T extends { id: string }> {
  title: string;
  subtitle?: string;
  path: string; // API path, e.g. /buses
  queryKey: string;
  columns: ColumnDef<T>[];
  fields: FieldDef[];
  toForm?: (row: T) => Record<string, unknown>;
  extraRowActions?: (row: T) => ReactNode;
  canWrite?: boolean;
  /** Extra static query params applied to the list request (e.g. { role: 'driver' }). */
  params?: Record<string, string | undefined>;
}

export function CrudPage<T extends { id: string }>({
  title,
  subtitle,
  path,
  queryKey,
  columns,
  fields,
  toForm,
  extraRowActions,
  canWrite: allowWrite = true,
  params,
}: Props<T>) {
  const role = useAuth((s) => s.user?.role);
  const canWrite = allowWrite && (role === 'admin' || role === 'super_admin');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const list = usePage<T>(queryKey, path, { ...params, q, page, pageSize: 20 });
  const { create, update, remove } = useCrud<T>(queryKey, path);
  const toast = useToast();

  const [editing, setEditing] = useState<T | 'new' | null>(null);

  async function onSubmit(values: Record<string, unknown>) {
    try {
      if (editing === 'new') {
        await create.mutateAsync(values);
        toast(`${title.replace(/s$/, '')} created`);
      } else if (editing) {
        await update.mutateAsync({ id: (editing as T).id, body: values });
        toast('Saved');
      }
      setEditing(null);
    } catch (err) {
      toast(err instanceof ApiError ? err.message : 'Save failed', 'err');
    }
  }

  async function onDelete(row: T) {
    if (!confirm('Delete this record? This cannot be undone.')) return;
    try {
      await remove.mutateAsync(row.id);
      toast('Deleted');
    } catch (err) {
      toast(err instanceof ApiError ? err.message : 'Delete failed', 'err');
    }
  }

  const cols: ColumnDef<T>[] = [
    ...columns,
    ...(canWrite
      ? [
          {
            key: '_actions',
            header: '',
            render: (row: T) => (
              <div className="flex justify-end gap-1.5">
                {extraRowActions?.(row)}
                <button
                  className="text-xs font-semibold text-brand-600 hover:underline"
                  onClick={() => setEditing(row)}
                >
                  Edit
                </button>
                <button
                  className="text-xs font-semibold text-rose-600 hover:underline"
                  onClick={() => onDelete(row)}
                >
                  Delete
                </button>
              </div>
            ),
          } satisfies ColumnDef<T>,
        ]
      : []),
  ];

  return (
    <div>
      <PageHeader
        title={title}
        subtitle={subtitle}
        actions={
          <div className="flex gap-2">
            <Input
              placeholder="Search…"
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setPage(1);
              }}
              className="input w-44"
            />
            {canWrite && <Button onClick={() => setEditing('new')}>+ New</Button>}
          </div>
        }
      />

      <div className="card p-1">
        {list.isLoading ? (
          <div className="flex justify-center py-16">
            <Spinner className="text-brand-500" />
          </div>
        ) : (
          <Table columns={cols as never} rows={list.data?.data ?? []} />
        )}
      </div>

      <Pager page={list.data?.pagination} onPage={setPage} />

      {editing && (
        <EditModal
          title={
            editing === 'new' ? `New ${title.replace(/s$/, '')}` : `Edit ${title.replace(/s$/, '')}`
          }
          fields={fields}
          isNew={editing === 'new'}
          row={editing === 'new' ? null : (editing as T)}
          path={path}
          toForm={toForm}
          busy={create.isPending || update.isPending}
          onClose={() => setEditing(null)}
          onSubmit={onSubmit}
        />
      )}
    </div>
  );
}

function Pager({
  page,
  onPage,
}: { page?: Page<unknown>['pagination']; onPage: (p: number) => void }) {
  if (!page || !page.totalPages || page.totalPages <= 1) return null;
  return (
    <div className="mt-3 flex items-center justify-end gap-3 text-sm text-slate-500">
      <span>
        {page.total} total · page {page.page}/{page.totalPages}
      </span>
      <button className="btn-ghost" disabled={page.page <= 1} onClick={() => onPage(page.page - 1)}>
        Prev
      </button>
      <button
        className="btn-ghost"
        disabled={page.page >= page.totalPages}
        onClick={() => onPage(page.page + 1)}
      >
        Next
      </button>
    </div>
  );
}

/**
 * Wraps EntityForm. On edit, fetches the full record ({path}/{id}) so joined
 * fields (guardians, stops, …) populate the form even though the list row omits them.
 */
function EditModal<T extends { id: string }>({
  title,
  fields,
  isNew,
  row,
  path,
  toForm,
  busy,
  onClose,
  onSubmit,
}: {
  title: string;
  fields: FieldDef[];
  isNew: boolean;
  row: T | null;
  path: string;
  toForm?: (row: T) => Record<string, unknown>;
  busy: boolean;
  onClose: () => void;
  onSubmit: (v: Record<string, unknown>) => void;
}) {
  const full = useQuery({
    queryKey: [path, 'edit', row?.id],
    queryFn: () => api<T>(`${path}/${row!.id}`),
    enabled: !isNew && !!row,
  });

  if (isNew) {
    return (
      <EntityForm
        title={title}
        fields={fields}
        initial={{}}
        isNew
        busy={busy}
        onClose={onClose}
        onSubmit={onSubmit}
      />
    );
  }

  if (full.isLoading || !full.data) {
    return (
      <Modal open onClose={onClose} title={title}>
        <div className="flex justify-center py-10">
          <Spinner className="text-brand-500" />
        </div>
      </Modal>
    );
  }

  const record = full.data;
  return (
    <EntityForm
      title={title}
      fields={fields}
      initial={toForm ? toForm(record) : (record as unknown as Record<string, unknown>)}
      isNew={false}
      busy={busy}
      onClose={onClose}
      onSubmit={onSubmit}
    />
  );
}

export function EntityForm({
  title,
  fields,
  initial,
  isNew,
  busy,
  onClose,
  onSubmit,
}: {
  title: string;
  fields: FieldDef[];
  initial: Record<string, unknown>;
  isNew: boolean;
  busy: boolean;
  onClose: () => void;
  onSubmit: (v: Record<string, unknown>) => void;
}) {
  const visible = fields.filter((f) => f.type !== 'hidden' && (!f.createOnly || isNew));
  const [values, setValues] = useState<Record<string, unknown>>(() => {
    const v: Record<string, unknown> = {};
    for (const f of fields) {
      v[f.name] =
        initial[f.name] ??
        f.default ??
        (f.type === 'checkbox' ? false : f.type === 'multiselect' ? [] : '');
    }
    return v;
  });
  const set = (k: string, val: unknown) => setValues((s) => ({ ...s, [k]: val }));

  const options = useMemo(
    () =>
      Object.fromEntries(
        fields.map((f) => [
          f.name,
          typeof f.options === 'function' ? f.options() : (f.options ?? []),
        ]),
      ),
    [fields],
  );

  function handle(e: React.FormEvent) {
    e.preventDefault();
    const out: Record<string, unknown> = {};
    for (const f of fields) {
      if (f.createOnly && !isNew) continue;
      let v = values[f.name];
      if (f.type === 'number') v = v === '' || v == null ? undefined : Number(v);
      if ((v === '' || v == null) && !f.required) v = f.type === 'multiselect' ? [] : undefined;
      out[f.name] = v;
    }
    onSubmit(out);
  }

  return (
    <Modal open onClose={onClose} title={title}>
      <form onSubmit={handle} className="space-y-3">
        {visible.map((f) => (
          <Field key={f.name} label={f.label}>
            {f.type === 'select' ? (
              <Select
                value={String(values[f.name] ?? '')}
                onChange={(e) => set(f.name, e.target.value || null)}
                required={f.required}
              >
                <option value="">— select —</option>
                {(options[f.name] ?? []).map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </Select>
            ) : f.type === 'multiselect' ? (
              <select
                multiple
                className="input h-28"
                value={(values[f.name] as string[]) ?? []}
                onChange={(e) =>
                  set(
                    f.name,
                    [...e.target.selectedOptions].map((o) => o.value),
                  )
                }
              >
                {(options[f.name] ?? []).map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            ) : f.type === 'checkbox' ? (
              <input
                type="checkbox"
                className="h-4 w-4"
                checked={Boolean(values[f.name])}
                onChange={(e) => set(f.name, e.target.checked)}
              />
            ) : (
              <Input
                type={f.type ?? 'text'}
                value={String(values[f.name] ?? '')}
                onChange={(e) => set(f.name, e.target.value)}
                required={f.required}
                placeholder={f.placeholder}
              />
            )}
            {f.help && <span className="mt-1 block text-xs text-slate-400">{f.help}</span>}
          </Field>
        ))}
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" type="button" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Save'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
