import { api } from './api';

function urlBase64ToUint8Array(base64: string): Uint8Array<ArrayBuffer> {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4);
  const b64 = (base64 + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(b64);
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return arr;
}

export async function enablePush(): Promise<'ok' | 'unsupported' | 'denied' | 'no-key'> {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return 'unsupported';
  const { key } = await api<{ key: string | null }>('/me/push/public-key');
  if (!key) return 'no-key';

  const perm = await Notification.requestPermission();
  if (perm !== 'granted') return 'denied';

  const reg = await navigator.serviceWorker.ready;
  const sub =
    (await reg.pushManager.getSubscription()) ??
    (await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(key),
    }));

  await api('/me/push/subscribe', { method: 'POST', json: sub.toJSON() });
  return 'ok';
}

export async function disablePush(): Promise<void> {
  const reg = await navigator.serviceWorker.ready;
  const sub = await reg.pushManager.getSubscription();
  if (sub) {
    await api('/me/push/unsubscribe', { method: 'POST', json: { endpoint: sub.endpoint } });
    await sub.unsubscribe();
  }
}
