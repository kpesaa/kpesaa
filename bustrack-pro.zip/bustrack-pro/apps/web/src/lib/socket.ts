import { useEffect, useRef, useState } from 'react';
import { type Socket, io } from 'socket.io-client';
import { useAuth } from './store';

let shared: Socket | null = null;

export function getSocket(): Socket | null {
  const token = useAuth.getState().accessToken;
  if (!token) return null;
  if (!shared) {
    shared = io({ path: '/socket.io', auth: { token }, transports: ['websocket', 'polling'] });
  } else {
    shared.auth = { token };
  }
  return shared;
}

export function disconnectSocket() {
  shared?.disconnect();
  shared = null;
}

/** Subscribe to a socket event for the lifetime of a component. */
export function useSocketEvent<T = unknown>(event: string, handler: (payload: T) => void) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    const s = getSocket();
    if (!s) return;
    const cb = (p: T) => ref.current(p);
    s.on(event, cb);
    return () => {
      s.off(event, cb);
    };
  }, [event]);
}

export function useSocketConnected(): boolean {
  const [connected, setConnected] = useState(() => Boolean(shared?.connected));
  useEffect(() => {
    const s = getSocket();
    if (!s) return;
    setConnected(s.connected);
    const on = () => setConnected(true);
    const off = () => setConnected(false);
    s.on('connect', on);
    s.on('disconnect', off);
    return () => {
      s.off('connect', on);
      s.off('disconnect', off);
    };
  }, []);
  return connected;
}
