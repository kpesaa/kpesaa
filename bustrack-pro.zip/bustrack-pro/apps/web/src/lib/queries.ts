import {
  type UseMutationOptions,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import { api } from './api';

export interface Page<T> {
  data: T[];
  pagination: { page: number; pageSize: number; total: number; totalPages: number };
}

export interface Bus {
  id: string;
  plate_number: string;
  label: string | null;
  model: string | null;
  capacity: number;
  driver_id: string | null;
  status: string;
}
export interface UserRow {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  role: string;
  status: string;
}
export interface RouteRow {
  id: string;
  name: string;
  description: string | null;
  path: [number, number][];
  active: boolean;
  length_m?: number;
  stops?: StopRow[];
}
export interface StopRow {
  id: string;
  route_id: string;
  name: string;
  kind: string;
  lat: number;
  lng: number;
  radius_m: number;
  sequence: number;
}
export interface StudentRow {
  id: string;
  first_name: string;
  last_name: string;
  grade: string | null;
  bus_id: string | null;
  route_id: string | null;
  pickup_stop_id: string | null;
  dropoff_stop_id: string | null;
  status: string;
  plate_number?: string | null;
  route_name?: string | null;
  guardians?: { id: string; name: string; email: string }[];
}
export interface TripRow {
  id: string;
  bus_id: string;
  status: string;
  direction: string;
  started_at: string | null;
  ended_at: string | null;
  distance_m: number;
  last_lat: number | null;
  last_lng: number | null;
  last_position_at?: string | null;
  plate_number?: string;
  bus_label?: string;
  driver_name?: string;
  route_name?: string;
  position_count?: number;
}
export interface Notif {
  id: string;
  type: string;
  title: string;
  body: string;
  read_at: string | null;
  created_at: string;
  trip_id: string | null;
  student_id: string | null;
}
export interface Child extends StudentRow {
  route_path?: [number, number][];
  driver_phone?: string | null;
  plate_number: string | null;
  bus_label: string | null;
  driver_name: string | null;
  route_name: string | null;
  pickup_stop: StopRow | null;
  dropoff_stop: StopRow | null;
  active_trip: TripRow | null;
}

const list = <T>(path: string, params?: Record<string, unknown>) => {
  const qs = params
    ? `?${new URLSearchParams(
        Object.entries(params).filter(([, v]) => v != null && v !== '') as [string, string][],
      )}`
    : '';
  return api<Page<T>>(`${path}${qs}`);
};

export function usePage<T>(key: string, path: string, params?: Record<string, unknown>) {
  return useQuery({ queryKey: [key, params], queryFn: () => list<T>(path, params) });
}

export function useEntity<T>(key: string, path: string, id?: string) {
  return useQuery({ queryKey: [key, id], queryFn: () => api<T>(`${path}/${id}`), enabled: !!id });
}

export function useCrud<T>(key: string, path: string) {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: [key] });
  const create = useMutation({
    mutationFn: (body: unknown) => api<T>(path, { method: 'POST', json: body }),
    onSuccess: invalidate,
  });
  const update = useMutation({
    mutationFn: ({ id, body }: { id: string; body: unknown }) =>
      api<T>(`${path}/${id}`, { method: 'PATCH', json: body }),
    onSuccess: invalidate,
  });
  const remove = useMutation({
    mutationFn: (id: string) => api(`${path}/${id}`, { method: 'DELETE' }),
    onSuccess: invalidate,
  });
  return { create, update, remove };
}

export function useMut<TData, TVars>(opts: UseMutationOptions<TData, Error, TVars>) {
  const qc = useQueryClient();
  return useMutation({
    ...opts,
    onSuccess: (...a) => {
      qc.invalidateQueries();
      opts.onSuccess?.(...a);
    },
  });
}

// ── domain hooks ─────────────────────────────────────────────
export const useSummary = () =>
  useQuery({
    queryKey: ['summary'],
    queryFn: () =>
      api<{
        buses: number;
        busesOnTrip: number;
        students: number;
        tripsToday: number;
        notifications7d: number;
        completedTrips: number;
        avgTripMinutes: number;
        totalDistanceKm: number;
      }>('/reports/summary'),
    refetchInterval: 15_000,
  });

export const useActiveTrips = () =>
  useQuery({
    queryKey: ['trips', 'active'],
    queryFn: () => api<TripRow[]>('/trips/active'),
    refetchInterval: 10_000,
  });

export const useNotifications = () =>
  useQuery({ queryKey: ['notifications'], queryFn: () => api<Notif[]>('/me/notifications') });

export const useUnread = () =>
  useQuery({
    queryKey: ['unread'],
    queryFn: () => api<{ count: number }>('/me/notifications/unread-count'),
    refetchInterval: 30_000,
  });

export const useChildren = () =>
  useQuery({
    queryKey: ['children'],
    queryFn: () => api<Child[]>('/me/children'),
    refetchInterval: 20_000,
  });

export const useMyBus = () =>
  useQuery({
    queryKey: ['my-bus'],
    queryFn: () =>
      api<
        Bus & {
          route_name: string | null;
          route_id: string | null;
          active_trip: TripRow | null;
          student_count: number;
        }
      >('/me/bus'),
  });

export const usePrefs = () =>
  useQuery({
    queryKey: ['prefs'],
    queryFn: () => api<Record<string, boolean | string | null>>('/me/preferences'),
  });
