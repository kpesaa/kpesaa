import { useAuth } from './store';

const BASE = '/api/v1';

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

let refreshing: Promise<string | null> | null = null;

async function doRefresh(): Promise<string | null> {
  const { refreshToken, setAccessToken, setSession, clear } = useAuth.getState();
  if (!refreshToken) return null;
  try {
    const res = await fetch(`${BASE}/auth/refresh`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });
    if (!res.ok) {
      clear();
      return null;
    }
    const data = (await res.json()) as { accessToken: string; refreshToken: string; user: never };
    setSession(data);
    setAccessToken(data.accessToken);
    return data.accessToken;
  } catch {
    clear();
    return null;
  }
}

export async function api<T = unknown>(
  path: string,
  opts: RequestInit & { json?: unknown; raw?: boolean } = {},
): Promise<T> {
  const { json, raw, ...init } = opts;
  const headers = new Headers(init.headers);
  if (json !== undefined) {
    headers.set('content-type', 'application/json');
    init.body = JSON.stringify(json);
  }
  const token = useAuth.getState().accessToken;
  if (token) headers.set('authorization', `Bearer ${token}`);

  let res = await fetch(`${BASE}${path}`, { ...init, headers });

  if (res.status === 401 && useAuth.getState().refreshToken) {
    refreshing ??= doRefresh().finally(() => {
      refreshing = null;
    });
    const newToken = await refreshing;
    if (newToken) {
      headers.set('authorization', `Bearer ${newToken}`);
      res = await fetch(`${BASE}${path}`, { ...init, headers });
    }
  }

  if (raw) return res as unknown as T;

  if (res.status === 204) return undefined as T;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiError(
      res.status,
      (body as { error?: string }).error || res.statusText,
      (body as { details?: unknown }).details,
    );
  }
  return body as T;
}

export const apiFetchBlob = (path: string) =>
  api<Response>(path, { raw: true }).then((r) => r.blob());
