import { type ClassValue, clsx } from 'clsx';

export const cn = (...a: ClassValue[]) => clsx(a);

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60_000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export function fmtTime(iso?: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function fmtDateTime(iso?: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function fmtDistance(m: number): string {
  return m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`;
}

export function fmtDuration(minutes?: number | null): string {
  if (minutes == null) return '—';
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  return h ? `${h}h ${m}m` : `${m}m`;
}

export const EVENT_META: Record<string, { icon: string; label: string }> = {
  trip_started: { icon: '🚌', label: 'Trip started' },
  departed_school: { icon: '🏫', label: 'Departed school' },
  approaching_stop: { icon: '📍', label: 'Approaching stop' },
  arrived_stop: { icon: '🚏', label: 'At stop' },
  arrived_school: { icon: '🏫', label: 'Arrived at school' },
  route_deviation: { icon: '⚠️', label: 'Off route' },
  emergency: { icon: '🚨', label: 'Emergency' },
  delay: { icon: '⏰', label: 'Delay' },
  trip_ended: { icon: '✅', label: 'Trip ended' },
};
