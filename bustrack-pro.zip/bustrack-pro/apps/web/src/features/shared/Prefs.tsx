import { useEffect, useState } from 'react';
import { Button, Card, Field, Input, Spinner, useToast } from '../../components/ui';
import { ApiError, api } from '../../lib/api';
import { disablePush, enablePush } from '../../lib/push';
import { usePrefs } from '../../lib/queries';

const TOGGLES: [string, string][] = [
  ['in_app_enabled', 'In-app notifications'],
  ['email_enabled', 'Email'],
  ['web_push_enabled', 'Browser push'],
  ['sms_enabled', 'SMS'],
];

export function PrefsForm() {
  const prefs = usePrefs();
  const toast = useToast();
  const [local, setLocal] = useState<Record<string, unknown>>({});

  useEffect(() => {
    if (prefs.data) setLocal(prefs.data);
  }, [prefs.data]);

  if (prefs.isLoading) return <Spinner className="text-brand-500" />;

  async function save(patch: Record<string, unknown>) {
    const next = { ...local, ...patch };
    setLocal(next);
    await api('/me/preferences', { method: 'PATCH', json: patch }).catch(() =>
      toast('Save failed', 'err'),
    );
    if (patch.web_push_enabled === true) {
      const r = await enablePush();
      if (r !== 'ok') toast(`Push not enabled: ${r}`, 'err');
    }
    if (patch.web_push_enabled === false) await disablePush().catch(() => {});
  }

  return (
    <Card className="p-5">
      <h3 className="mb-3 font-semibold">Notification channels</h3>
      <div className="space-y-2">
        {TOGGLES.map(([key, label]) => (
          <label
            key={key}
            className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm"
          >
            <span>{label}</span>
            <input
              type="checkbox"
              className="h-4 w-4"
              checked={Boolean(local[key])}
              onChange={(e) => save({ [key]: e.target.checked })}
            />
          </label>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <Field label="Quiet hours start">
          <Input
            type="time"
            value={(local.quiet_hours_start as string)?.slice(0, 5) ?? ''}
            onChange={(e) => save({ quiet_hours_start: e.target.value || null })}
          />
        </Field>
        <Field label="Quiet hours end">
          <Input
            type="time"
            value={(local.quiet_hours_end as string)?.slice(0, 5) ?? ''}
            onChange={(e) => save({ quiet_hours_end: e.target.value || null })}
          />
        </Field>
      </div>
      <p className="mt-2 text-xs text-slate-400">
        Emergencies always come through, even during quiet hours.
      </p>
    </Card>
  );
}

export function ChangePasswordForm() {
  const toast = useToast();
  const [cur, setCur] = useState('');
  const [next, setNext] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await api('/auth/change-password', {
        method: 'POST',
        json: { currentPassword: cur, newPassword: next },
      });
      toast('Password changed — sign in again if prompted');
      setCur('');
      setNext('');
    } catch (err) {
      toast(err instanceof ApiError ? err.message : 'Failed', 'err');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="p-5">
      <h3 className="mb-3 font-semibold">Change password</h3>
      <form onSubmit={submit} className="space-y-3">
        <Field label="Current password">
          <Input type="password" value={cur} onChange={(e) => setCur(e.target.value)} required />
        </Field>
        <Field label="New password">
          <Input
            type="password"
            value={next}
            onChange={(e) => setNext(e.target.value)}
            required
            minLength={8}
          />
        </Field>
        <Button type="submit" disabled={busy}>
          {busy ? 'Saving…' : 'Update password'}
        </Button>
      </form>
    </Card>
  );
}
