import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { Badge, Button, Card, EmptyState, Field, Input, PageHeader, Spinner, Table, useToast } from '../../components/ui';
import { ApiError, api } from '../../lib/api';
import { useSocketEvent } from '../../lib/socket';
import { fmtTime } from '../../lib/utils';

interface Handover {
  id: string;
  student_id: string;
  first_name: string;
  last_name: string;
  status: string;
  trip_status?: string;
  expires_at: string;
  verified_at?: string;
  receiver_name?: string;
  receiver_relationship?: string;
  driver_name?: string;
  code?: string;
}
const tone = (s: string) => s === 'verified' ? 'green' : s === 'authorised' ? 'indigo' : ['expired', 'locked', 'revoked'].includes(s) ? 'rose' : 'amber';
const statusLabel = (s: string) => ({ pending: 'Waiting for parent', authorised: 'Ready to verify', verified: 'Handover confirmed', not_requested: 'Code not requested' }[s] ?? s);
const message = (e: unknown) => e instanceof ApiError ? e.message : 'Could not complete this action. Please try again.';

export function ParentHandovers() {
  const q = useQuery({ queryKey: ['handovers', 'mine'], queryFn: () => api<Handover[]>('/handovers/mine'), refetchInterval: 10_000 });
  useSocketEvent('handover:updated', () => q.refetch());
  return <div>
    <PageHeader title="Child handover" subtitle="Choose a trusted adult to receive your child." />
    <Card className="mb-6 flex items-start gap-4 border-blue-100 bg-blue-50/60 p-5">
      <span className="step-dot">01</span><div><h2 className="font-semibold text-slate-900">A clear record of every handover</h2>
      <p className="mt-1 max-w-2xl text-sm leading-6 text-slate-600">When the driver requests a code, name yourself or the adult receiving your child. Share the code privately with that person. The driver checks their name and code before recording the handover.</p></div>
    </Card>
    {q.isLoading ? <Spinner /> : q.error ? <Card className="p-6"><p role="alert">Could not load handovers.</p><Button onClick={() => q.refetch()}>Try again</Button></Card> :
      !q.data?.length ? <Card><EmptyState title="No handover requests yet" hint="Requests appear here during your child's afternoon trip." /></Card> :
      <div className="grid items-start gap-5 xl:grid-cols-2">{q.data.map((h) => <ParentHandoverCard key={h.id} h={h} refresh={() => q.refetch()} />)}</div>}
  </div>;
}

function ParentHandoverCard({ h, refresh }: { h: Handover; refresh: () => void }) {
  const [name, setName] = useState(h.receiver_name ?? '');
  const [relation, setRelation] = useState(h.receiver_relationship ?? '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const toast = useToast();
  useEffect(() => { setName(h.receiver_name ?? ''); setRelation(h.receiver_relationship ?? ''); }, [h.receiver_name, h.receiver_relationship]);
  const open = ['pending', 'authorised'].includes(h.status) && h.trip_status === 'active' && Boolean(h.code);
  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError('');
    try { await api(`/handovers/${h.id}/authorise`, { method: 'POST', json: { receiverName: name, relationship: relation } }); refresh(); toast('Receiving adult authorised'); }
    catch (e) { setError(message(e)); } finally { setBusy(false); }
  }
  async function revoke() {
    if (!confirm('Revoke this code? The driver will need to request a replacement.')) return;
    setBusy(true); setError('');
    try { await api(`/handovers/${h.id}/revoke`, { method: 'POST' }); refresh(); toast('Code revoked'); }
    catch (e) { setError(message(e)); } finally { setBusy(false); }
  }
  return <Card className="overflow-hidden">
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 p-5"><div className="flex items-center gap-3">
      <span className="avatar-tile">{h.first_name[0]}{h.last_name[0]}</span><div><h2 className="font-semibold">{h.first_name} {h.last_name}</h2><p className="text-xs text-slate-500">Afternoon drop-off</p></div></div>
      <Badge tone={tone(h.status)}>{statusLabel(h.status)}</Badge></div>
    <div className="space-y-4 p-5">
      {h.status === 'verified' ? <div className="rounded-xl bg-emerald-50 p-4"><p className="font-semibold text-emerald-900">Received by {h.receiver_name}</p><p className="mt-1 text-sm text-emerald-800">Driver confirmation recorded at {fmtTime(h.verified_at)}.</p></div> : open ? <>
        <form onSubmit={save} className="space-y-3"><Field label="Receiving adult's full name"><Input value={name} onChange={(e) => setName(e.target.value)} minLength={2} maxLength={100} placeholder="e.g. Winnie Lawson" required /></Field>
          <Field label="Relationship to your child"><Input value={relation} onChange={(e) => setRelation(e.target.value)} minLength={2} maxLength={80} placeholder="e.g. Mother, father, aunt or trusted caregiver" required /></Field>
          <Button disabled={busy} type="submit" className="w-full">{busy ? 'Saving…' : h.status === 'authorised' ? 'Update receiving adult' : 'Authorise receiving adult'}</Button>
        </form>
        {h.status === 'authorised' && <div className="rounded-2xl border border-blue-100 bg-blue-50 p-5 text-center"><p className="eyebrow">One-time handover code</p>
          <div className="my-3 font-mono text-4xl font-bold tracking-[.28em] text-slate-900">{h.code}</div>
          <p className="text-xs text-slate-600">Expires at {fmtTime(h.expires_at)} · Works once for this child</p>
          <Button variant="ghost" className="mt-4" onClick={async () => { try { await navigator.clipboard.writeText(`BusTrack handover for ${h.first_name} ${h.last_name}: ${h.code}. Receiving adult: ${h.receiver_name}. Expires at ${fmtTime(h.expires_at)}.`); toast('Code copied. Share it privately.'); } catch { setError('Copy is unavailable. Share the six-digit code privately.'); } }}>Copy for receiving adult</Button>
        </div>}
        <Button variant="ghost" className="w-full text-rose-700" onClick={revoke} disabled={busy}>Revoke this code</Button>
      </> : <p className="text-sm leading-6 text-slate-600">{h.trip_status !== 'active' ? 'This trip has ended. Codes can only be verified during an active trip.' : 'This code cannot be used. Ask the driver to request a new code and contact the school if help is needed.'}</p>}
      {error && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm text-rose-800">{error}</p>}
    </div>
  </Card>;
}

export function DriverHandovers({ tripId }: { tripId: string }) {
  const q = useQuery({ queryKey: ['handovers', tripId], queryFn: () => api<Handover[]>(`/handovers/trips/${tripId}`), refetchInterval: 10_000 });
  useSocketEvent('handover:updated', () => q.refetch());
  return <Card className="mt-5 overflow-hidden"><div className="border-b border-slate-100 p-5"><h2 className="font-semibold">Child handovers</h2>
    <p className="mt-1 text-sm leading-6 text-slate-500">Park before using these controls. Request a code, check the receiving adult, then verify the code they provide.</p></div>
    {q.isLoading ? <div className="p-5"><Spinner /></div> : q.error ? <p role="alert" className="p-5 text-rose-700">Could not load children. Please reconnect and try again.</p> :
      !q.data?.length ? <EmptyState title="No children assigned" /> : <div className="divide-y divide-slate-100">{q.data.map((h) => <DriverHandoverRow key={h.student_id} h={h} tripId={tripId} refresh={() => q.refetch()} />)}</div>}
  </Card>;
}

function DriverHandoverRow({ h, tripId, refresh }: { h: Handover; tripId: string; refresh: () => void }) {
  const [code, setCode] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function request() {
    setBusy(true); setError('');
    try { await api(`/handovers/trips/${tripId}/request`, { method: 'POST', json: { studentId: h.student_id } }); refresh(); }
    catch (e) { setError(message(e)); } finally { setBusy(false); }
  }
  async function verify(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError('');
    try { await api(`/handovers/${h.id}/verify`, { method: 'POST', json: { code, receiverConfirmed: confirmed } }); setCode(''); setConfirmed(false); refresh(); }
    catch (e) { setError(message(e)); refresh(); } finally { setBusy(false); }
  }
  return <div className="space-y-3 p-5"><div className="flex flex-wrap items-center justify-between gap-2"><p className="font-semibold">{h.first_name} {h.last_name}</p><Badge tone={tone(h.status)}>{statusLabel(h.status)}</Badge></div>
    {['not_requested', 'expired', 'revoked', 'locked'].includes(h.status) && <Button variant="ghost" onClick={request} disabled={busy} className="w-full">{busy ? 'Requesting…' : 'Request code from parent'}</Button>}
    {h.status === 'pending' && <p className="text-sm text-slate-600">The linked parent needs to authorise a receiving adult. Keep the handover unconfirmed until verification succeeds.</p>}
    {h.status === 'authorised' && <form onSubmit={verify} className="space-y-3"><div className="rounded-xl bg-blue-50 p-3"><p className="eyebrow">Authorised receiving adult</p><p className="mt-1 font-semibold">{h.receiver_name}</p><p className="text-sm text-slate-600">{h.receiver_relationship}</p></div>
      <Field label="Six-digit code supplied by receiver"><Input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} placeholder="000000" required /></Field>
      <label className="flex items-start gap-3 text-sm leading-6"><input className="mt-1 h-5 w-5" type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} /><span>I have checked the adult present against the parent's nominated receiver.</span></label>
      <Button disabled={busy || !confirmed || code.length !== 6} className="w-full" type="submit">{busy ? 'Verifying…' : 'Verify and confirm handover'}</Button>
    </form>}
    {h.status === 'verified' && <p className="text-sm text-emerald-800">Confirmed at {fmtTime(h.verified_at)} · {h.receiver_name}</p>}
    {error && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm text-rose-800">{error}</p>}
  </div>;
}

export function AdminHandovers() {
  const q = useQuery({ queryKey: ['handovers', 'school'], queryFn: () => api<Handover[]>('/handovers/school'), refetchInterval: 15_000 });
  useSocketEvent('handover:updated', () => q.refetch());
  return <div><PageHeader title="Handover records" subtitle="Recent requests and confirmed child handovers. Secret codes are visible only to linked guardians." />
    <Card className="overflow-hidden">{q.isLoading ? <div className="p-6"><Spinner /></div> : q.error ? <p role="alert" className="p-6 text-rose-700">Could not load handover records.</p> : <Table rows={q.data ?? []} columns={[
      { key: 'child', header: 'Child', render: (h) => `${h.first_name} ${h.last_name}` },
      { key: 'status', header: 'Status', render: (h) => <Badge tone={tone(h.status)}>{statusLabel(h.status)}</Badge> },
      { key: 'receiver_name', header: 'Receiving adult' }, { key: 'driver_name', header: 'Driver' },
      { key: 'verified_at', header: 'Confirmed', render: (h) => h.verified_at ? fmtTime(h.verified_at) : 'Awaiting confirmation' },
    ]} />}</Card></div>;
}
