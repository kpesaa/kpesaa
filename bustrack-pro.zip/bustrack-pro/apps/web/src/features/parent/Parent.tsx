import { Link } from 'react-router-dom';
import { Icon } from '../../components/Icon';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useState } from 'react';
import { LiveMap } from '../../components/maps';
import { Badge, Card, PageHeader, Spinner } from '../../components/ui';
import { api } from '../../lib/api';
import { type Child, useChildren, useNotifications } from '../../lib/queries';
import { getSocket, useSocketEvent } from '../../lib/socket';
import { fmtDistance, fmtTime } from '../../lib/utils';

interface LivePos {
  tripId: string;
  busId: string;
  lat: number;
  lng: number;
  speedKph: number;
  recordedAt: string;
}

export function ParentHome() {
  const children = useChildren();
  const notifications = useNotifications();
  const school = useQuery({
    queryKey: ['my-school'],
    queryFn: () =>
      api<{ lat: number; lng: number; name: string; radius_m: number; contact_phone?: string } | null>('/me/school'),
  });
  const [selected, setSelected] = useState<string | null>(null);
  const [pos, setPos] = useState<Record<string, LivePos>>({});

  const kids = children.data ?? [];
  const child = useMemo(() => kids.find((k) => k.id === selected) ?? kids[0], [kids, selected]);

  useEffect(() => {
    const s = getSocket();
    if (!s || !child?.bus_id) return;
    const watch = () => s.emit('watch:bus', child.bus_id);
    watch();
    s.on('connect', watch);
    return () => {
      s.off('connect', watch);
      s.emit('unwatch:bus', child.bus_id!);
    };
  }, [child?.bus_id]);

  useSocketEvent<LivePos>('bus:position', (p) => setPos((m) => ({ ...m, [p.busId]: p })));
  useSocketEvent('trip:event', () => children.refetch());

  if (children.isLoading) return <Spinner className="text-brand-500" />;
  if (!kids.length)
    return (
      <div>
        <PageHeader title="Live tracking" />
        <Card className="p-10 text-center text-slate-400">
          No children are linked to your account yet.
        </Card>
      </div>
    );

  const liveCandidate = child?.bus_id ? pos[child.bus_id] : undefined;
  const busPos = liveCandidate?.tripId === child?.active_trip?.id ? liveCandidate : undefined;
  const onTrip = Boolean(child?.active_trip);
  const busPoint = !onTrip ? null : busPos
    ? { lat: busPos.lat, lng: busPos.lng, label: child?.bus_label ?? child?.plate_number ?? 'Bus' }
    : child?.active_trip?.last_lat != null
      ? {
          lat: child.active_trip.last_lat,
          lng: child.active_trip.last_lng!,
          label: child.plate_number ?? 'Bus',
        }
      : null;

  const stops = [child?.pickup_stop, child?.dropoff_stop]
    .filter(Boolean)
    .map((s) => ({ id: s!.id, name: s!.name, lat: s!.lat, lng: s!.lng, radius_m: s!.radius_m }))
    .filter((s, i, arr) => arr.findIndex((x) => x.id === s.id) === i);

  const lastPing = busPos?.recordedAt ?? child?.active_trip?.last_position_at;
  const stale = onTrip && (!lastPing || Date.now() - new Date(lastPing).getTime() > 30_000);
  const recent = (notifications.data ?? []).filter((n) => !n.student_id || n.student_id === child?.id).slice(0, 4);
  return (
    <div>
      <PageHeader title="Your child's journey" subtitle="Live bus updates and a clear handover record." actions={<Link to="/parent/handovers" className="btn-primary"><Icon name="shield" size={18} />Manage handover</Link>} />
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-[#102035] p-5 text-white sm:p-6"><div><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-blue-200">{onTrip ? 'Journey in progress' : 'Between journeys'}</p><h2 className="mt-2 text-xl font-semibold">{onTrip ? `${child?.first_name}'s bus trip is active` : 'No active bus trip right now'}</h2><p className="mt-2 text-sm text-slate-300">{onTrip ? 'Bus location is separate from child handover confirmation.' : 'The map will update when the driver starts the next trip.'}</p></div><Badge tone={stale ? 'amber' : onTrip ? 'green' : 'slate'}>{stale ? 'Location delayed' : onTrip ? 'Trip active' : 'Idle'}</Badge></div>

      {kids.length > 1 && (
        <div className="mb-4 flex gap-2">
          {kids.map((k) => (
            <button
              key={k.id}
              onClick={() => setSelected(k.id)}
              className={`rounded-lg px-3 py-1.5 text-sm font-medium ${
                k.id === child?.id
                  ? 'bg-brand-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              {k.first_name}
            </button>
          ))}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="overflow-hidden lg:col-span-2">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4"><h2 className="section-title">Live bus map</h2><span className="text-xs text-slate-500">{child?.route_name ?? 'Route not assigned'}</span></div><div className="h-[350px] sm:h-[440px]">
            <LiveMap school={school.data ?? undefined} bus={busPoint} stops={stops} path={child?.route_path ?? []} follow />
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-lg font-bold text-slate-900">
                  {child?.first_name} {child?.last_name}
                </div>
                <div className="text-sm text-slate-500">
                  {child?.grade} · Bus {child?.plate_number ?? '—'}
                </div>
              </div>
              <Badge tone={onTrip ? 'green' : 'slate'}>{onTrip ? 'Trip active' : 'Idle'}</Badge>
            </div>
            {stale && <p className="mt-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">The last position is delayed. Contact the school if you need an update.</p>}
            {onTrip && (
              <div className="mt-3 grid grid-cols-2 gap-3 rounded-lg bg-slate-50 p-3 text-sm">
                <div>
                  <div className="text-xs uppercase text-slate-400">Speed</div>
                  <div className="font-semibold">
                    {busPos ? `${Math.round(busPos.speedKph)} km/h` : '—'}
                  </div>
                </div>
                <div>
                  <div className="text-xs uppercase text-slate-400">Last ping</div>
                  <div className="font-semibold">
                    {fmtTime(lastPing)}
                  </div>
                </div>
                <div>
                  <div className="text-xs uppercase text-slate-400">Distance</div>
                  <div className="font-semibold">
                    {fmtDistance(child?.active_trip?.distance_m ?? 0)}
                  </div>
                </div>
                <div>
                  <div className="text-xs uppercase text-slate-400">Driver</div>
                  <div className="font-semibold">{child?.driver_name ?? '—'}</div>
                </div>
              </div>
            )}
          </Card>

          <Card className="p-4">
            <h3 className="mb-2 text-sm font-semibold">Stops</h3>
            {stops.length ? (
              stops.map((s) => (
                <div key={s.id} className="flex items-center gap-2 py-1 text-sm">
                  <Icon name="pin" size={16} /><span>{s.name}</span>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-400">No stops configured.</p>
            )}
          </Card>
          <Card className="p-5"><div className="mb-4 flex items-center justify-between"><h3 className="section-title">Recent updates</h3><Link className="text-xs font-semibold text-blue-600" to="/parent/notifications">View all</Link></div>{recent.length ? recent.map((n) => <div key={n.id} className="relative border-l border-slate-200 pb-4 pl-4"><span className="absolute -left-1 top-1 h-2 w-2 rounded-full bg-blue-500"/><p className="text-sm font-semibold">{n.title}</p><p className="mt-1 text-xs leading-5 text-slate-500">{n.body}</p></div>) : <p className="text-sm text-slate-500">Trip alerts will appear here.</p>}</Card>
          {school.data?.contact_phone && <a className="btn-ghost w-full" href={`tel:${school.data.contact_phone}`}>Contact school</a>}
        </div>
      </div>
    </div>
  );
}
