import { useQuery } from '@tanstack/react-query';
import { Badge, Card, EmptyState, PageHeader, Spinner } from '../../components/ui';
import { api } from '../../lib/api';
import type { TripRow } from '../../lib/queries';
import { fmtDistance, fmtTime } from '../../lib/utils';

export function ParentHistory() {
  const q = useQuery({ queryKey: ['parent-history'], queryFn: () => api<TripRow[]>('/me/history') });
  return <div><PageHeader title="Trip history" subtitle="Recent bus journeys associated with your children's current bus assignments." />
    {q.isLoading ? <Spinner /> : q.error ? <p role="alert">Could not load trip history.</p> : !q.data?.length ? <Card><EmptyState title="No past trips yet" hint="Completed journeys will appear here." /></Card> :
      <div className="grid gap-4 lg:grid-cols-2">{q.data.map((t) => <Card key={t.id} className="p-5"><div className="flex justify-between gap-3"><div><p className="eyebrow">{new Date(t.started_at!).toLocaleDateString('en-NG', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}</p>
        <h2 className="mt-1 font-semibold">{t.direction === 'from_school' ? 'Afternoon drop-off' : 'Morning pickup'} · {t.plate_number}</h2></div><Badge tone={t.status === 'completed' ? 'green' : 'amber'}>{t.status}</Badge></div>
        <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-slate-50 p-3 text-sm"><div><p className="text-xs text-slate-500">Started</p><p className="font-medium">{fmtTime(t.started_at)}</p></div><div><p className="text-xs text-slate-500">Ended</p><p className="font-medium">{fmtTime(t.ended_at)}</p></div><div><p className="text-xs text-slate-500">Distance</p><p className="font-medium">{fmtDistance(t.distance_m)}</p></div></div>
        <p className="mt-3 text-sm text-slate-600">Driver: {t.driver_name}</p></Card>)}</div>}</div>;
}
