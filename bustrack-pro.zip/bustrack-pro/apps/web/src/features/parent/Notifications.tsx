import { Icon } from '../../components/Icon';
import { Button, Card, EmptyState, PageHeader, Spinner } from '../../components/ui';
import { api } from '../../lib/api';
import { useNotifications, useUnread } from '../../lib/queries';
import { useSocketEvent } from '../../lib/socket';
import { timeAgo } from '../../lib/utils';

export function ParentNotifications() {
  const notifs = useNotifications();
  const unread = useUnread();

  useSocketEvent('notification:new', () => {
    notifs.refetch();
    unread.refetch();
  });

  async function markAll() {
    await api('/me/notifications/read-all', { method: 'POST' });
    notifs.refetch();
    unread.refetch();
  }

  const list = notifs.data ?? [];

  return (
    <div>
      <PageHeader
        title="Notifications"
        subtitle={`${unread.data?.count ?? 0} unread`}
        actions={
          list.some((n) => !n.read_at) ? (
            <Button variant="ghost" onClick={markAll}>
              Mark all read
            </Button>
          ) : undefined
        }
      />
      <Card className="divide-y divide-slate-100">
        {notifs.isLoading ? (
          <div className="flex justify-center py-16">
            <Spinner className="text-brand-500" />
          </div>
        ) : list.length === 0 ? (
          <EmptyState
            icon="🔔"
            title="No notifications yet"
            hint="Alerts appear here when a bus is on the move."
          />
        ) : (
          list.map((n) => (
            <div key={n.id} className={`flex gap-3 p-4 ${n.read_at ? '' : 'bg-brand-50/40'}`}>
              <span className="avatar-tile"><Icon name={n.type === 'emergency' ? 'shield' : 'bell'} /></span>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-800">{n.title}</span>
                  {!n.read_at && <span className="h-2 w-2 rounded-full bg-brand-500" />}
                </div>
                <p className="text-sm text-slate-600">{n.body}</p>
                <span className="text-xs text-slate-400">{timeAgo(n.created_at)}</span>
              </div>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}
