import { PageHeader } from '../../components/ui';
import { ChangePasswordForm, PrefsForm } from '../shared/Prefs';

export function ParentSettings() {
  return (
    <div>
      <PageHeader title="Settings" subtitle="How and when we reach you" />
      <div className="grid gap-5 lg:grid-cols-2">
        <PrefsForm />
        <ChangePasswordForm />
      </div>
    </div>
  );
}
