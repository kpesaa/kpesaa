import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { LiveMap } from '../../components/maps';
import { Badge, Card, PageHeader, Spinner } from '../../components/ui';
import { api } from '../../lib/api';
import { useActiveTrips, useSummary } from '../../lib/queries';
import { useSocketEvent } from '../../lib/socket';
import { fmtDistance } from '../../lib/utils';

interface LivePos {
  tripId: string;
  busId: string;
  lat: number;
  lng: number;
  speedKph: number;
}

export function AdminDashboard() {
  const summary = useSummary();
  const trips = useActiveTrips();
  const school = useQuery({
    queryKey: ['my-school'],
    queryFn: () =>
      api<{ lat: number; lng: number; name: string; radius_m: number } | null>('/me/school'),
  });
  const [positions, setPositions] = useState<Record<string, LivePos>>({});

  useSocketEvent<LivePos>('bus:position', (p) => setPositions((s) => ({ ...s, [p.busId]: p })));
  useSocketEvent('trip:ended', () => trips.refetch());
  useSocketEvent('trip:started', () => trips.refetch());

  const s = summary.data;
  const tiles = [
    { label: 'Buses on a trip', value: s?.busesOnTrip, of: s?.buses },
    { label: 'Active students', value: s?.students },
    { label: 'Trips today', value: s?.tripsToday },
    { label: 'Notifications (7d)', value: s?.notifications7d },
  ];

  const activeTrips = trips.data ?? [];
  const fleet = activeTrips.flatMap((t) => {
    const p = positions[t.bus_id];
    return p || t.last_lat != null ? [{ id: t.bus_id, lat: p?.lat ?? t.last_lat!, lng: p?.lng ?? t.last_lng!, label: t.bus_label ?? t.plate_number }] : [];
  });

  return (
    <div>
      <PageHeader title="Fleet overview" subtitle="Your transport operation, at a glance." actions={<Link to="/admin/handovers" className="btn-ghost">View handover records</Link>} />

      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tiles.map((t) => (
          <Card key={t.label} className="p-5 sm:p-6">
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              {t.label}
            </div>
            <div className="mt-3 text-4xl font-bold tracking-tight text-slate-900">
              {t.value ?? <Spinner />}
              {t.of != null && <span className="text-lg text-slate-400"> / {t.of}</span>}
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="overflow-hidden lg:col-span-2">
          <div className="border-b border-slate-200 px-4 py-2.5 text-sm font-semibold">
            Live fleet map · {fleet.length} buses located
          </div>
          <div className="h-[420px]">
            <LiveMap
              school={school.data ?? undefined}
              buses={fleet}
              follow={false}
            />
          </div>
        </Card>

        <Card className="overflow-hidden">
          <div className="border-b border-slate-200 px-4 py-2.5 text-sm font-semibold">
            Active trips ({activeTrips.length})
          </div>
          <div className="divide-y divide-slate-100">
            {activeTrips.length === 0 && (
              <p className="p-4 text-sm text-slate-400">No trips running right now.</p>
            )}
            {activeTrips.map((t) => {
              const pos = positions[t.bus_id];
              return (
                <Link
                  key={t.id}
                  to={`/admin/trips/${t.id}`}
                  className="block px-4 py-3 hover:bg-slate-50"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800">
                      {t.plate_number ?? t.bus_label}
                    </span>
                    <Badge tone="green">live</Badge>
                  </div>
                  <div className="text-xs text-slate-500">
                    {t.driver_name} · {t.route_name ?? 'no route'} ·{' '}
                    {pos ? `${Math.round(pos.speedKph)} km/h` : `${fmtDistance(t.distance_m)}`}
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}
