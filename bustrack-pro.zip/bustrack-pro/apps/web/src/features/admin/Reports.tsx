import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Button, Card, Field, Input, PageHeader, Spinner, Table } from '../../components/ui';
import { api, apiFetchBlob } from '../../lib/api';
import { useSummary } from '../../lib/queries';
import { fmtDateTime } from '../../lib/utils';

interface Row {
  id: string;
  plate_number: string;
  driver_name: string;
  route_name: string | null;
  direction: string;
  started_at: string;
  duration_minutes: string;
  distance_km: string;
  gps_points: string;
  deviations: string;
}

export function Reports() {
  const summary = useSummary();
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const trips = useQuery({
    queryKey: ['report-trips', from, to],
    queryFn: () =>
      api<{ data: Row[]; total: number }>(
        `/reports/trips${from || to ? `?${new URLSearchParams({ ...(from && { from }), ...(to && { to }) })}` : ''}`,
      ),
  });

  async function exportCsv() {
    const params = new URLSearchParams({ format: 'csv', ...(from && { from }), ...(to && { to }) });
    const blob = await apiFetchBlob(`/reports/trips?${params}`);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bustrack-trips.csv';
    a.click();
    URL.revokeObjectURL(url);
  }

  const s = summary.data;

  return (
    <div>
      <PageHeader
        title="Reports"
        subtitle="Completed-trip analytics"
        actions={<Button onClick={exportCsv}>⬇ Export CSV</Button>}
      />

      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          ['Completed trips', s?.completedTrips],
          ['Avg trip time', s ? `${s.avgTripMinutes} min` : undefined],
          ['Total distance', s ? `${s.totalDistanceKm} km` : undefined],
          ['Trips today', s?.tripsToday],
        ].map(([label, value]) => (
          <Card key={label} className="p-4">
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              {label}
            </div>
            <div className="mt-1 text-2xl font-bold text-slate-900">{value ?? <Spinner />}</div>
          </Card>
        ))}
      </div>

      <Card className="p-4">
        <div className="mb-4 flex flex-wrap items-end gap-3">
          <Field label="From">
            <Input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="input w-44"
            />
          </Field>
          <Field label="To">
            <Input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="input w-44"
            />
          </Field>
        </div>
        {trips.isLoading ? (
          <div className="flex justify-center py-10">
            <Spinner className="text-brand-500" />
          </div>
        ) : (
          <Table
            columns={[
              { key: 'plate_number', header: 'Bus' },
              { key: 'driver_name', header: 'Driver' },
              { key: 'route_name', header: 'Route', render: (r: Row) => r.route_name ?? '—' },
              {
                key: 'direction',
                header: 'Direction',
                render: (r: Row) => r.direction.replace('_', ' '),
              },
              {
                key: 'started_at',
                header: 'Started',
                render: (r: Row) => fmtDateTime(r.started_at),
              },
              { key: 'duration_minutes', header: 'Minutes' },
              { key: 'distance_km', header: 'Km' },
              { key: 'gps_points', header: 'GPS pts' },
              { key: 'deviations', header: 'Deviations' },
            ]}
            rows={trips.data?.data ?? []}
          />
        )}
      </Card>
    </div>
  );
}
