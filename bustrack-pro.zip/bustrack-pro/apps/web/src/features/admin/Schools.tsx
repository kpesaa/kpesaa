import { CrudPage } from '../../components/CrudPage';
import { Badge } from '../../components/ui';

interface SchoolRow {
  id: string;
  name: string;
  slug: string;
  timezone: string;
  lat: number;
  lng: number;
  radius_m: number;
  active: boolean;
}

export function Schools() {
  return (
    <CrudPage<SchoolRow>
      title="Schools"
      subtitle="Tenants on the platform"
      path="/schools"
      queryKey="schools"
      columns={[
        { key: 'name', header: 'Name' },
        { key: 'slug', header: 'Slug' },
        { key: 'timezone', header: 'Timezone' },
        { key: 'radius_m', header: 'Geofence', render: (s) => `${s.radius_m} m` },
        {
          key: 'active',
          header: 'Active',
          render: (s) => (
            <Badge tone={s.active ? 'green' : 'rose'}>{s.active ? 'active' : 'inactive'}</Badge>
          ),
        },
      ]}
      fields={[
        { name: 'name', label: 'School name', required: true },
        {
          name: 'slug',
          label: 'Slug',
          required: true,
          createOnly: true,
          help: 'lowercase-with-dashes',
        },
        { name: 'timezone', label: 'Timezone', default: 'Africa/Lagos' },
        { name: 'address', label: 'Address' },
        { name: 'lat', label: 'Latitude', type: 'number', required: true },
        { name: 'lng', label: 'Longitude', type: 'number', required: true },
        { name: 'radius_m', label: 'Geofence radius (m)', type: 'number', default: 250 },
        { name: 'contact_phone', label: 'Contact phone', type: 'tel' },
        { name: 'active', label: 'Active', type: 'checkbox', default: true },
      ]}
    />
  );
}
