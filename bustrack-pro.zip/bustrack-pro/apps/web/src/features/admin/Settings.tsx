import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { Button, Card, Field, Input, PageHeader, Spinner, useToast } from '../../components/ui';
import { api } from '../../lib/api';
import { useAuth } from '../../lib/store';
import { ChangePasswordForm, PrefsForm } from '../shared/Prefs';

export function Settings() {
  const { user } = useAuth();
  const canEditSchool = user?.role === 'admin' || user?.role === 'super_admin';
  const toast = useToast();
  const school = useQuery({
    queryKey: ['my-school'],
    queryFn: () => api<Record<string, unknown> | null>('/me/school'),
  });
  const [form, setForm] = useState<Record<string, unknown>>({});

  useEffect(() => {
    if (school.data) setForm(school.data);
  }, [school.data]);

  async function saveSchool(e: React.FormEvent) {
    e.preventDefault();
    await api(`/schools/${school.data!.id}`, {
      method: 'PATCH',
      json: {
        name: form.name,
        address: form.address,
        lat: Number(form.lat),
        lng: Number(form.lng),
        radius_m: Number(form.radius_m),
        contact_phone: form.contact_phone,
      },
    });
    toast('School updated');
    school.refetch();
  }

  return (
    <div>
      <PageHeader title="Settings" />
      <div className="grid gap-5 lg:grid-cols-2">
        {canEditSchool && school.data && (
          <Card className="p-5">
            <h3 className="mb-3 font-semibold">School</h3>
            {school.isLoading ? (
              <Spinner />
            ) : (
              <form onSubmit={saveSchool} className="space-y-3">
                <Field label="Name">
                  <Input
                    value={String(form.name ?? '')}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                </Field>
                <Field label="Address">
                  <Input
                    value={String(form.address ?? '')}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                  />
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Latitude">
                    <Input
                      value={String(form.lat ?? '')}
                      onChange={(e) => setForm({ ...form, lat: e.target.value })}
                    />
                  </Field>
                  <Field label="Longitude">
                    <Input
                      value={String(form.lng ?? '')}
                      onChange={(e) => setForm({ ...form, lng: e.target.value })}
                    />
                  </Field>
                </div>
                <Field label="Geofence radius (m)">
                  <Input
                    value={String(form.radius_m ?? '')}
                    onChange={(e) => setForm({ ...form, radius_m: e.target.value })}
                  />
                </Field>
                <Field label="Contact phone">
                  <Input
                    value={String(form.contact_phone ?? '')}
                    onChange={(e) => setForm({ ...form, contact_phone: e.target.value })}
                  />
                </Field>
                <Button type="submit">Save school</Button>
              </form>
            )}
          </Card>
        )}
        <PrefsForm />
        <ChangePasswordForm />
      </div>
    </div>
  );
}
