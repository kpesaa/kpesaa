import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { CrudPage } from '../../components/CrudPage';
import { Badge } from '../../components/ui';
import { api } from '../../lib/api';
import {
  type Bus,
  type RouteRow,
  type StopRow,
  type StudentRow,
  type UserRow,
  usePage,
} from '../../lib/queries';

const useOpts = (path: string, map: (x: never) => { value: string; label: string }) => {
  const sep = path.includes('?') ? '&' : '?';
  const q = useQuery({
    queryKey: ['opts', path],
    queryFn: () => api<{ data: never[] }>(`${path}${sep}pageSize=200`),
  });
  return () => (q.data?.data ?? []).map(map);
};

const statusBadge = (s: string) => {
  const tone =
    s === 'active'
      ? 'green'
      : s === 'maintenance'
        ? 'amber'
        : s === 'disabled' || s === 'inactive'
          ? 'rose'
          : 'slate';
  return <Badge tone={tone}>{s}</Badge>;
};

// ── Buses ────────────────────────────────────────────────────
export function Buses() {
  const driverOpts = useOpts('/users?role=driver', (u: UserRow) => ({
    value: u.id,
    label: u.name,
  }));
  return (
    <CrudPage<Bus>
      title="Buses"
      subtitle="Your vehicle fleet"
      path="/buses"
      queryKey="buses"
      columns={[
        { key: 'plate_number', header: 'Plate' },
        { key: 'label', header: 'Label' },
        { key: 'model', header: 'Model' },
        { key: 'capacity', header: 'Seats' },
        { key: 'status', header: 'Status', render: (b) => statusBadge(b.status) },
      ]}
      fields={[
        { name: 'plate_number', label: 'Plate number', required: true },
        { name: 'label', label: 'Label', placeholder: 'e.g. Bus 1' },
        { name: 'model', label: 'Model' },
        { name: 'capacity', label: 'Capacity', type: 'number', default: 30 },
        { name: 'driver_id', label: 'Assigned driver', type: 'select', options: driverOpts },
        {
          name: 'status',
          label: 'Status',
          type: 'select',
          default: 'active',
          options: [
            { value: 'active', label: 'Active' },
            { value: 'inactive', label: 'Inactive' },
            { value: 'maintenance', label: 'Maintenance' },
          ],
        },
      ]}
    />
  );
}

// ── Drivers / Parents / Staff (users) ────────────────────────
function UsersPage({ userRole, title }: { userRole: string; title: string }) {
  return (
    <CrudPage<UserRow & { tempPassword?: string }>
      title={title}
      path="/users"
      queryKey={`users-${userRole}`}
      params={{ role: userRole }}
      columns={[
        { key: 'name', header: 'Name' },
        { key: 'email', header: 'Email' },
        { key: 'phone', header: 'Phone' },
        { key: 'status', header: 'Status', render: (u) => statusBadge(u.status) },
      ]}
      fields={[
        { name: 'name', label: 'Full name', required: true },
        { name: 'email', label: 'Email', type: 'email', required: true, createOnly: true },
        { name: 'phone', label: 'Phone', type: 'tel', placeholder: '+234…' },
        { name: 'role', label: 'Role', type: 'hidden', default: userRole },
        {
          name: 'password',
          label: 'Password',
          help: 'Leave blank to auto-generate a temporary password',
        },
        {
          name: 'status',
          label: 'Status',
          type: 'select',
          default: 'active',
          options: [
            { value: 'active', label: 'Active' },
            { value: 'invited', label: 'Invited' },
            { value: 'disabled', label: 'Disabled' },
          ],
        },
      ]}
    />
  );
}
export const Drivers = () => <UsersPage userRole="driver" title="Drivers" />;
export const Parents = () => <UsersPage userRole="parent" title="Parents" />;
export const Staff = () => <UsersPage userRole="dispatcher" title="Staff" />;

// ── Routes ───────────────────────────────────────────────────
export function Routes() {
  return (
    <CrudPage<RouteRow>
      title="Routes"
      subtitle="Planned paths and stops"
      path="/routes"
      queryKey="routes"
      columns={[
        { key: 'name', header: 'Name' },
        {
          key: 'length_m',
          header: 'Length',
          render: (r) => (r.length_m ? `${(r.length_m / 1000).toFixed(1)} km` : '—'),
        },
        {
          key: 'active',
          header: 'Active',
          render: (r) => statusBadge(r.active ? 'active' : 'inactive'),
        },
      ]}
      extraRowActions={(r) => (
        <Link
          to={`/admin/routes/${r.id}`}
          className="text-xs font-semibold text-slate-600 hover:underline"
        >
          Map
        </Link>
      )}
      fields={[
        { name: 'name', label: 'Route name', required: true },
        { name: 'description', label: 'Description' },
        { name: 'active', label: 'Active', type: 'checkbox', default: true },
      ]}
    />
  );
}

// ── Students ─────────────────────────────────────────────────
export function Students() {
  const busOpts = useOpts('/buses', (b: Bus) => ({ value: b.id, label: b.plate_number }));
  const routeOpts = useOpts('/routes', (r: RouteRow) => ({ value: r.id, label: r.name }));
  const parentOpts = useOpts('/users?role=parent', (u: UserRow) => ({
    value: u.id,
    label: u.name,
  }));
  const stops = usePage<StopRow>('all-stops', '/routes', { pageSize: 200 });
  const stopOpts = () =>
    (stops.data?.data as unknown as RouteRow[] | undefined)?.flatMap((r) =>
      (r.stops ?? []).map((s) => ({ value: s.id, label: `${r.name} · ${s.name}` })),
    ) ?? [];

  return (
    <CrudPage<StudentRow>
      title="Students"
      path="/students"
      queryKey="students"
      columns={[
        { key: 'name', header: 'Name', render: (s) => `${s.first_name} ${s.last_name}` },
        { key: 'grade', header: 'Grade' },
        { key: 'bus', header: 'Bus', render: (s) => s.plate_number ?? '—' },
        {
          key: 'guardians',
          header: 'Guardians',
          render: (s) => (s.guardians ?? []).map((g) => g.name).join(', ') || '—',
        },
        { key: 'status', header: 'Status', render: (s) => statusBadge(s.status) },
      ]}
      toForm={(s) => ({ ...s, guardian_ids: (s.guardians ?? []).map((g) => g.id) })}
      fields={[
        { name: 'first_name', label: 'First name', required: true },
        { name: 'last_name', label: 'Last name', required: true },
        { name: 'grade', label: 'Grade / class' },
        { name: 'route_id', label: 'Route', type: 'select', options: routeOpts },
        { name: 'bus_id', label: 'Bus', type: 'select', options: busOpts },
        { name: 'pickup_stop_id', label: 'Pickup stop', type: 'select', options: stopOpts },
        { name: 'dropoff_stop_id', label: 'Drop-off stop', type: 'select', options: stopOpts },
        {
          name: 'guardian_ids',
          label: 'Guardians (parents)',
          type: 'multiselect',
          options: parentOpts,
        },
        {
          name: 'status',
          label: 'Status',
          type: 'select',
          default: 'active',
          options: [
            { value: 'active', label: 'Active' },
            { value: 'inactive', label: 'Inactive' },
          ],
        },
      ]}
    />
  );
}
