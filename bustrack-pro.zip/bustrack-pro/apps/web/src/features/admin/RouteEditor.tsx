import { useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { RouteEditorMap } from '../../components/maps';
import {
  Button,
  Card,
  Field,
  Input,
  PageHeader,
  Select,
  Spinner,
  useToast,
} from '../../components/ui';
import { api } from '../../lib/api';
import { type RouteRow, type StopRow, useEntity } from '../../lib/queries';

export function RouteEditor() {
  const { id } = useParams<{ id: string }>();
  const route = useEntity<RouteRow>('route', '/routes', id);
  const qc = useQueryClient();
  const toast = useToast();
  const [path, setPath] = useState<[number, number][]>([]);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    if (route.data) setPath(route.data.path ?? []);
  }, [route.data]);

  if (route.isLoading || !route.data) return <Spinner className="text-brand-500" />;
  const stops = route.data.stops ?? [];

  async function savePath() {
    await api(`/routes/${id}`, { method: 'PATCH', json: { path } });
    setDirty(false);
    toast('Route path saved');
    qc.invalidateQueries({ queryKey: ['route', id] });
    qc.invalidateQueries({ queryKey: ['routes'] });
  }

  return (
    <div>
      <PageHeader
        title={`Route: ${route.data.name}`}
        subtitle="Click the map to add path points · click a point to remove it"
        actions={
          <div className="flex gap-2">
            <Link to="/admin/routes" className="btn-ghost">
              Back
            </Link>
            <Button onClick={savePath} disabled={!dirty}>
              Save path ({path.length} pts)
            </Button>
          </div>
        }
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="overflow-hidden lg:col-span-2">
          <RouteEditorMap
            path={path}
            onChange={(p) => {
              setPath(p);
              setDirty(true);
            }}
            stops={stops.map((s) => ({
              id: s.id,
              name: s.name,
              lat: s.lat,
              lng: s.lng,
              radius_m: s.radius_m,
            }))}
            height={520}
          />
        </Card>
        <StopsPanel
          routeId={id!}
          stops={stops}
          onChange={() => qc.invalidateQueries({ queryKey: ['route', id] })}
        />
      </div>
    </div>
  );
}

function StopsPanel({
  routeId,
  stops,
  onChange,
}: {
  routeId: string;
  stops: StopRow[];
  onChange: () => void;
}) {
  const toast = useToast();
  const [form, setForm] = useState({ name: '', lat: '', lng: '', kind: 'both', radius_m: '150' });

  async function add(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api(`/routes/${routeId}/stops`, {
        method: 'POST',
        json: {
          name: form.name,
          lat: Number(form.lat),
          lng: Number(form.lng),
          kind: form.kind,
          radius_m: Number(form.radius_m),
          sequence: stops.length + 1,
        },
      });
      setForm({ name: '', lat: '', lng: '', kind: 'both', radius_m: '150' });
      toast('Stop added');
      onChange();
    } catch {
      toast('Could not add stop', 'err');
    }
  }

  async function del(sid: string) {
    await api(`/routes/${routeId}/stops/${sid}`, { method: 'DELETE' });
    toast('Stop removed');
    onChange();
  }

  return (
    <Card className="p-4">
      <h3 className="mb-3 font-semibold">Stops ({stops.length})</h3>
      <div className="mb-4 space-y-2">
        {stops.map((s) => (
          <div
            key={s.id}
            className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm"
          >
            <div>
              <div className="font-medium">{s.name}</div>
              <div className="text-xs text-slate-400">
                {s.kind} · {s.radius_m} m · {s.lat.toFixed(4)}, {s.lng.toFixed(4)}
              </div>
            </div>
            <button
              className="text-xs font-semibold text-rose-600 hover:underline"
              onClick={() => del(s.id)}
            >
              Delete
            </button>
          </div>
        ))}
      </div>
      <form onSubmit={add} className="space-y-2 border-t border-slate-200 pt-3">
        <Field label="Add stop">
          <Input
            placeholder="Stop name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            required
          />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Input
            placeholder="Latitude"
            value={form.lat}
            onChange={(e) => setForm({ ...form, lat: e.target.value })}
            required
          />
          <Input
            placeholder="Longitude"
            value={form.lng}
            onChange={(e) => setForm({ ...form, lng: e.target.value })}
            required
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
            <option value="both">Pickup & drop-off</option>
            <option value="pickup">Pickup only</option>
            <option value="dropoff">Drop-off only</option>
          </Select>
          <Input
            placeholder="Radius (m)"
            value={form.radius_m}
            onChange={(e) => setForm({ ...form, radius_m: e.target.value })}
          />
        </div>
        <Button type="submit" className="w-full">
          Add stop
        </Button>
      </form>
    </Card>
  );
}
