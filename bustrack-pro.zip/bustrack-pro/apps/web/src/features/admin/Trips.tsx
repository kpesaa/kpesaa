import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { LiveMap, TrackReplayMap } from '../../components/maps';
import { Badge, Button, Card, PageHeader, Spinner, Table, useToast } from '../../components/ui';
import { api } from '../../lib/api';
import { type Notif, type TripRow, usePage } from '../../lib/queries';
import { useSocketEvent } from '../../lib/socket';
import { EVENT_META, fmtDateTime, fmtDistance, fmtDuration, fmtTime } from '../../lib/utils';

export function Trips() {
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const list = usePage<TripRow>('trips', '/trips', { status, page, pageSize: 20 });
  useSocketEvent('trip:ended', () => list.refetch());
  useSocketEvent('trip:started', () => list.refetch());

  return (
    <div>
      <PageHeader
        title="Trips"
        subtitle="Live and historical journeys"
        actions={
          <select className="input w-40" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        }
      />
      <Card className="p-1">
        {list.isLoading ? (
          <div className="flex justify-center py-16">
            <Spinner className="text-brand-500" />
          </div>
        ) : (
          <Table
            columns={[
              { key: 'bus', header: 'Bus', render: (t: TripRow) => t.plate_number ?? t.bus_label },
              { key: 'driver', header: 'Driver', render: (t: TripRow) => t.driver_name ?? '—' },
              { key: 'route', header: 'Route', render: (t: TripRow) => t.route_name ?? '—' },
              {
                key: 'dir',
                header: 'Direction',
                render: (t: TripRow) => t.direction.replace('_', ' '),
              },
              {
                key: 'started',
                header: 'Started',
                render: (t: TripRow) => fmtDateTime(t.started_at),
              },
              {
                key: 'dur',
                header: 'Duration',
                render: (t: TripRow) =>
                  t.started_at && t.ended_at
                    ? fmtDuration(
                        (new Date(t.ended_at).getTime() - new Date(t.started_at).getTime()) / 60000,
                      )
                    : '—',
              },
              {
                key: 'dist',
                header: 'Distance',
                render: (t: TripRow) => fmtDistance(t.distance_m),
              },
              { key: 'pts', header: 'GPS', render: (t: TripRow) => t.position_count ?? '—' },
              {
                key: 'status',
                header: 'Status',
                render: (t: TripRow) => (
                  <Badge
                    tone={
                      t.status === 'active' ? 'green' : t.status === 'cancelled' ? 'rose' : 'indigo'
                    }
                  >
                    {t.status}
                  </Badge>
                ),
              },
              {
                key: '_',
                header: '',
                render: (t: TripRow) => (
                  <Link
                    to={`/admin/trips/${t.id}`}
                    className="text-xs font-semibold text-brand-600 hover:underline"
                  >
                    Open
                  </Link>
                ),
              },
            ]}
            rows={list.data?.data ?? []}
          />
        )}
      </Card>
      {(list.data?.pagination.totalPages ?? 1) > 1 && (
        <div className="mt-3 flex justify-end gap-2">
          <Button variant="ghost" disabled={page <= 1} onClick={() => setPage(page - 1)}>
            Prev
          </Button>
          <Button
            variant="ghost"
            disabled={page >= (list.data?.pagination.totalPages ?? 1)}
            onClick={() => setPage(page + 1)}
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
}

interface TripFull extends TripRow {
  events: (Notif & { type: string; lat: number; lng: number; created_at: string })[];
  track: { lat: number; lng: number; speed_kph: number; recorded_at: string }[];
}

export function TripDetail() {
  const { id } = useParams<{ id: string }>();
  const toast = useToast();
  const trip = useQuery({
    queryKey: ['trip', id],
    queryFn: () => api<TripFull>(`/trips/${id}`),
    enabled: !!id,
  });
  const school = useQuery({
    queryKey: ['my-school'],
    queryFn: () => api<{ lat: number; lng: number } | null>('/me/school'),
  });

  const [live, setLive] = useState<{ lat: number; lng: number } | null>(null);
  useSocketEvent<{ tripId: string; lat: number; lng: number }>('bus:position', (p) => {
    if (p.tripId === id) setLive({ lat: p.lat, lng: p.lng });
  });
  useSocketEvent('trip:event', () => trip.refetch());

  const [idx, setIdx] = useState(0);
  const playing = useRef<number | null>(null);
  useEffect(() => () => window.clearInterval(playing.current ?? undefined), []);

  if (trip.isLoading || !trip.data) return <Spinner className="text-brand-500" />;
  const t = trip.data;
  const isLive = t.status === 'active';
  const track = t.track ?? [];

  function play() {
    if (playing.current) {
      window.clearInterval(playing.current);
      playing.current = null;
      return;
    }
    playing.current = window.setInterval(() => {
      setIdx((i) => {
        if (i >= track.length - 1) {
          window.clearInterval(playing.current ?? undefined);
          playing.current = null;
          return i;
        }
        return i + 1;
      });
    }, 150);
  }

  async function cancel() {
    if (!confirm('Cancel this active trip?')) return;
    await api(`/trips/${id}/cancel`, { method: 'POST' }).catch(() =>
      toast('Could not cancel', 'err'),
    );
    trip.refetch();
  }

  return (
    <div>
      <PageHeader
        title={`${t.plate_number ?? t.bus_label} · ${t.direction.replace('_', ' ')}`}
        subtitle={`${t.driver_name} · ${t.route_name ?? 'no route'} · ${fmtDistance(t.distance_m)}`}
        actions={
          <div className="flex gap-2">
            <Link to="/admin/trips" className="btn-ghost">
              Back
            </Link>
            {isLive && (
              <Button variant="danger" onClick={cancel}>
                Cancel trip
              </Button>
            )}
          </div>
        }
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="overflow-hidden lg:col-span-2">
          {isLive ? (
            <div className="h-[460px]">
              <LiveMap
                school={school.data ?? undefined}
                bus={
                  live ??
                  (t.last_lat != null
                    ? { lat: t.last_lat, lng: t.last_lng!, label: t.plate_number }
                    : null)
                }
              />
            </div>
          ) : track.length ? (
            <>
              <TrackReplayMap
                track={track}
                index={idx}
                school={school.data ?? undefined}
                height={420}
              />
              <div className="flex items-center gap-3 border-t border-slate-200 p-3">
                <Button variant="ghost" onClick={play}>
                  ▶ / ⏸
                </Button>
                <input
                  type="range"
                  min={0}
                  max={Math.max(track.length - 1, 1)}
                  value={idx}
                  onChange={(e) => setIdx(Number(e.target.value))}
                  className="flex-1"
                />
                <span className="w-24 text-right text-xs tabular-nums text-slate-500">
                  {idx + 1}/{track.length} ·{' '}
                  {fmtTime(track[Math.min(idx, track.length - 1)]?.recorded_at)}
                </span>
              </div>
            </>
          ) : (
            <div className="p-10 text-center text-sm text-slate-400">No GPS track recorded.</div>
          )}
        </Card>

        <Card className="overflow-hidden">
          <div className="border-b border-slate-200 px-4 py-2.5 text-sm font-semibold">
            Timeline
          </div>
          <div className="max-h-[460px] divide-y divide-slate-100 overflow-y-auto">
            {(t.events ?? []).map((e) => (
              <div key={e.id} className="flex gap-2.5 px-4 py-2.5 text-sm">
                <span>{EVENT_META[e.type]?.icon ?? '•'}</span>
                <div>
                  <div className="font-medium">{EVENT_META[e.type]?.label ?? e.type}</div>
                  <div className="text-xs text-slate-400">{fmtDateTime(e.created_at)}</div>
                </div>
              </div>
            ))}
            {!(t.events ?? []).length && (
              <p className="p-4 text-sm text-slate-400">No events yet.</p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
