import { useQueryClient } from '@tanstack/react-query';
import { useCallback, useEffect, useRef, useState } from 'react';
import { DriverHandovers } from '../shared/Handovers';
import { PageHeader } from '../../components/ui';
import { LiveMap } from '../../components/maps';
import { Button, Card, Spinner, useToast } from '../../components/ui';
import { ApiError, api } from '../../lib/api';
import { useMyBus } from '../../lib/queries';
import { useSocketConnected } from '../../lib/socket';

interface Buffered {
  lat: number;
  lng: number;
  speedKph: number;
  headingDeg: number;
  accuracyM?: number;
  recordedAt: string;
  source: 'device' | 'sim';
}

const BUFFER_KEY = 'bustrack-driver-buffer-v2';
const FLUSH_MS = Math.max(500, Math.min(10000, Number(import.meta.env.VITE_GPS_FLUSH_MS) || 1000));

export function DriverConsole() {
  const bus = useMyBus();
  const cache = useQueryClient();
  const toast = useToast();
  const connected = useSocketConnected();

  const [tripId, setTripId] = useState<string | null>(null);
  const [direction, setDirection] = useState<'to_school' | 'from_school'>('to_school');
  const [starting, setStarting] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [last, setLast] = useState<Buffered | null>(null);
  const [pending, setPending] = useState(0);
  const [gpsError, setGpsError] = useState('');
  const [lastUpload, setLastUpload] = useState<string | null>(null);
  const flushingRef = useRef(false);
  const [useSim, setUseSim] = useState(false);

  const bufferRef = useRef<Buffered[]>([]);
  const watchRef = useRef<number | null>(null);
  const flushRef = useRef<number | null>(null);
  const timerRef = useRef<number | null>(null);
  const wakeRef = useRef<WakeLockSentinel | null>(null);
  const simRef = useRef<{ i: number; path: [number, number][] }>({ i: 0, path: [] });
  const tripRef = useRef<string | null>(null);
  tripRef.current = tripId;

  // Resume an already-active trip.
  useEffect(() => {
    if (bus.data?.active_trip && !tripId) {
      setDirection(bus.data.active_trip.direction as 'to_school' | 'from_school');
      setTripId(bus.data.active_trip.id);
    }
  }, [bus.data, tripId]);

  const enqueue = useCallback((p: Buffered) => {
    if (bufferRef.current.length >= 10000) { setGpsError('Offline storage is full. Reconnect to resume recording.'); return; }
    bufferRef.current.push(p);
    saveBuffer(tripRef.current!, bufferRef.current);
    setLast(p);
    setPending(bufferRef.current.length);
  }, []);

  const flush = useCallback(async () => {
    const id = tripRef.current;
    if (!id) return false;
    if (flushingRef.current) return false;
    if (bufferRef.current.length === 0) return true;
    flushingRef.current = true;
    const batch = bufferRef.current.slice(0, 200);
    try {
      await api(`/trips/${id}/positions`, { method: 'POST', json: { positions: batch } });
      bufferRef.current = bufferRef.current.slice(batch.length);
      saveBuffer(id, bufferRef.current);
      setPending(bufferRef.current.length);
      setLastUpload(new Date().toISOString());
      return true;
    } catch {
      return false;
    } finally { flushingRef.current = false; }
  }, []);

  const startTracking = useCallback(() => {
    // Screen wake lock.
    navigator.wakeLock
      ?.request('screen')
      .then((s) => {
        wakeRef.current = s;
      })
      .catch(() => {});

    // Flusher.
    flushRef.current = window.setInterval(flush, FLUSH_MS);

    if (useSim) {
      simRef.current = { i: 0, path: bus.data?.active_trip ? [] : [] };
      // Build a sim path from route if available; fall back to a small loop around school.
      api<{ path: [number, number][] } | null>(`/routes/${bus.data?.route_id}`)
        .then((r) => {
          simRef.current.path = r?.path?.length ? r.path : SIM_FALLBACK;
        })
        .catch(() => {
          simRef.current.path = SIM_FALLBACK;
        });
      watchRef.current = window.setInterval(() => {
        const { i, path } = simRef.current;
        if (!path.length) return;
        const [lat, lng] = path[Math.min(i, path.length - 1)]!;
        simRef.current.i = i + 1;
        enqueue({
          lat,
          lng,
          speedKph: 28 + Math.random() * 8,
          headingDeg: 0,
          recordedAt: new Date().toISOString(),
          source: 'sim',
        });
      }, FLUSH_MS) as unknown as number;
    } else {
      if (!navigator.geolocation) { setGpsError('Location tracking requires HTTPS and a supported browser.'); return; }
      watchRef.current = navigator.geolocation.watchPosition(
        (pos) => {
          setGpsError('');
          enqueue({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            speedKph: pos.coords.speed ? pos.coords.speed * 3.6 : 0,
            headingDeg: pos.coords.heading ?? 0,
            accuracyM: pos.coords.accuracy,
            recordedAt: new Date(pos.timestamp).toISOString(),
            source: 'device',
          });
        },
        (err) => setGpsError(`Location unavailable: ${err.message}`),
        { enableHighAccuracy: true, maximumAge: 3000, timeout: 15000 },
      );
    }

    timerRef.current = window.setInterval(() => setElapsed((e) => e + 1), 1000);
  }, [bus.data, enqueue, flush, toast, useSim]);

  const stopTracking = useCallback(() => {
    if (watchRef.current != null) {
      if (useSim) window.clearInterval(watchRef.current);
      else navigator.geolocation.clearWatch(watchRef.current);
      watchRef.current = null;
    }
    for (const r of [flushRef, timerRef]) {
      if (r.current) window.clearInterval(r.current);
      r.current = null;
    }
    wakeRef.current?.release().catch(() => {});
    wakeRef.current = null;
  }, [useSim]);

  useEffect(() => {
    if (tripId) {
      bufferRef.current = loadBuffer(tripId);
      setPending(bufferRef.current.length);
      startTracking();
    }
    return stopTracking;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tripId]);

  useEffect(() => stopTracking, [stopTracking]);
  useEffect(() => {
    const acquire = () => {
      if (tripId && document.visibilityState === 'visible' && (!wakeRef.current || wakeRef.current.released)) {
        navigator.wakeLock?.request('screen').then((s) => { wakeRef.current = s; }).catch(() => {});
      }
    };
    document.addEventListener('visibilitychange', acquire);
    return () => document.removeEventListener('visibilitychange', acquire);
  }, [tripId]);

  async function start() {
    if (!bus.data) return;
    setStarting(true);
    try {
      const trip = await api<{ id: string }>('/trips', {
        method: 'POST',
        json: { bus_id: bus.data.id, direction },
      });
      setElapsed(0);
      setTripId(trip.id);
      toast('Trip started');
    } catch (err) {
      toast(err instanceof ApiError ? err.message : 'Could not start', 'err');
    } finally {
      setStarting(false);
    }
  }

  async function fireEvent(kind: 'depart' | 'arrive' | 'emergency') {
    if (!tripId) return;
    try {
      await api(`/trips/${tripId}/${kind}`, {
        method: 'POST',
        json: kind === 'emergency' ? { note: 'Driver pressed emergency' } : undefined,
      });
      toast(kind === 'emergency' ? '🚨 Emergency alert sent' : 'Signal sent');
    } catch {
      toast('Failed to send', 'err');
    }
  }

  async function end() {
    if (!tripId) return;
    if (!confirm('End this trip?')) return;
    stopTracking();
    while (flushingRef.current) await new Promise((resolve) => setTimeout(resolve, 100));
    while (bufferRef.current.length) {
      if (!(await flush())) { toast('Trip remains active. Reconnect and upload queued locations before ending.', 'err'); startTracking(); return; }
    }
    try {
      await api(`/trips/${tripId}/end`, { method: 'POST' });
      stopTracking();
      cache.setQueryData(['my-bus'], (old: typeof bus.data) => old ? { ...old, active_trip: null } : old);
      setTripId(null);
      bufferRef.current = [];
      saveBuffer(tripId, []);
      setPending(0);
      setLast(null);
      toast('Trip ended');
      bus.refetch();
    } catch {
      toast('Could not end trip. Tracking has resumed.', 'err');
      startTracking();
    }
  }

  if (bus.isLoading) return <Spinner className="text-brand-500" />;
  if (bus.error || !bus.data)
    return (
      <Card className="p-8 text-center text-slate-500">No bus is assigned to your account.</Card>
    );

  const active = Boolean(tripId);

  return (
    <div className="mx-auto max-w-3xl"><PageHeader title="Your journey" subtitle="Start tracking, monitor connection status and confirm child handovers." />
      <Card className="overflow-hidden">
        <div className="flex items-center justify-between bg-[#102035] px-5 py-5 text-white">
          <div>
            <div className="text-lg font-bold">{bus.data.plate_number}</div>
            <div className="text-xs text-slate-400">
              {bus.data.route_name ?? 'No route'} · {bus.data.student_count} students
            </div>
          </div>
          <span
            className={`rounded px-2 py-0.5 text-xs font-bold ${
              connected ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-700 text-slate-300'
            }`}
          >
            {connected ? '● LIVE' : '● OFFLINE'}
          </span>
        </div>

        <div className="h-64 sm:h-72">
          <LiveMap
            bus={last ? { lat: last.lat, lng: last.lng, label: bus.data.plate_number } : null}
            follow
          />
        </div>

        {gpsError && <p role="alert" className="border-b border-amber-200 bg-amber-50 px-5 py-4 text-sm text-amber-900">{gpsError}</p>}
        {active && <div className="flex flex-wrap gap-3 border-b border-slate-100 px-5 py-3 text-xs text-slate-500"><span>Location: {gpsError ? 'Needs attention' : last ? 'Acquired' : 'Waiting for GPS'}</span><span>Last upload: {lastUpload ? new Date(lastUpload).toLocaleTimeString() : 'Waiting'}</span><span>Queued: {pending}</span></div>}
        {active ? (
          <div className="space-y-4 p-4">
            <div className="grid grid-cols-3 gap-2 rounded-lg bg-slate-50 p-3 text-center">
              <Stat label="Elapsed" value={fmtElapsed(elapsed)} />
              <Stat label="Speed" value={last ? `${Math.round(last.speedKph)}` : '0'} unit="km/h" />
              <Stat label="Queued" value={String(pending)} unit="pts" />
            </div>
            {last && (
              <p className="text-center text-xs text-slate-400">
                {last.lat.toFixed(5)}, {last.lng.toFixed(5)} · {useSim ? 'simulated' : 'device GPS'}
              </p>
            )}
            <div className="grid grid-cols-2 gap-2">
              <Button variant="ghost" onClick={() => fireEvent('depart')}>
                Departed school
              </Button>
              <Button variant="ghost" onClick={() => fireEvent('arrive')}>
                Arrived at school
              </Button>
            </div>
            <Button variant="danger" className="w-full" onClick={() => { if (confirm('Send an emergency alert to parents and the school?')) fireEvent('emergency'); }}>
              Emergency alert
            </Button>
            <Button variant="ghost" className="w-full" onClick={end}>
              End trip
            </Button>
          </div>
        ) : (
          <div className="space-y-4 p-4">
            <div className="flex gap-2">
              {(['to_school', 'from_school'] as const).map((d) => (
                <button
                  key={d}
                  onClick={() => setDirection(d)}
                  className={`flex-1 rounded-lg border px-3 py-2 text-sm font-medium ${
                    direction === d
                      ? 'border-brand-500 bg-brand-50 text-brand-700'
                      : 'border-slate-200'
                  }`}
                >
                  {d === 'to_school' ? 'Morning pickup' : 'Afternoon drop-off'}
                </button>
              ))}
            </div>
            <label className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm">
              <span>
                Simulated location <span className="text-xs text-slate-400">(demo)</span>
              </span>
              <input
                type="checkbox"
                className="h-4 w-4"
                checked={useSim}
                onChange={(e) => setUseSim(e.target.checked)}
              />
            </label>
            <Button className="w-full py-3 text-base" onClick={start} disabled={starting}>
              {starting ? 'Starting…' : 'START TRIP'}
            </Button>
          </div>
        )}
      </Card>
      {tripId && direction === 'from_school' && <DriverHandovers tripId={tripId} />}
    </div>
  );
}

const Stat = ({ label, value, unit }: { label: string; value: string; unit?: string }) => (
  <div>
    <div className="text-[10px] uppercase tracking-wide text-slate-400">{label}</div>
    <div className="text-lg font-bold tabular-nums text-slate-800">
      {value}
      {unit && <span className="ml-0.5 text-xs font-normal text-slate-400">{unit}</span>}
    </div>
  </div>
);

function fmtElapsed(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return [h, m, sec].map((x) => String(x).padStart(2, '0')).join(':');
}

function loadBuffer(tripId: string): Buffered[] {
  try {
    return JSON.parse(localStorage.getItem(BUFFER_KEY) ?? '{}')[tripId] ?? [];
  } catch {
    return [];
  }
}
function saveBuffer(tripId: string, b: Buffered[]) {
  const store = JSON.parse(localStorage.getItem(BUFFER_KEY) ?? '{}');
  if (b.length) store[tripId] = b; else delete store[tripId];
  localStorage.setItem(BUFFER_KEY, JSON.stringify(store));
}

const SIM_FALLBACK: [number, number][] = [
  [5.0478, 7.9137],
  [5.0489, 7.9146],
  [5.05, 7.9158],
  [5.0511, 7.9171],
  [5.0518, 7.9186],
  [5.0521, 7.9201],
  [5.0508, 7.9216],
  [5.0491, 7.9198],
  [5.0481, 7.9158],
  [5.0478, 7.9137],
];
