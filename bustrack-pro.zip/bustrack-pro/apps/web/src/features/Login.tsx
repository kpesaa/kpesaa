import { Icon } from '../components/Icon';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Field, Input } from '../components/ui';
import { ApiError, api } from '../lib/api';
import { type User, useAuth } from '../lib/store';

const DEMO = [
  ['Admin', 'admin@graceland.edu.ng', 'admin12345'],
  ['Dispatcher', 'dispatch@graceland.edu.ng', 'dispatch12345'],
  ['Driver', 'driver1@graceland.edu.ng', 'driver12345'],
  ['Parent', 'parent1@example.com', 'parent12345'],
];

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const setSession = useAuth((s) => s.setSession);
  const nav = useNavigate();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const res = await api<{ accessToken: string; refreshToken: string; user: User }>(
        '/auth/login',
        {
          method: 'POST',
          json: { email, password },
        },
      );
      setSession(res);
      nav(
        res.user.role === 'super_admin' ? '/admin/schools' : res.user.role === 'driver' ? '/driver' : res.user.role === 'parent' ? '/parent' : '/admin',
      );
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Login failed');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen">
      <div className="hidden flex-1 flex-col justify-center relative overflow-hidden bg-[#102035] p-16 text-white lg:flex">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-500"><Icon name="bus" size={40} /></div><p className="mt-12 text-xs font-semibold uppercase tracking-[.22em] text-blue-300">Connected school transport</p>
        <h1 className="mt-4 text-4xl font-extrabold tracking-tight">A clearer journey.<br />A confirmed handover.</h1>
        <p className="mt-2 max-w-sm text-brand-100/70">
          Follow every bus journey. Receive timely stop alerts. Confirm who receives each child with a parent-authorised code.
        </p>
      </div>
      <div className="flex flex-1 items-center justify-center bg-white p-6">
        <div className="w-full max-w-sm">
          <div className="mb-9 flex items-center gap-2 text-blue-600"><Icon name="bus" size={24} /><span className="text-xl font-bold text-slate-900">BusTrack Pro</span></div><p className="eyebrow">Welcome back</p><h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-900">Sign in to your workspace</h2>
          <p className="mb-6 text-sm text-slate-500">Use your BusTrack account.</p>
          {error && (
            <div className="mb-4 rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">
              {error}
            </div>
          )}
          <form onSubmit={submit} className="space-y-4">
            <Field label="Email">
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoComplete="email"
              />
            </Field>
            <Field label="Password">
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="current-password"
              />
            </Field>
            <Button type="submit" disabled={busy} className="w-full">
              {busy ? 'Signing in…' : 'Sign in'}
            </Button>
          </form>

          {import.meta.env.DEV && <div className="mt-8 rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
              Demo accounts
            </p>
            <div className="grid grid-cols-2 gap-1.5">
              {DEMO.map(([label, e, p]) => (
                <button
                  key={e}
                  type="button"
                  onClick={() => {
                    setEmail(e!);
                    setPassword(p!);
                  }}
                  className="rounded border border-slate-200 bg-white px-2 py-1.5 text-left text-xs text-slate-600 hover:bg-slate-100"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>}
        </div>
      </div>
    </div>
  );
}
