import type { ReactNode } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { AppShell } from './components/Layout';
import { Login } from './features/Login';
import { AdminDashboard } from './features/admin/Dashboard';
import { Reports } from './features/admin/Reports';
import { RouteEditor } from './features/admin/RouteEditor';
import { Schools } from './features/admin/Schools';
import { Settings } from './features/admin/Settings';
import { TripDetail, Trips } from './features/admin/Trips';
import {
  Buses,
  Drivers,
  Parents,
  Routes as RoutesPage,
  Staff,
  Students,
} from './features/admin/entities';
import { DriverConsole } from './features/driver/Driver';
import { ParentNotifications } from './features/parent/Notifications';
import { ParentHistory } from './features/parent/History';
import { AdminHandovers, ParentHandovers } from './features/shared/Handovers';
import { ParentHome } from './features/parent/Parent';
import { ParentSettings } from './features/parent/Settings';
import { type Role, useAuth } from './lib/store';

function Guard({ roles, children }: { roles: Role[]; children: ReactNode }) {
  const user = useAuth((s) => s.user);
  if (!user) return <Navigate to="/login" replace />;
  if (!roles.includes(user.role)) return <Navigate to={homeFor(user.role)} replace />;
  return <AppShell>{children}</AppShell>;
}

function homeFor(role: Role) {
  if (role === 'super_admin') return '/admin/schools';
  if (role === 'driver') return '/driver';
  if (role === 'parent') return '/parent';
  return '/admin';
}

export function App() {
  const user = useAuth((s) => s.user);
  const admin: Role[] = ['admin', 'dispatcher', 'super_admin'];

  return (
    <Routes>
      <Route
        path="/login"
        element={user ? <Navigate to={homeFor(user.role)} replace /> : <Login />}
      />

      <Route
        path="/admin"
        element={
          <Guard roles={admin}>
            <AdminDashboard />
          </Guard>
        }
      />
      <Route
        path="/admin/schools"
        element={
          <Guard roles={['super_admin']}>
            <Schools />
          </Guard>
        }
      />
      <Route
        path="/admin/trips"
        element={
          <Guard roles={admin}>
            <Trips />
          </Guard>
        }
      />
      <Route
        path="/admin/trips/:id"
        element={
          <Guard roles={admin}>
            <TripDetail />
          </Guard>
        }
      />
      <Route
        path="/admin/buses"
        element={
          <Guard roles={admin}>
            <Buses />
          </Guard>
        }
      />
      <Route
        path="/admin/routes"
        element={
          <Guard roles={admin}>
            <RoutesPage />
          </Guard>
        }
      />
      <Route
        path="/admin/routes/:id"
        element={
          <Guard roles={admin}>
            <RouteEditor />
          </Guard>
        }
      />
      <Route
        path="/admin/students"
        element={
          <Guard roles={admin}>
            <Students />
          </Guard>
        }
      />
      <Route
        path="/admin/drivers"
        element={
          <Guard roles={admin}>
            <Drivers />
          </Guard>
        }
      />
      <Route
        path="/admin/parents"
        element={
          <Guard roles={admin}>
            <Parents />
          </Guard>
        }
      />
      <Route
        path="/admin/staff"
        element={
          <Guard roles={['admin', 'super_admin']}>
            <Staff />
          </Guard>
        }
      />
      <Route
        path="/admin/reports"
        element={
          <Guard roles={admin}>
            <Reports />
          </Guard>
        }
      />
      <Route
        path="/admin/settings"
        element={
          <Guard roles={admin}>
            <Settings />
          </Guard>
        }
      />

      <Route
        path="/driver"
        element={
          <Guard roles={['driver']}>
            <DriverConsole />
          </Guard>
        }
      />

      <Route
        path="/parent"
        element={
          <Guard roles={['parent']}>
            <ParentHome />
          </Guard>
        }
      />
      <Route
        path="/parent/notifications"
        element={
          <Guard roles={['parent']}>
            <ParentNotifications />
          </Guard>
        }
      />
      <Route
        path="/parent/settings"
        element={
          <Guard roles={['parent']}>
            <ParentSettings />
          </Guard>
        }
      />

      <Route path="/parent/handovers" element={<Guard roles={['parent']}><ParentHandovers /></Guard>} />
      <Route path="/parent/history" element={<Guard roles={['parent']}><ParentHistory /></Guard>} />
      <Route path="/admin/handovers" element={<Guard roles={admin}><AdminHandovers /></Guard>} />

      <Route path="*" element={<Navigate to={user ? homeFor(user.role) : '/login'} replace />} />
    </Routes>
  );
}
