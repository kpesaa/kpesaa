import react from '@vitejs/plugin-react';
import { defineConfig, loadEnv } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const apiUrl = env.VITE_API_URL || 'http://localhost:4000';

  return {
    plugins: [
      react(),
      VitePWA({
        strategies: 'injectManifest',
        srcDir: 'src',
        filename: 'sw.ts',
        registerType: 'autoUpdate',
        injectManifest: { globPatterns: ['**/*.{js,css,html,svg,png,webmanifest}'] },
        devOptions: { enabled: true, type: 'module' },
        manifest: {
          name: 'BusTrack',
          short_name: 'BusTrack',
          description: 'Real-time school bus tracking and parent notifications',
          theme_color: '#0f172a',
          background_color: '#0f172a',
          display: 'standalone',
          start_url: '/',
          icons: [
            { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
            { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
          ],
        },
      }),
    ],
    server: {
      port: 5173,
      // Listen on all interfaces so phones/tablets on the same Wi-Fi can reach it
      // at http://<this-machine-LAN-IP>:5173. Set to '127.0.0.1' to keep it local-only.
      host: true,
      // Allow tunnel hostnames (cloudflared / ngrok) in addition to LAN IPs.
      allowedHosts: true,
      proxy: {
        '/api': { target: apiUrl, changeOrigin: true },
        '/socket.io': { target: apiUrl, ws: true, changeOrigin: true },
      },
    },
    preview: { port: 4173, host: '127.0.0.1' },
  };
});
