import path from 'node:path';
import dotenv from 'dotenv';
import { z } from 'zod';

// Load the repo-root .env (docker-compose and local dev share it).
dotenv.config({ path: path.resolve(__dirname, '../../../../.env') });
dotenv.config(); // also allow apps/api/.env to override

const bool = z
  .string()
  .transform((v) => v === 'true' || v === '1')
  .pipe(z.boolean());

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  API_PORT: z.coerce.number().int().positive().default(4000),
  WEB_ORIGIN: z.string().url().default('http://localhost:5173'),
  CORS_ORIGINS: z.string().optional(),

  DATABASE_URL: z.string().min(1),
  TEST_DATABASE_URL: z.string().optional(),
  REDIS_URL: z.string().optional(),

  HANDOVER_CODE_SECRET: z.string().min(32).optional(),
  HANDOVER_CODE_TTL_MINUTES: z.coerce.number().int().min(5).max(60).default(30),
  JWT_ACCESS_SECRET: z.string().min(16),
  JWT_REFRESH_SECRET: z.string().min(16),
  ACCESS_TOKEN_TTL: z.string().default('15m'),
  REFRESH_TOKEN_TTL: z.string().default('30d'),
  LOGIN_MAX_ATTEMPTS: z.coerce.number().int().positive().default(8),
  LOGIN_LOCK_MINUTES: z.coerce.number().int().positive().default(15),

  DEFAULT_STOP_RADIUS_M: z.coerce.number().positive().default(150),
  SCHOOL_RADIUS_M: z.coerce.number().positive().default(250),
  ROUTE_DEVIATION_M: z.coerce.number().positive().default(120),
  NOTIFY_COOLDOWN_S: z.coerce.number().positive().default(600),

  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.coerce.number().default(587),
  SMTP_SECURE: bool.default('false'),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  MAIL_FROM: z.string().default('BusTrack <no-reply@bustrack.local>'),

  VAPID_PUBLIC_KEY: z.string().optional(),
  VAPID_PRIVATE_KEY: z.string().optional(),
  VAPID_SUBJECT: z.string().default('mailto:admin@bustrack.local'),

  SMS_PROVIDER: z.enum(['log', 'termii']).default('log'),
  TERMII_API_KEY: z.string().optional(),
  TERMII_SENDER_ID: z.string().default('BusTrack'),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error('❌ Invalid environment configuration:');
  for (const issue of parsed.error.issues) {
    console.error(`  - ${issue.path.join('.') || '(root)'}: ${issue.message}`);
  }
  process.exit(1);
}

const raw = parsed.data;
if (raw.NODE_ENV === 'production' && !raw.HANDOVER_CODE_SECRET) {
  throw new Error('HANDOVER_CODE_SECRET (at least 32 characters) is required in production');
}

export const env = {
  ...raw,
  isProd: raw.NODE_ENV === 'production',
  isTest: raw.NODE_ENV === 'test',
  isDev: raw.NODE_ENV === 'development',
  databaseUrl:
    raw.NODE_ENV === 'test' ? (raw.TEST_DATABASE_URL ?? raw.DATABASE_URL) : raw.DATABASE_URL,
  corsOrigins: (raw.CORS_ORIGINS ?? raw.WEB_ORIGIN)
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
};

export type Env = typeof env;
