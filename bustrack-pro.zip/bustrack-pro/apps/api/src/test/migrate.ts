// Run migrations against the TEST database before the vitest run.
// Executed by `tsx` so the .ts migration files load correctly (which knex's
// in-process loader cannot do inside vitest's worker).
process.env.NODE_ENV = 'test';

async function main() {
  // Dynamic import so config/env reads NODE_ENV *after* it is set above.
  const { db } = await import('../db/knex');
  await db.raw('select 1');
  const [batch, files] = await db.migrate.latest();
  // eslint-disable-next-line no-console
  console.log(
    files.length
      ? `test-db: ran batch ${batch} (${files.length} files)`
      : 'test-db: schema up to date',
  );
  await db.destroy();
}

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('test-db migration failed', err);
  process.exit(1);
});
