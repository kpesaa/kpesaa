import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import type { Express } from 'express';
import supertest from 'supertest';
import { createApp } from '../app';
import { db } from '../db/knex';

export const app: Express = createApp();
export const request = () => supertest(app);

const TABLES = [
  'child_handovers',
  'audit_logs',
  'notification_deliveries',
  'notifications',
  'notification_preferences',
  'push_subscriptions',
  'trip_events',
  'trip_positions',
  'trips',
  'guardianships',
  'students',
  'stops',
  'routes',
  'buses',
  'refresh_tokens',
  'users',
  'schools',
];

export async function resetDb(): Promise<void> {
  // Safety net: this TRUNCATEs every table. If NODE_ENV/env resolution ever points
  // the test process at a non-test database, refuse rather than wipe real data.
  const { rows } = await db.raw('select current_database() as db');
  const name = String(rows[0]?.db ?? '');
  if (!/_test$/.test(name)) {
    throw new Error(`resetDb refusing to TRUNCATE non-test database "${name}"`);
  }
  await db.raw(`TRUNCATE ${TABLES.map((t) => `"${t}"`).join(', ')} RESTART IDENTITY CASCADE`);
}

export interface Fixture {
  schoolId: string;
  admin: { id: string; email: string; password: string };
  driver: { id: string; email: string; password: string };
  parent: { id: string; email: string; password: string };
  busId: string;
  routeId: string;
  stopId: string;
  studentId: string;
}

/** A minimal school with one of each role, one bus, one route+stop, one student. */
export async function seedFixture(): Promise<Fixture> {
  const id = () => randomUUID();
  const pw = 'password123';
  const hash = bcrypt.hashSync(pw, 4);

  const schoolId = id();
  await db('schools').insert({
    id: schoolId,
    name: 'Test School',
    slug: `test-${schoolId.slice(0, 8)}`,
    lat: 5.0478,
    lng: 7.9137,
    radius_m: 250,
  });

  const adminId = id();
  const driverId = id();
  const parentId = id();
  await db('users').insert([
    {
      id: adminId,
      school_id: schoolId,
      name: 'Admin',
      email: `admin-${adminId.slice(0, 6)}@t.io`,
      password_hash: hash,
      role: 'admin',
      status: 'active',
    },
    {
      id: driverId,
      school_id: schoolId,
      name: 'Driver',
      email: `driver-${driverId.slice(0, 6)}@t.io`,
      password_hash: hash,
      role: 'driver',
      status: 'active',
    },
    {
      id: parentId,
      school_id: schoolId,
      name: 'Parent',
      email: `parent-${parentId.slice(0, 6)}@t.io`,
      password_hash: hash,
      role: 'parent',
      status: 'active',
      phone: '+2348000000000',
    },
  ]);
  await db('notification_preferences').insert(
    [adminId, driverId, parentId].map((user_id) => ({ user_id })),
  );

  const busId = id();
  await db('buses').insert({
    id: busId,
    school_id: schoolId,
    plate_number: `T-${busId.slice(0, 5)}`,
    label: 'Test Bus',
    driver_id: driverId,
  });

  const routeId = id();
  await db('routes').insert({
    id: routeId,
    school_id: schoolId,
    name: 'Test Route',
    path: JSON.stringify([
      [5.0478, 7.9137],
      [5.05, 7.9158],
      [5.0521, 7.9201],
    ]),
  });

  const stopId = id();
  await db('stops').insert({
    id: stopId,
    route_id: routeId,
    school_id: schoolId,
    name: 'Test Stop',
    kind: 'both',
    lat: 5.0521,
    lng: 7.9201,
    radius_m: 150,
    sequence: 1,
  });

  const studentId = id();
  await db('students').insert({
    id: studentId,
    school_id: schoolId,
    first_name: 'Kid',
    last_name: 'One',
    route_id: routeId,
    bus_id: busId,
    pickup_stop_id: stopId,
    dropoff_stop_id: stopId,
  });
  await db('guardianships').insert({
    id: id(),
    student_id: studentId,
    guardian_id: parentId,
    is_primary: true,
  });

  return {
    schoolId,
    admin: { id: adminId, email: `admin-${adminId.slice(0, 6)}@t.io`, password: pw },
    driver: { id: driverId, email: `driver-${driverId.slice(0, 6)}@t.io`, password: pw },
    parent: { id: parentId, email: `parent-${parentId.slice(0, 6)}@t.io`, password: pw },
    busId,
    routeId,
    stopId,
    studentId,
  };
}

export async function tokenFor(email: string, password: string): Promise<string> {
  const res = await request().post('/api/v1/auth/login').send({ email, password });
  return res.body.accessToken as string;
}
