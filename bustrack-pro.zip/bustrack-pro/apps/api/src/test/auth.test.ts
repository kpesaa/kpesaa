import { beforeEach, describe, expect, it } from 'vitest';
import { db } from '../db/knex';
import { type Fixture, request, resetDb, seedFixture, tokenFor } from './helpers';

describe('auth + rbac', () => {
  let fx: Fixture;
  beforeEach(async () => {
    await resetDb();
    fx = await seedFixture();
  });

  it('logs in with valid credentials and issues tokens', async () => {
    const res = await request()
      .post('/api/v1/auth/login')
      .send({ email: fx.admin.email, password: fx.admin.password });
    expect(res.status).toBe(200);
    expect(res.body.accessToken).toBeTypeOf('string');
    expect(res.body.refreshToken).toBeTypeOf('string');
    expect(res.body.user.password_hash).toBeUndefined();
  });

  it('rejects a bad password', async () => {
    const res = await request()
      .post('/api/v1/auth/login')
      .send({ email: fx.admin.email, password: 'wrong' });
    expect(res.status).toBe(401);
  });

  it('locks the account after too many failed attempts', async () => {
    for (let i = 0; i < 8; i++) {
      await request().post('/api/v1/auth/login').send({ email: fx.driver.email, password: 'nope' });
    }
    const locked = await request()
      .post('/api/v1/auth/login')
      .send({ email: fx.driver.email, password: fx.driver.password });
    expect(locked.status).toBe(429);
    const row = await db('users').where({ id: fx.driver.id }).first();
    expect(row.locked_until).not.toBeNull();
  });

  it('rotates refresh tokens and revokes the old one', async () => {
    const login = await request()
      .post('/api/v1/auth/login')
      .send({ email: fx.parent.email, password: fx.parent.password });
    const first = login.body.refreshToken;

    const r1 = await request().post('/api/v1/auth/refresh').send({ refreshToken: first });
    expect(r1.status).toBe(200);
    expect(r1.body.refreshToken).not.toBe(first);

    const reuse = await request().post('/api/v1/auth/refresh').send({ refreshToken: first });
    expect(reuse.status).toBe(401);
  });

  it('enforces role-based access', async () => {
    const parentTok = await tokenFor(fx.parent.email, fx.parent.password);
    const adminTok = await tokenFor(fx.admin.email, fx.admin.password);

    expect(
      (await request().get('/api/v1/users').set('Authorization', `Bearer ${parentTok}`)).status,
    ).toBe(403);
    expect(
      (await request().get('/api/v1/users').set('Authorization', `Bearer ${adminTok}`)).status,
    ).toBe(200);
    expect((await request().get('/api/v1/users')).status).toBe(401);
  });

  it('scopes list results to the caller school', async () => {
    // A second school with its own bus.
    const other = await seedFixture();
    const adminTok = await tokenFor(fx.admin.email, fx.admin.password);
    const res = await request().get('/api/v1/buses').set('Authorization', `Bearer ${adminTok}`);
    const ids = res.body.data.map((b: { id: string }) => b.id);
    expect(ids).toContain(fx.busId);
    expect(ids).not.toContain(other.busId);
  });

  it('validates request bodies with zod', async () => {
    const adminTok = await tokenFor(fx.admin.email, fx.admin.password);
    const res = await request()
      .post('/api/v1/buses')
      .set('Authorization', `Bearer ${adminTok}`)
      .send({ plate_number: '', capacity: -3 });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/validation/i);
  });
});
