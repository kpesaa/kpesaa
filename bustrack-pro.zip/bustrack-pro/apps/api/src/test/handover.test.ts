import { randomUUID } from 'node:crypto';
import { beforeEach, describe, expect, it } from 'vitest';
import { db } from '../db/knex';
import { canWatchBus } from '../realtime/io';
import { type Fixture, request, resetDb, seedFixture, tokenFor } from './helpers';

describe('child handover and access boundaries', () => {
  let fx: Fixture;
  let driver: string;
  let parent: string;
  let tripId: string;
  const auth = (token: string) => `Bearer ${token}`;
  beforeEach(async () => {
    await resetDb();
    fx = await seedFixture();
    driver = await tokenFor(fx.driver.email, fx.driver.password);
    parent = await tokenFor(fx.parent.email, fx.parent.password);
    tripId = (await request().post('/api/v1/trips').set('Authorization', auth(driver))
      .send({ bus_id: fx.busId, direction: 'from_school' })).body.id;
  });
  const issue = () => request().post(`/api/v1/handovers/trips/${tripId}/request`)
    .set('Authorization', auth(driver)).send({ studentId: fx.studentId });
  const mine = () => request().get('/api/v1/handovers/mine').set('Authorization', auth(parent));
  const authorise = (id: string) => request().post(`/api/v1/handovers/${id}/authorise`)
    .set('Authorization', auth(parent)).send({ receiverName: 'Aunt Winnie', relationship: 'Aunt' });
  const verify = (id: string, code: string) => request().post(`/api/v1/handovers/${id}/verify`)
    .set('Authorization', auth(driver)).send({ code, receiverConfirmed: true });

  it('keeps the code out of driver, admin, notification and audit responses', async () => {
    const created = await issue();
    expect(created.status).toBe(201);
    expect(created.body.code).toBeUndefined();
    expect(created.body.code_hash).toBeUndefined();
    const h = (await mine()).body[0];
    expect(h.code).toMatch(/^\d{6}$/);
    const admin = await tokenFor(fx.admin.email, fx.admin.password);
    const list = await request().get('/api/v1/handovers/school').set('Authorization', auth(admin));
    expect(list.body[0].code).toBeUndefined();
    const records = await db('audit_logs').where({ entity: 'child_handover' });
    expect(JSON.stringify(records)).not.toContain(h.code);
    const notifications = await db('notifications').where({ student_id: fx.studentId });
    expect(JSON.stringify(notifications)).not.toContain(h.code);
  });
  it('requires parent authorisation and records a single-use verified handover', async () => {
    const id = (await issue()).body.id;
    const code = (await mine()).body[0].code;
    expect((await verify(id, code)).status).toBe(409);
    expect((await authorise(id)).status).toBe(200);
    const done = await verify(id, code);
    expect(done.status).toBe(200);
    expect(done.body.status).toBe('verified');
    expect(done.body.receiver_name).toBe('Aunt Winnie');
    expect((await verify(id, code)).status).toBe(409);
    expect((await mine()).body[0].code).toBeUndefined();
    expect((await issue()).status).toBe(409);
  });
  it('commits wrong attempts and locks after five guesses', async () => {
    const id = (await issue()).body.id;
    const code = (await mine()).body[0].code;
    await authorise(id);
    const wrong = code === '000000' ? '999999' : '000000';
    for (let i = 0; i < 5; i++) expect((await verify(id, wrong)).status).toBe(i === 4 ? 429 : 400);
    const row = await db('child_handovers').where({ id }).first();
    expect(row.failed_attempts).toBe(5);
    expect(row.status).toBe('locked');
    expect((await verify(id, code)).status).toBe(409);
  });
  it('rejects expired and revoked codes and hides the secret', async () => {
    const id = (await issue()).body.id;
    const code = (await mine()).body[0].code;
    await authorise(id);
    await db('child_handovers').where({ id }).update({ expires_at: new Date(Date.now() - 1000) });
    expect((await verify(id, code)).status).toBe(409);
    expect((await mine()).body[0].code).toBeUndefined();
    expect((await request().post(`/api/v1/handovers/${id}/revoke`).set('Authorization', auth(parent))).status).toBe(200);
    expect((await verify(id, code)).status).toBe(409);
  });
  it('denies unrelated parents and other schools', async () => {
    const id = (await issue()).body.id;
    const other = await seedFixture();
    const otherParent = await tokenFor(other.parent.email, other.parent.password);
    const res = await request().post(`/api/v1/handovers/${id}/authorise`).set('Authorization', auth(otherParent))
      .send({ receiverName: 'Someone', relationship: 'Parent' });
    expect(res.status).toBe(404);
    // An unrelated parent within the same school must also be refused.
    await db('users').where({ id: other.parent.id }).update({ school_id: fx.schoolId });
    const sameSchoolToken = await tokenFor(other.parent.email, other.parent.password);
    const denied = await request().post(`/api/v1/handovers/${id}/authorise`).set('Authorization', auth(sameSchoolToken))
      .send({ receiverName: 'Someone', relationship: 'Parent' });
    expect(denied.status).toBe(403);
  });
  it('rejects children outside the assigned bus and requires physical receiver confirmation', async () => {
    const id = (await issue()).body.id;
    const code = (await mine()).body[0].code;
    await authorise(id);
    const res = await request().post(`/api/v1/handovers/${id}/verify`).set('Authorization', auth(driver)).send({ code });
    expect(res.status).toBe(400);
    expect((await request().post(`/api/v1/handovers/trips/${tripId}/request`).set('Authorization', auth(driver))
      .send({ studentId: randomUUID() })).status).toBe(404);
  });
  it('preserves the code on repeated requests and rejects verification after the trip ends', async () => {
    const id = (await issue()).body.id;
    const code = (await mine()).body[0].code;
    await issue();
    expect((await mine()).body[0].code).toBe(code);
    await authorise(id);
    await request().post(`/api/v1/trips/${tripId}/end`).set('Authorization', auth(driver));
    expect((await verify(id, code)).status).toBe(403);
    expect((await mine()).body[0].code).toBeUndefined();
  });
  it('allows only one verification when requests arrive concurrently', async () => {
    const id = (await issue()).body.id;
    const code = (await mine()).body[0].code;
    await authorise(id);
    const result = await Promise.all([verify(id, code), verify(id, code)]);
    expect(result.map((r) => r.status).sort()).toEqual([200, 409]);
  });
  it('checks live subscriptions against family and school relationships', async () => {
    const claims = { sub: fx.parent.id, schoolId: fx.schoolId, role: 'parent' as const, name: 'Parent', email: fx.parent.email };
    expect(await canWatchBus(claims, fx.busId)).toBe(true);
    const other = await seedFixture();
    expect(await canWatchBus(claims, other.busId)).toBe(false);
    expect(await canWatchBus({ ...claims, sub: other.parent.id }, fx.busId)).toBe(false);
  });
  it('rejects cross-school guardians and drivers in administrative assignments', async () => {
    const other = await seedFixture();
    const admin = await tokenFor(fx.admin.email, fx.admin.password);
    const student = await request().post('/api/v1/students').set('Authorization', auth(admin))
      .send({ first_name: 'New', last_name: 'Child', bus_id: fx.busId, guardian_ids: [other.parent.id] });
    expect(student.status).toBe(400);
    const bus = await request().post('/api/v1/buses').set('Authorization', auth(admin))
      .send({ plate_number: 'CROSS-SCHOOL', driver_id: other.driver.id });
    expect(bus.status).toBe(400);
  });
  it('keeps parent history scoped to linked buses and school', async () => {
    await request().post(`/api/v1/trips/${tripId}/end`).set('Authorization', auth(driver));
    const other = await seedFixture();
    const otherDriver = await tokenFor(other.driver.email, other.driver.password);
    const otherTrip = (await request().post('/api/v1/trips').set('Authorization', auth(otherDriver))
      .send({ bus_id: other.busId })).body.id;
    await request().post(`/api/v1/trips/${otherTrip}/end`).set('Authorization', auth(otherDriver));
    const history = await request().get('/api/v1/me/history').set('Authorization', auth(parent));
    expect(history.status).toBe(200);
    expect(history.body.map((t: { id: string }) => t.id)).toEqual([tripId]);
  });
  it('does not issue drop-off codes for morning pickup trips', async () => {
    await request().post(`/api/v1/trips/${tripId}/end`).set('Authorization', auth(driver));
    const morning = (await request().post('/api/v1/trips').set('Authorization', auth(driver))
      .send({ bus_id: fx.busId, direction: 'to_school' })).body.id;
    const code = await request().post(`/api/v1/handovers/trips/${morning}/request`)
      .set('Authorization', auth(driver)).send({ studentId: fx.studentId });
    expect(code.status).toBe(400);
  });
  it('detects afternoon departure automatically and rejects starting another driver\'s bus', async () => {
    await request().post(`/api/v1/trips/${tripId}/positions`).set('Authorization', auth(driver)).send({ positions: [
      { lat: 5.0478, lng: 7.9137, recordedAt: new Date(Date.now() - 10_000).toISOString() },
      { lat: 5.0521, lng: 7.9201, recordedAt: new Date(Date.now() - 5_000).toISOString() },
    ] });
    const count = await db('trip_events').where({ trip_id: tripId, type: 'departed_school' }).count({ c: '*' }).first();
    expect(Number(count?.c)).toBe(1);
    const otherBus = randomUUID();
    await db('buses').insert({ id: otherBus, school_id: fx.schoolId, plate_number: 'OTHER' });
    const res = await request().post('/api/v1/trips').set('Authorization', auth(driver)).send({ bus_id: otherBus });
    expect(res.status).toBe(403);
  });
});
