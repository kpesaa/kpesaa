// Test-only PostgreSQL engine: no service or production database is contacted.
import { PGlite } from '@electric-sql/pglite';
const PgClient = require('knex/lib/dialects/postgres');

export class PgliteClient extends PgClient {
  private engine: PGlite | null = null;
  async acquireRawConnection() {
    this.engine ??= new PGlite();
    const engine = this.engine;
    return {
      query: (query: any, callback: any) => {
        const text = typeof query === 'string' ? query : query.text;
        const values = typeof query === 'string' ? [] : (query.values ?? []);
        if (text.includes('CREATE EXTENSION IF NOT EXISTS "pgcrypto"')) {
          return callback(null, { rows: [], rowCount: 0, command: 'CREATE' });
        }
        if (text === 'select current_database() as db') {
          return callback(null, { rows: [{ db: 'bustrack_embedded_test' }], rowCount: 1, command: 'SELECT' });
        }
        engine.query(text, values).then((r) => callback(null, { ...r, rowCount: r.affectedRows ?? r.rows.length,
          command: text.trim().split(/\s+/)[0]?.toUpperCase() }), (e) => callback(e));
      },
      end: (cb: any) => { cb(); },
    };
  }
  async destroyRawConnection() {}
  async destroy() {
    await super.destroy();
    await this.engine?.close();
    this.engine = null;
  }
}
