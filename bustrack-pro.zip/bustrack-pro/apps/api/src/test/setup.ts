import { afterAll, beforeAll, vi } from 'vitest';

vi.mock('../db/knex', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../db/knex')>();
  if (process.env.PGLITE_TEST !== 'true') return actual;
  const { default: knex } = await import('knex');
  const { PgliteClient } = await import('./pglite');
  const embedded = knex({ client: PgliteClient as any, connection: {}, pool: { min: 0, max: 1 } });
  return { ...actual, db: embedded, closeDb: () => embedded.destroy() };
});
import { closeDb, db } from '../db/knex';
import { up as initial } from '../db/migrations/20250101000000_init';
import { up as handovers } from '../db/migrations/20261006000000_handovers';
import { resetDb } from './helpers';

// Schema is migrated by `src/test/migrate.ts` (a tsx pretest step) before vitest runs.
beforeAll(async () => {
  if (process.env.PGLITE_TEST === 'true') {
    await initial(db);
    await handovers(db);
  }
  await resetDb();
});

afterAll(async () => {
  await closeDb();
});
