import { beforeEach, describe, expect, it } from 'vitest';
import { db } from '../db/knex';
import { type Fixture, request, resetDb, seedFixture, tokenFor } from './helpers';

const iso = (msAgo: number) => new Date(Date.now() - msAgo).toISOString();

describe('trip lifecycle + geofence engine', () => {
  let fx: Fixture;
  let driverTok: string;

  beforeEach(async () => {
    await resetDb();
    fx = await seedFixture();
    driverTok = await tokenFor(fx.driver.email, fx.driver.password);
  });

  const start = () =>
    request()
      .post('/api/v1/trips')
      .set('Authorization', `Bearer ${driverTok}`)
      .send({ bus_id: fx.busId, direction: 'to_school' });

  it('starts a trip and blocks a second active trip on the same bus', async () => {
    const first = await start();
    expect(first.status).toBe(201);
    expect(first.body.status).toBe('active');

    const second = await start();
    expect(second.status).toBe(409);
  });

  it('rejects positions with invalid coordinates', async () => {
    const trip = (await start()).body;
    const res = await request()
      .post(`/api/v1/trips/${trip.id}/positions`)
      .set('Authorization', `Bearer ${driverTok}`)
      .send({ positions: [{ lat: 999, lng: 7.9, recordedAt: iso(1000) }] });
    expect(res.status).toBe(400);
  });

  it('ingests a batch, accumulates distance, and persists engine state', async () => {
    const trip = (await start()).body;
    const positions = [
      { lat: 5.0478, lng: 7.9137, speedKph: 20, recordedAt: iso(30_000), source: 'sim' },
      { lat: 5.05, lng: 7.9158, speedKph: 30, recordedAt: iso(20_000), source: 'sim' },
      { lat: 5.052, lng: 7.9195, speedKph: 30, recordedAt: iso(10_000), source: 'sim' },
    ];
    const res = await request()
      .post(`/api/v1/trips/${trip.id}/positions`)
      .set('Authorization', `Bearer ${driverTok}`)
      .send({ positions });
    expect(res.body.accepted).toBe(3);

    const row = await db('trips').where({ id: trip.id }).first();
    expect(Number(row.distance_m)).toBeGreaterThan(400);
    expect(row.engine_state.left_school).toBe(true); // travelled outside the 250 m school geofence
    const count = await db('trip_positions').where({ trip_id: trip.id }).count({ c: '*' }).first();
    expect(Number(count!.c)).toBe(3);
  });

  it('raises approaching/arrived stop events and notifies the guardian', async () => {
    const trip = (await start()).body;
    await request()
      .post(`/api/v1/trips/${trip.id}/positions`)
      .set('Authorization', `Bearer ${driverTok}`)
      .send({
        positions: [
          { lat: 5.05, lng: 7.9158, speedKph: 25, recordedAt: iso(20_000), source: 'sim' },
          { lat: 5.0521, lng: 7.9201, speedKph: 10, recordedAt: iso(5000), source: 'sim' }, // on the stop
        ],
      });

    const events = await db('trip_events').where({ trip_id: trip.id }).pluck('type');
    expect(events).toContain('arrived_stop');

    const notif = await db('notifications')
      .where({ user_id: fx.parent.id, type: 'arrived_stop' })
      .first();
    expect(notif).toBeTruthy();
    const delivery = await db('notification_deliveries')
      .where({ notification_id: notif.id, channel: 'in_app' })
      .first();
    expect(delivery.status).toBe('sent');
  });

  it('only fires "arrived_school" after leaving and returning', async () => {
    const trip = (await start()).body;
    // First ping is at the school — must NOT trigger arrival.
    await request()
      .post(`/api/v1/trips/${trip.id}/positions`)
      .set('Authorization', `Bearer ${driverTok}`)
      .send({ positions: [{ lat: 5.0478, lng: 7.9137, recordedAt: iso(60_000), source: 'sim' }] });
    let events = await db('trip_events').where({ trip_id: trip.id }).pluck('type');
    expect(events).not.toContain('arrived_school');

    // Leave, then come back.
    await request()
      .post(`/api/v1/trips/${trip.id}/positions`)
      .set('Authorization', `Bearer ${driverTok}`)
      .send({
        positions: [
          { lat: 5.0521, lng: 7.9201, recordedAt: iso(40_000), source: 'sim' },
          { lat: 5.0478, lng: 7.9137, recordedAt: iso(10_000), source: 'sim' },
        ],
      });
    events = await db('trip_events').where({ trip_id: trip.id }).pluck('type');
    expect(events).toContain('arrived_school');
  });

  it('ends the trip and records distance', async () => {
    const trip = (await start()).body;
    const res = await request()
      .post(`/api/v1/trips/${trip.id}/end`)
      .set('Authorization', `Bearer ${driverTok}`);
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('completed');
    expect(res.body.ended_at).toBeTruthy();
  });

  it('emergency notifies guardians urgently over multiple channels', async () => {
    const trip = (await start()).body;
    const res = await request()
      .post(`/api/v1/trips/${trip.id}/emergency`)
      .set('Authorization', `Bearer ${driverTok}`)
      .send({ note: 'test' });
    expect(res.status).toBe(202);
    const notif = await db('notifications')
      .where({ user_id: fx.parent.id, type: 'emergency' })
      .first();
    expect(notif).toBeTruthy();
    const channels = await db('notification_deliveries')
      .where({ notification_id: notif.id })
      .pluck('channel');
    expect(channels).toContain('sms');
  });

  it('CSV export returns completed trips', async () => {
    const trip = (await start()).body;
    await request()
      .post(`/api/v1/trips/${trip.id}/end`)
      .set('Authorization', `Bearer ${driverTok}`);
    const adminTok = await tokenFor(fx.admin.email, fx.admin.password);
    const res = await request()
      .get('/api/v1/reports/trips?format=csv')
      .set('Authorization', `Bearer ${adminTok}`);
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/csv/);
    expect(res.text.split('\n')[0]).toContain('duration_minutes');
  });
});
