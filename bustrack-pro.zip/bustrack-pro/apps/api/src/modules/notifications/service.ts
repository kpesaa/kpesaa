import type { NotificationPreferences } from '../../domain/models';
import { logger } from '../../lib/logger';
import { emit } from '../../realtime/io';
import { notifications, prefs, userRepo } from '../../repositories';
import { emailEnabled, sendEmail } from './channels/email';
import { sms, smsEnabled } from './channels/sms';
import { sendWebPush, webPushEnabled } from './channels/webpush';

export interface NotifyInput {
  userId: string;
  schoolId: string;
  type: string;
  title: string;
  body: string;
  tripId?: string | null;
  eventId?: string | null;
  studentId?: string | null;
  data?: Record<string, unknown>;
  /** Channels to attempt in addition to in-app. Defaults to email + web push. */
  channels?: ('email' | 'web_push' | 'sms')[];
  /** Bypass quiet hours (emergencies). */
  urgent?: boolean;
}

function inQuietHours(p: NotificationPreferences, tz: string): boolean {
  if (!p.quiet_hours_start || !p.quiet_hours_end) return false;
  const now = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(new Date());
  const [s, e] = [p.quiet_hours_start, p.quiet_hours_end];
  return s <= e ? now >= s && now < e : now >= s || now < e; // handles overnight windows
}

/**
 * Create one notification for a user and fan it out across their enabled channels.
 * In-app is always delivered (persisted + socket). Returns the notification id.
 */
export async function notifyUser(input: NotifyInput): Promise<string> {
  const [user, pref] = await Promise.all([
    userRepo.findById(input.userId),
    prefs.get(input.userId),
  ]);
  if (!user) return '';

  const notif = await notifications.create({
    school_id: input.schoolId,
    user_id: input.userId,
    trip_id: input.tripId ?? null,
    event_id: input.eventId ?? null,
    student_id: input.studentId ?? null,
    type: input.type,
    title: input.title,
    body: input.body,
    data: input.data ?? {},
  });

  // In-app (socket + it's already persisted).
  await notifications.addDelivery(notif.id, 'in_app', (pref.in_app_enabled || input.urgent) ? 'sent' : 'skipped');
  if (pref.in_app_enabled || input.urgent) {
    emit.toUser(input.userId, 'notification:new', notif);
    emit.toUser(input.userId, 'notification:unread', {
      count: await notifications.unreadCount(input.userId),
    });
  }

  const quiet = !input.urgent && inQuietHours(pref, 'Africa/Lagos');
  const want = new Set(input.channels ?? ['email', 'web_push']);

  // Email
  if (want.has('email')) {
    await deliver(notif.id, 'email', async () => {
      if ((!pref.email_enabled && !input.urgent) || quiet) return 'skipped';
      if (!emailEnabled() || !user.email) return 'skipped';
      await sendEmail(user.email, input.title, `${input.body}\n\n— BusTrack`);
      return 'sent';
    });
  }

  // Web push
  if (want.has('web_push')) {
    await deliver(notif.id, 'web_push', async () => {
      if ((!pref.web_push_enabled && !input.urgent) || quiet) return 'skipped';
      if (!webPushEnabled()) return 'skipped';
      const n = await sendWebPush(input.userId, {
        title: input.title,
        body: input.body,
        data: { ...input.data, notificationId: notif.id, tripId: input.tripId },
      });
      return n > 0 ? 'sent' : 'skipped';
    });
  }

  // SMS
  if (want.has('sms')) {
    await deliver(notif.id, 'sms', async () => {
      if ((!pref.sms_enabled && !input.urgent) || quiet) return 'skipped';
      if (!smsEnabled() || !user.phone) return 'skipped';
      await sms.send(user.phone, `${input.title}: ${input.body}`);
      return 'sent';
    });
  }

  return notif.id;
}

async function deliver(
  notificationId: string,
  channel: string,
  fn: () => Promise<'sent' | 'skipped'>,
): Promise<void> {
  try {
    const status = await fn();
    await notifications.addDelivery(notificationId, channel, status);
  } catch (err) {
    logger.warn({ err, channel }, 'notification channel failed');
    await notifications.addDelivery(notificationId, channel, 'failed', (err as Error).message);
  }
}

/** Notify a set of users with the same content. */
export async function notifyMany(
  userIds: string[],
  input: Omit<NotifyInput, 'userId'>,
): Promise<void> {
  await Promise.all(userIds.map((userId) => notifyUser({ ...input, userId })));
}
