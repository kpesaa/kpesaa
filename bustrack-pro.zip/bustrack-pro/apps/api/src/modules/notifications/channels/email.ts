import nodemailer, { type Transporter } from 'nodemailer';
import { env } from '../../../config/env';
import { logger } from '../../../lib/logger';

let transporter: Transporter | null = null;
let usingEthereal = false;

export async function initEmail(): Promise<void> {
  if (env.SMTP_HOST) {
    transporter = nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: env.SMTP_PORT,
      secure: env.SMTP_SECURE,
      auth: env.SMTP_USER ? { user: env.SMTP_USER, pass: env.SMTP_PASS } : undefined,
    });
    logger.info({ host: env.SMTP_HOST }, 'Email transport ready (SMTP)');
    return;
  }
  if (env.isProd) {
    logger.warn('No SMTP_HOST configured — email notifications are disabled');
    return;
  }
  // Dev convenience: real SMTP not configured → capture to an Ethereal inbox.
  try {
    const test = await nodemailer.createTestAccount();
    transporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: { user: test.user, pass: test.pass },
    });
    usingEthereal = true;
    logger.info('Email transport ready (Ethereal test inbox — previews logged per message)');
  } catch (err) {
    logger.warn({ err }, 'Could not create Ethereal account; email disabled');
  }
}

export async function sendEmail(
  to: string,
  subject: string,
  text: string,
  html?: string,
): Promise<void> {
  if (!transporter) throw new Error('email transport not configured');
  const info = await transporter.sendMail({ from: env.MAIL_FROM, to, subject, text, html });
  if (usingEthereal) {
    logger.info({ to, preview: nodemailer.getTestMessageUrl(info) }, 'email sent (ethereal)');
  }
}

export const emailEnabled = () => transporter !== null;
