import { env } from '../../../config/env';
import { logger } from '../../../lib/logger';

export interface SmsProvider {
  send(to: string, message: string): Promise<void>;
}

/** Default: prints to the log. Swap SMS_PROVIDER=termii for real delivery. */
const logProvider: SmsProvider = {
  async send(to, message) {
    logger.info({ to, message }, '[SMS:log] would send');
  },
};

const termiiProvider: SmsProvider = {
  async send(to, message) {
    if (!env.TERMII_API_KEY) throw new Error('TERMII_API_KEY not set');
    const res = await fetch('https://api.ng.termii.com/api/sms/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to,
        from: env.TERMII_SENDER_ID,
        sms: message,
        type: 'plain',
        channel: 'generic',
        api_key: env.TERMII_API_KEY,
      }),
    });
    if (!res.ok) throw new Error(`Termii ${res.status}: ${await res.text()}`);
  },
};

export const sms: SmsProvider = env.SMS_PROVIDER === 'termii' ? termiiProvider : logProvider;
export const smsEnabled = () => env.SMS_PROVIDER === 'log' || Boolean(env.TERMII_API_KEY);
