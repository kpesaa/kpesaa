import webpush from 'web-push';
import { env } from '../../../config/env';
import { logger } from '../../../lib/logger';
import { pushSubs } from '../../../repositories';

let configured = false;

export function initWebPush(): void {
  if (env.VAPID_PUBLIC_KEY && env.VAPID_PRIVATE_KEY) {
    webpush.setVapidDetails(env.VAPID_SUBJECT, env.VAPID_PUBLIC_KEY, env.VAPID_PRIVATE_KEY);
    configured = true;
    logger.info('Web Push configured (VAPID)');
  } else {
    logger.warn('VAPID keys not set — web push disabled (run: npx web-push generate-vapid-keys)');
  }
}

export const webPushEnabled = () => configured;

export interface PushPayload {
  title: string;
  body: string;
  data?: Record<string, unknown>;
}

export async function sendWebPush(userId: string, payload: PushPayload): Promise<number> {
  if (!configured) throw new Error('web push not configured');
  const subs = await pushSubs.forUser(userId);
  let delivered = 0;
  await Promise.all(
    subs.map(async (s) => {
      try {
        await webpush.sendNotification(
          { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          JSON.stringify(payload),
        );
        delivered++;
      } catch (err) {
        const status = (err as { statusCode?: number }).statusCode;
        if (status === 404 || status === 410) {
          await pushSubs.removeByEndpoint(s.endpoint); // subscription gone
        } else {
          logger.warn({ err, userId }, 'web push send failed');
        }
      }
    }),
  );
  return delivered;
}
