import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, randomInt, randomUUID, timingSafeEqual } from 'node:crypto';
import type { Knex } from 'knex';
import { env } from '../../config/env';
import { db } from '../../db/knex';
import { HttpError, badRequest, conflict, forbidden, notFound } from '../../domain/common';
import { emit } from '../../realtime/io';
import { notifyMany } from '../notifications/service';

const key = () => createHash('sha256').update(env.HANDOVER_CODE_SECRET ?? env.JWT_ACCESS_SECRET).digest();
const digest = (id: string, code: string) => createHmac('sha256', key()).update(`${id}:${code}`).digest('hex');

function encrypt(id: string, code: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key(), iv);
  cipher.setAAD(Buffer.from(id));
  const data = Buffer.concat([cipher.update(code, 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), data]).toString('base64');
}

function decrypt(id: string, encoded: string): string {
  const data = Buffer.from(encoded, 'base64');
  const cipher = createDecipheriv('aes-256-gcm', key(), data.subarray(0, 12));
  cipher.setAAD(Buffer.from(id));
  cipher.setAuthTag(data.subarray(12, 28));
  return Buffer.concat([cipher.update(data.subarray(28)), cipher.final()]).toString('utf8');
}

function present(row: Record<string, any>, reveal = false) {
  const { code_hash, code_ciphertext, ...safe } = row;
  const expired = new Date(row.expires_at).getTime() <= Date.now();
  return {
    ...safe,
    status: expired && ['pending', 'authorised'].includes(row.status) ? 'expired' : row.status,
    code: reveal && !expired && ['pending', 'authorised'].includes(row.status)
      ? decrypt(row.id, code_ciphertext) : undefined,
  };
}

async function driverTrip(trx: Knex, tripId: string, driverId: string, lock = false) {
  const driver = await trx('users').where({ id: driverId, role: 'driver', status: 'active' }).first();
  if (!driver) throw forbidden('Driver account is not active');
  const query = trx('trips').where({ id: tripId, driver_id: driverId, status: 'active' });
  const trip = await (lock ? query.forUpdate() : query).first();
  if (!trip) throw forbidden('This is not your active trip');
  if (trip.direction !== 'from_school') throw badRequest('Handover codes are for afternoon drop-off trips');
  return trip;
}

async function guardian(trx: Knex, studentId: string, userId: string, schoolId: string) {
  const linked = await trx('guardianships as g').join('students as s', 's.id', 'g.student_id')
    .join('users as u', 'u.id', 'g.guardian_id')
    .where({ 'g.student_id': studentId, 'g.guardian_id': userId, 's.school_id': schoolId,
      'u.school_id': schoolId, 'u.role': 'parent', 'u.status': 'active' }).first();
  if (!linked) throw forbidden('Only a linked guardian can access this handover');
}

async function audit(trx: Knex, row: Record<string, any>, actorId: string, action: string, meta = {}) {
  await trx('audit_logs').insert({ school_id: row.school_id, actor_id: actorId, action,
    entity: 'child_handover', entity_id: row.id, meta: JSON.stringify(meta) });
}

function broadcast(row: Record<string, any>) {
  const payload = { id: row.id, tripId: row.trip_id, studentId: row.student_id };
  emit.toStudentGuardians(row.student_id, 'handover:updated', payload);
  emit.toUser(row.requested_by, 'handover:updated', payload);
  emit.toDispatch(row.school_id, 'handover:updated', payload);
}

export async function issueCode(tripId: string, studentId: string, driverId: string) {
  const row = await db.transaction(async (trx) => {
    const trip = await driverTrip(trx, tripId, driverId, true);
    const child = await trx('students').where({ id: studentId, school_id: trip.school_id,
      bus_id: trip.bus_id, status: 'active' }).first();
    if (!child) throw notFound('Child is not assigned to this bus');
    const hasGuardian = await trx('guardianships as g').join('users as u', 'u.id', 'g.guardian_id')
      .where({ 'g.student_id': studentId, 'u.school_id': trip.school_id, 'u.role': 'parent', 'u.status': 'active' }).first();
    if (!hasGuardian) throw conflict('Link an active guardian before requesting a code');
    const existing = await trx('child_handovers').where({ trip_id: tripId, student_id: studentId }).first();
    if (existing?.status === 'verified') throw conflict('This child has already been handed over');
    if (existing && ['pending', 'authorised'].includes(existing.status) && new Date(existing.expires_at).getTime() > Date.now()) {
      return existing; // Repeat taps do not invalidate the parent's code.
    }
    if (existing && Date.now() - new Date(existing.updated_at).getTime() < 60_000) {
      throw new HttpError(429, 'Wait one minute before requesting a replacement code');
    }
    const id = existing?.id ?? randomUUID();
    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
    const values = { id, school_id: trip.school_id, trip_id: tripId, student_id: studentId,
      requested_by: driverId, code_hash: digest(id, code), code_ciphertext: encrypt(id, code),
      expires_at: new Date(Date.now() + env.HANDOVER_CODE_TTL_MINUTES * 60_000),
      status: 'pending', failed_attempts: 0, authorised_by: null, receiver_name: null,
      receiver_relationship: null, authorised_at: null, verified_by: null, verified_at: null,
      updated_at: new Date() };
    const [saved] = existing
      ? await trx('child_handovers').where({ id }).update(values).returning('*')
      : await trx('child_handovers').insert(values).returning('*');
    await audit(trx, saved, driverId, 'code_requested');
    return saved;
  });
  broadcast(row);
  // The secret is never placed in email, push payloads, notifications or audit logs.
  const ids = await db('guardianships as g').join('users as u', 'u.id', 'g.guardian_id')
    .where({ 'g.student_id': studentId, 'g.notify': true, 'u.school_id': row.school_id,
      'u.role': 'parent', 'u.status': 'active' }).pluck('u.id');
  // Notification once per generated version; idempotent repeated requests only update the UI.
  const alreadySent = await db('notifications').where({ type: 'handover_requested', student_id: studentId })
    .where('created_at', '>=', row.updated_at).first();
  if (!alreadySent) await notifyMany(ids, { schoolId: row.school_id, studentId, tripId,
    type: 'handover_requested', title: 'Choose who will receive your child',
    body: 'The driver requested a handover code. Open Handover in BusTrack, name the receiving adult and share the code privately.' });
  return present(row);
}

export async function myHandovers(userId: string, schoolId: string) {
  const rows = await db('child_handovers as h').join('guardianships as g', 'g.student_id', 'h.student_id')
    .join('students as s', 's.id', 'h.student_id').join('trips as t', 't.id', 'h.trip_id')
    .join('users as u', 'u.id', 'g.guardian_id')
    .where({ 'g.guardian_id': userId, 'h.school_id': schoolId, 's.school_id': schoolId, 'u.school_id': schoolId, 'u.role': 'parent', 'u.status': 'active' })
    .where('h.created_at', '>', db.raw("now() - interval '7 days'"))
    .select('h.*', 's.first_name', 's.last_name', 't.status as trip_status').orderBy('h.created_at', 'desc');
  return rows.map((r) => present(r, r.trip_status === 'active'));
}

export async function roster(tripId: string, driverId: string) {
  const trip = await driverTrip(db, tripId, driverId);
  const rows = await db('students as s').leftJoin('child_handovers as h', function () {
    this.on('h.student_id', '=', 's.id').andOn('h.trip_id', '=', db.raw('?', [tripId]));
  }).where({ 's.bus_id': trip.bus_id, 's.school_id': trip.school_id, 's.status': 'active' })
    .select('s.id as student_id', 's.first_name', 's.last_name', 's.grade', 'h.id', 'h.status',
      'h.expires_at', 'h.receiver_name', 'h.receiver_relationship', 'h.verified_at', 'h.failed_attempts')
    .orderBy('s.first_name');
  return rows.map((r) => ({ ...r, status: r.expires_at && new Date(r.expires_at).getTime() <= Date.now()
    && ['pending', 'authorised'].includes(r.status) ? 'expired' : r.status ?? 'not_requested' }));
}

export async function authorise(id: string, userId: string, schoolId: string, receiverName: string, relationship: string) {
  const row = await db.transaction(async (trx) => {
    const h = await trx('child_handovers').where({ id, school_id: schoolId }).forUpdate().first();
    if (!h) throw notFound('Handover not found');
    await guardian(trx, h.student_id, userId, schoolId);
    const trip = await trx('trips').where({ id: h.trip_id, status: 'active' }).first();
    if (!trip || new Date(h.expires_at).getTime() <= Date.now()) throw conflict('Code has expired or the trip has ended');
    if (!['pending', 'authorised'].includes(h.status)) throw conflict('Request a new code from the driver');
    const [saved] = await trx('child_handovers').where({ id }).update({ status: 'authorised',
      authorised_by: userId, receiver_name: receiverName, receiver_relationship: relationship,
      authorised_at: new Date(), updated_at: new Date() }).returning('*');
    await audit(trx, saved, userId, 'receiver_authorised', { receiverName, relationship });
    return saved;
  });
  broadcast(row);
  return present(row, true);
}

export async function revoke(id: string, userId: string, schoolId: string) {
  const row = await db.transaction(async (trx) => {
    const h = await trx('child_handovers').where({ id, school_id: schoolId }).forUpdate().first();
    if (!h) throw notFound('Handover not found');
    await guardian(trx, h.student_id, userId, schoolId);
    if (h.status === 'verified') throw conflict('Completed handovers cannot be revoked');
    const [saved] = await trx('child_handovers').where({ id }).update({ status: 'revoked',
      code_ciphertext: '', updated_at: new Date() }).returning('*');
    await audit(trx, saved, userId, 'code_revoked');
    return saved;
  });
  broadcast(row);
  return present(row);
}

export async function verify(id: string, driverId: string, code: string) {
  // Return validation failures from the transaction so failed attempts are committed.
  const result = await db.transaction(async (trx) => {
    // Lock trip before handover, matching issueCode's lock order.
    const ref = await trx('child_handovers').where({ id }).first();
    if (!ref) throw notFound('Handover not found');
    const trip = await driverTrip(trx, ref.trip_id, driverId, true);
    const h = await trx('child_handovers').where({ id, school_id: trip.school_id }).forUpdate().first();
    if (!h || h.status !== 'authorised' || new Date(h.expires_at).getTime() <= Date.now()) {
      return { error: 'Code is expired, used, locked, revoked or awaiting parent authorisation', status: 409 };
    }
    const actual = Buffer.from(digest(h.id, code), 'hex');
    const expected = Buffer.from(h.code_hash, 'hex');
    if (!timingSafeEqual(actual, expected)) {
      const attempts = h.failed_attempts + 1;
      await trx('child_handovers').where({ id }).update({ failed_attempts: attempts,
        status: attempts >= 5 ? 'locked' : 'authorised', updated_at: new Date() });
      await audit(trx, h, driverId, 'code_rejected', { attempts });
      return { error: attempts >= 5 ? 'Code locked after five incorrect attempts. Contact the parent and school.' : 'Incorrect code. Child handover has not been confirmed.', status: attempts >= 5 ? 429 : 400 };
    }
    const [saved] = await trx('child_handovers').where({ id }).update({ status: 'verified',
      verified_by: driverId, verified_at: new Date(), code_ciphertext: '', updated_at: new Date() }).returning('*');
    await audit(trx, saved, driverId, 'child_handed_over', { receiverName: saved.receiver_name });
    return { row: saved };
  });
  if ('error' in result) throw new HttpError(result.status!, result.error!);
  const row = result.row;
  broadcast(row);
  const ids = await db('guardianships').where({ student_id: row.student_id, notify: true }).pluck('guardian_id');
  await notifyMany(ids, { schoolId: row.school_id, studentId: row.student_id, tripId: row.trip_id,
    type: 'child_handed_over', title: 'Child handover confirmed',
    body: `The driver confirmed handover to ${row.receiver_name}. You can review the record in Handover.` });
  return present(row);
}

export async function schoolHandovers(schoolId: string) {
  const rows = await db('child_handovers as h').join('students as s', 's.id', 'h.student_id')
    .join('users as d', 'd.id', 'h.requested_by').where('h.school_id', schoolId)
    .select('h.*', 's.first_name', 's.last_name', 'd.name as driver_name')
    .orderBy('h.created_at', 'desc').limit(200);
  return rows.map((r) => present(r));
}
