import { createHash, randomBytes } from 'node:crypto';
import jwt, { type SignOptions } from 'jsonwebtoken';
import { env } from '../../config/env';
import type { Role } from '../../domain/common';

export interface AccessClaims {
  sub: string;
  role: Role;
  schoolId: string | null;
  name: string;
  email: string;
}

export function signAccessToken(claims: AccessClaims): string {
  return jwt.sign(claims, env.JWT_ACCESS_SECRET, {
    expiresIn: env.ACCESS_TOKEN_TTL,
  } as SignOptions);
}

export function verifyAccessToken(token: string): AccessClaims {
  return jwt.verify(token, env.JWT_ACCESS_SECRET) as AccessClaims;
}

/** Opaque refresh token: random string to the client, only its hash stored. */
export function newRefreshToken(): { token: string; hash: string; expiresAt: Date } {
  const token = randomBytes(48).toString('base64url');
  return { token, hash: hashToken(token), expiresAt: refreshExpiry() };
}

export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

function refreshExpiry(): Date {
  const ttl = env.REFRESH_TOKEN_TTL;
  const days = ttl.endsWith('d') ? Number.parseInt(ttl, 10) : 30;
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
}
