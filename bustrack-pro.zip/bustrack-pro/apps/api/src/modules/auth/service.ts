import bcrypt from 'bcryptjs';
import { env } from '../../config/env';
import { HttpError, badRequest, unauthorized } from '../../domain/common';
import type { PublicUser, User } from '../../domain/models';
import { logger } from '../../lib/logger';
import { prefs, refreshTokens, userRepo } from '../../repositories';
import { type AccessClaims, hashToken, newRefreshToken, signAccessToken } from './tokens';

export function toPublicUser(u: User): PublicUser {
  const { password_hash, failed_login_attempts, locked_until, ...rest } = u;
  return rest;
}

export function claimsFor(u: User): AccessClaims {
  return { sub: u.id, role: u.role, schoolId: u.school_id, name: u.name, email: u.email };
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

interface LoginCtx {
  userAgent?: string;
  ip?: string;
}

let dummyHashPromise: Promise<string> | null = null;
const dummyHash = () => (dummyHashPromise ??= bcrypt.hash('invalid-user-placeholder', 12));

export async function login(email: string, password: string, ctx: LoginCtx) {
  const user = await userRepo.byEmail(email);
  // Equalise timing whether or not the user exists (mitigates account enumeration).
  const ok = await bcrypt.compare(password, user?.password_hash ?? (await dummyHash()));

  if (!user || user.status === 'disabled') throw unauthorized('Invalid email or password');

  if (user.locked_until && new Date(user.locked_until) > new Date()) {
    throw new HttpError(
      429,
      'Account temporarily locked after too many failed attempts. Try again later.',
    );
  }

  if (!ok) {
    const attempts = user.failed_login_attempts + 1;
    const lock =
      attempts >= env.LOGIN_MAX_ATTEMPTS
        ? new Date(Date.now() + env.LOGIN_LOCK_MINUTES * 60_000)
        : null;
    await userRepo.bumpFailed(user.id, lock);
    throw unauthorized('Invalid email or password');
  }

  await userRepo.touchLogin(user.id);
  await prefs.get(user.id); // ensure prefs row exists

  return issueSession(user, ctx);
}

export async function issueSession(user: User, ctx: LoginCtx) {
  const accessToken = signAccessToken(claimsFor(user));
  const refresh = newRefreshToken();
  await refreshTokens.create({
    user_id: user.id,
    token_hash: refresh.hash,
    expires_at: refresh.expiresAt,
    user_agent: ctx.userAgent,
    ip: ctx.ip,
  });
  return { accessToken, refreshToken: refresh.token, user: toPublicUser(user) };
}

export async function refresh(rawToken: string, ctx: LoginCtx) {
  if (!rawToken) throw unauthorized('Missing refresh token');
  const hash = hashToken(rawToken);
  const stored = await refreshTokens.findValid(hash);
  if (!stored) throw unauthorized('Refresh token invalid or expired');

  const user = await userRepo.findById(stored.user_id);
  if (!user || user.status === 'disabled') throw unauthorized('Account unavailable');

  // Rotate.
  await refreshTokens.revoke(hash);
  return issueSession(user, ctx);
}

export async function logout(rawToken: string): Promise<void> {
  if (rawToken) await refreshTokens.revoke(hashToken(rawToken));
}

export async function changePassword(userId: string, currentPassword: string, newPassword: string) {
  const user = await userRepo.findById(userId);
  if (!user) throw unauthorized();
  const ok = await bcrypt.compare(currentPassword, user.password_hash);
  if (!ok) throw badRequest('Current password is incorrect');
  await userRepo.update(userId, { password_hash: await hashPassword(newPassword) });
  await refreshTokens.revokeAllForUser(userId);
  logger.info({ userId }, 'password changed');
}
