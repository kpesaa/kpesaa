import { env } from '../../config/env';
import { db } from '../../db/knex';
import type { Bus, School, Stop, Student, Trip, TripEventType } from '../../domain/models';
import { logger } from '../../lib/logger';
import { emit } from '../../realtime/io';
import { buses, guardianships, schools, tripEvents, trips } from '../../repositories';
import { type LatLng, distanceToPolyline, etaMinutes, haversine } from '../geo/geo';
import { notifyMany } from '../notifications/service';

interface StudentOnBus extends Student {
  stop: Stop | null;
}

export interface GeofenceContext {
  school: School;
  busLabel: string;
  students: StudentOnBus[];
  routePath: LatLng[];
}

const APPROACH_ETA_MIN = 3;

/** Load everything the engine needs for a trip, once. */
export async function loadContext(trip: Trip): Promise<GeofenceContext | null> {
  const [school, bus, students, route] = await Promise.all([
    schools.findById(trip.school_id) as Promise<School | undefined>,
    buses.findById(trip.bus_id) as Promise<Bus | undefined>,
    studentsOnTrip(trip),
    trip.route_id ? db('routes').where({ id: trip.route_id }).first() : Promise.resolve(null),
  ]);
  if (!school) return null;
  const path: [number, number][] = route?.path ?? [];
  return {
    school,
    busLabel: bus ? bus.label || `Bus ${bus.plate_number}` : 'The school bus',
    students,
    routePath: path.map(([lat, lng]) => ({ lat, lng })),
  };
}

/**
 * Evaluate one position against the geofences. Mutates `state` (engine bookkeeping)
 * and fires deduped events + notifications. Returns nothing; caller persists `state`.
 */
export async function evaluateAt(
  trip: Trip,
  ctx: GeofenceContext,
  pos: LatLng & { speedKph: number },
  state: Trip['engine_state'],
): Promise<void> {
  await checkSchool(trip, ctx, pos, state);
  await checkStops(trip, ctx, pos);
  await checkDeviation(trip, ctx, pos, state);
}

/** Convenience: load context, evaluate a single position, persist state. */
export async function evaluate(trip: Trip, pos: LatLng & { speedKph: number }): Promise<void> {
  const ctx = await loadContext(trip);
  if (!ctx) return;
  const state = { ...trip.engine_state };
  const before = JSON.stringify(state);
  await evaluateAt(trip, ctx, pos, state);
  if (JSON.stringify(state) !== before) {
    await persistState(trip.id, state);
  }
}

export async function persistState(tripId: string, state: Trip['engine_state']): Promise<void> {
  await trips
    .query()
    .where('id', tripId)
    .update({
      engine_state: db.raw('?::jsonb', [JSON.stringify(state)]),
      updated_at: db.fn.now(),
    });
}

// ── school arrival / departure ───────────────────────────────
async function checkSchool(
  trip: Trip,
  ctx: GeofenceContext,
  pos: LatLng,
  state: Trip['engine_state'],
): Promise<void> {
  const dist = haversine(pos, { lat: ctx.school.lat, lng: ctx.school.lng });
  const radius = ctx.school.radius_m || env.SCHOOL_RADIUS_M;
  if (dist > radius) {
    if (!state.left_school && trip.direction === 'from_school') {
      await fire(trip, ctx, { type: 'departed_school', dedupeKey: 'departed_school', pos,
        title: 'Bus departed school', body: `${ctx.busLabel} has left school for afternoon drop-off.`,
        audience: 'guardians+dispatch' });
    }
    state.left_school = true;
    return;
  }
  if (state.left_school) {
    await fire(trip, ctx, {
      type: 'arrived_school',
      dedupeKey: 'arrived_school',
      pos,
      title: 'Bus arrived at school',
      body: `${ctx.busLabel} has arrived at ${ctx.school.name} safely.`,
      audience: 'guardians+dispatch',
    });
  }
}

// ── stop approach / arrival ──────────────────────────────────
async function checkStops(
  trip: Trip,
  ctx: GeofenceContext,
  pos: LatLng & { speedKph: number },
): Promise<void> {
  for (const s of ctx.students) {
    if (!s.stop) continue;
    const stop = s.stop;
    const dist = haversine(pos, { lat: stop.lat, lng: stop.lng });
    const radius = stop.radius_m || env.DEFAULT_STOP_RADIUS_M;
    const eta = etaMinutes(dist, pos.speedKph);
    const child = `${s.first_name} ${s.last_name}`;

    if (dist <= radius) {
      await fire(trip, ctx, {
        type: 'arrived_stop',
        dedupeKey: `arrived_stop:${stop.id}:${s.id}`,
        stopId: stop.id,
        studentId: s.id,
        pos,
        title: `Bus at ${child}'s stop`,
        body: `${ctx.busLabel} has reached ${stop.name}${
          trip.direction === 'from_school' ? ` to drop off ${child}` : ` to pick up ${child}`
        }.`,
        audience: 'student',
      });
    } else if (dist <= radius * 4 || eta <= APPROACH_ETA_MIN) {
      const when = eta <= 1 ? 'less than a minute' : `about ${eta} min`;
      await fire(trip, ctx, {
        type: 'approaching_stop',
        dedupeKey: `approaching_stop:${stop.id}:${s.id}`,
        stopId: stop.id,
        studentId: s.id,
        pos,
        title: `Bus approaching ${child}'s stop`,
        body: `${ctx.busLabel} is ${when} from ${stop.name}. Please have ${child} ready.`,
        audience: 'student',
      });
    }
  }
}

// ── route deviation ──────────────────────────────────────────
async function checkDeviation(
  trip: Trip,
  ctx: GeofenceContext,
  pos: LatLng,
  state: Trip['engine_state'],
): Promise<void> {
  if (ctx.routePath.length < 2) return;
  const off = distanceToPolyline(pos, ctx.routePath);
  const strikes = state.deviation_strikes ?? 0;

  if (off > env.ROUTE_DEVIATION_M) {
    state.deviation_strikes = strikes + 1;
    if (state.deviation_strikes >= 3 && !state.deviation_active) {
      state.deviation_active = true;
      await fire(trip, ctx, {
        type: 'route_deviation',
        dedupeKey: `route_deviation:${Date.now()}`,
        pos,
        title: 'Bus off planned route',
        body: `${ctx.busLabel} is ${Math.round(off)} m off its planned route.`,
        audience: 'guardians+dispatch',
      });
    }
  } else {
    state.deviation_strikes = 0;
    state.deviation_active = false;
  }
}

// ── event + notification dispatch ────────────────────────────
interface FireOpts {
  type: TripEventType;
  dedupeKey: string;
  pos: LatLng;
  title: string;
  body: string;
  audience: 'guardians+dispatch' | 'student' | 'dispatch';
  stopId?: string;
  studentId?: string;
}

async function fire(trip: Trip, _ctx: GeofenceContext, o: FireOpts): Promise<void> {
  const event = await tripEvents.record({
    trip_id: trip.id,
    school_id: trip.school_id,
    type: o.type,
    stop_id: o.stopId ?? null,
    student_id: o.studentId ?? null,
    lat: o.pos.lat,
    lng: o.pos.lng,
    payload: { title: o.title, body: o.body },
    dedupe_key: o.dedupeKey,
  });
  if (!event) return; // already handled

  emit.toDispatch(trip.school_id, 'trip:event', event);
  if (o.studentId) emit.toStudentGuardians(o.studentId, 'trip:event', event);
  logger.info({ trip: trip.id, type: o.type }, 'geofence event');

  const notif = {
    schoolId: trip.school_id,
    type: o.type,
    title: o.title,
    body: o.body,
    tripId: trip.id,
    eventId: event.id,
    studentId: o.studentId ?? null,
    data: { stopId: o.stopId, lat: o.pos.lat, lng: o.pos.lng },
  };

  if (o.audience === 'dispatch') {
    await notifyMany(await dispatcherIds(trip.school_id), notif);
  } else if (o.audience === 'student' && o.studentId) {
    await notifyMany(await guardianships.guardianIdsForStudent(o.studentId), notif);
  } else if (o.audience === 'guardians+dispatch') {
    const ids = new Set([
      ...(await guardiansOnTrip(trip)),
      ...(await dispatcherIds(trip.school_id)),
    ]);
    await notifyMany([...ids], notif);
  }
}

// ── helpers ──────────────────────────────────────────────────
async function studentsOnTrip(trip: Trip): Promise<StudentOnBus[]> {
  const rows = (await db<Student>('students').where({
    bus_id: trip.bus_id,
    status: 'active',
  })) as Student[];
  const stopField = trip.direction === 'from_school' ? 'dropoff_stop_id' : 'pickup_stop_id';
  const stopIds = [...new Set(rows.map((r) => r[stopField]).filter(Boolean) as string[])];
  const stopMap = new Map<string, Stop>();
  if (stopIds.length) {
    for (const s of (await db<Stop>('stops').whereIn('id', stopIds)) as Stop[])
      stopMap.set(s.id, s);
  }
  return rows.map((r) => ({ ...r, stop: stopMap.get(r[stopField] as string) ?? null }));
}

async function guardiansOnTrip(trip: Trip): Promise<string[]> {
  const students = (await db<Student>('students').where({ bus_id: trip.bus_id })) as Student[];
  const ids = new Set<string>();
  for (const s of students) {
    for (const g of await guardianships.guardianIdsForStudent(s.id)) ids.add(g);
  }
  return [...ids];
}

export async function dispatcherIds(schoolId: string): Promise<string[]> {
  const rows = await db('users')
    .where({ school_id: schoolId, status: 'active' })
    .whereIn('role', ['admin', 'dispatcher'])
    .select('id');
  return rows.map((r) => r.id as string);
}
