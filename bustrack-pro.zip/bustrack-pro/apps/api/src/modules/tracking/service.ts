import { db } from '../../db/knex';
import { badRequest, conflict, forbidden, notFound } from '../../domain/common';
import type { Bus, Trip } from '../../domain/models';
import { logger } from '../../lib/logger';
import { emit } from '../../realtime/io';
import { buses, guardianships, positions, tripEvents, tripRepo } from '../../repositories';
import { haversine } from '../geo/geo';
import { notifyMany } from '../notifications/service';
import { dispatcherIds, evaluateAt, loadContext, persistState } from './geofence';

export interface PositionInput {
  lat: number;
  lng: number;
  speedKph?: number;
  headingDeg?: number;
  accuracyM?: number;
  recordedAt: string; // ISO
  source?: 'device' | 'batch' | 'sim';
}

export async function startTrip(args: {
  schoolId: string;
  driverId: string;
  busId: string;
  routeId?: string | null;
  direction?: Trip['direction'];
}): Promise<Trip> {
  const bus = (await buses.findById(args.busId, { school_id: args.schoolId })) as Bus | undefined;
  if (!bus) throw notFound('Bus not found');
  if (bus.status !== 'active') throw badRequest('Bus is not active');
  if (bus.driver_id !== args.driverId) throw forbidden('This bus is assigned to another driver');
  if (args.routeId && !(await db('routes').where({ id: args.routeId, school_id: args.schoolId, active: true }).first())) {
    throw badRequest('Route must be active and belong to your school');
  }

  const existing = await tripRepo.activeForBus(args.busId);
  if (existing) throw conflict('This bus already has an active trip');
  const driverBusy = await tripRepo.activeForDriver(args.driverId);
  if (driverBusy) throw conflict('You already have an active trip');

  const routeId = args.routeId ?? (await defaultRouteForBus(args.busId));

  const trip = await tripRepo.create({
    school_id: args.schoolId,
    bus_id: args.busId,
    driver_id: args.driverId,
    route_id: routeId,
    direction: args.direction ?? 'to_school',
    status: 'active',
    started_at: db.fn.now() as never,
  });

  await tripEvents.record({
    trip_id: trip.id,
    school_id: args.schoolId,
    type: 'trip_started',
    stop_id: null,
    student_id: null,
    lat: null,
    lng: null,
    payload: { direction: trip.direction },
    dedupe_key: 'trip_started',
  });

  emit.toDispatch(args.schoolId, 'trip:started', { trip, bus });
  logger.info({ trip: trip.id, bus: bus.plate_number }, 'trip started');
  return trip;
}

export async function markDepartedSchool(tripId: string, driverId: string): Promise<void> {
  const trip = await requireDriverTrip(tripId, driverId);
  const ev = await tripEvents.record({
    trip_id: trip.id,
    school_id: trip.school_id,
    type: 'departed_school',
    stop_id: null,
    student_id: null,
    lat: trip.last_lat,
    lng: trip.last_lng,
    payload: {},
    dedupe_key: 'departed_school',
  });
  if (!ev) return;
  const guardianIds = await guardiansForTrip(trip.bus_id);
  await notifyMany(guardianIds, {
    schoolId: trip.school_id,
    type: 'departed_school',
    title: 'Bus departed school',
    body: 'The school bus has left the school and is now on its way.',
    tripId: trip.id,
    eventId: ev.id,
  });
  emit.toDispatch(trip.school_id, 'trip:event', ev);
}

/** Manual "we've arrived at school" button — triggers the arrival geofence deterministically. */
export async function markArrivedSchool(tripId: string, driverId: string): Promise<void> {
  const trip = await requireDriverTrip(tripId, driverId);
  const ctx = await loadContext(trip);
  if (!ctx) return;
  const state = { ...trip.engine_state, left_school: true };
  await evaluateAt(trip, ctx, { lat: ctx.school.lat, lng: ctx.school.lng, speedKph: 0 }, state);
  await persistState(trip.id, state);
}

export async function raiseEmergency(
  tripId: string,
  driverId: string,
  note?: string,
): Promise<void> {
  const trip = await requireDriverTrip(tripId, driverId);
  const ev = await tripEvents.record({
    trip_id: trip.id,
    school_id: trip.school_id,
    type: 'emergency',
    stop_id: null,
    student_id: null,
    lat: trip.last_lat,
    lng: trip.last_lng,
    payload: { note: note ?? null, at: new Date().toISOString() },
    dedupe_key: `emergency:${Date.now()}`,
  });
  const audience = [
    ...new Set([
      ...(await guardiansForTrip(trip.bus_id)),
      ...(await dispatcherIds(trip.school_id)),
    ]),
  ];
  await notifyMany(audience, {
    schoolId: trip.school_id,
    type: 'emergency',
    title: '🚨 Emergency alert from the school bus',
    body: note
      ? `The driver reported an emergency: ${note}. Please contact the school immediately.`
      : 'The driver has raised an emergency signal. Please contact the school immediately.',
    tripId: trip.id,
    eventId: ev?.id ?? null,
    channels: ['email', 'web_push', 'sms'],
    urgent: true,
  });
  emit.toSchool(trip.school_id, 'trip:emergency', { tripId: trip.id, ...ev });
}

export async function endTrip(tripId: string, driverId: string): Promise<Trip> {
  const trip = await requireDriverTrip(tripId, driverId);
  const updated = (await tripRepo.update(trip.id, {
    status: 'completed',
    ended_at: db.fn.now() as never,
  })) as Trip;
  await tripEvents.record({
    trip_id: trip.id,
    school_id: trip.school_id,
    type: 'trip_ended',
    stop_id: null,
    student_id: null,
    lat: trip.last_lat,
    lng: trip.last_lng,
    payload: { distance_m: Math.round(trip.distance_m) },
    dedupe_key: 'trip_ended',
  });
  emit.toDispatch(trip.school_id, 'trip:ended', { tripId: trip.id });
  emit.toBus(trip.bus_id, 'trip:ended', { tripId: trip.id });
  logger.info({ trip: trip.id }, 'trip ended');
  return updated;
}

/** Ingest a batch of positions (also used for single positions). Restart-safe. */
export async function ingestPositions(
  tripId: string,
  driverId: string,
  batch: PositionInput[],
): Promise<{ accepted: number; rejected: number; last: PositionInput | null }> {
  const trip = await requireDriverTrip(tripId, driverId);

  const clean = batch
    .filter(
      (p) =>
        Number.isFinite(p.lat) &&
        Number.isFinite(p.lng) &&
        p.lat >= -90 &&
        p.lat <= 90 &&
        p.lng >= -180 &&
        p.lng <= 180 &&
        !Number.isNaN(Date.parse(p.recordedAt)),
    )
    .sort((a, b) => Date.parse(a.recordedAt) - Date.parse(b.recordedAt));

  const rejected = batch.length - clean.length;
  if (!clean.length) return { accepted: 0, rejected, last: null };

  // Drop positions older than what we already have.
  const cutoff = trip.last_position_at ? Date.parse(trip.last_position_at) : 0;
  const fresh = clean.filter((p) => Date.parse(p.recordedAt) > cutoff);
  if (!fresh.length) return { accepted: 0, rejected, last: null };

  await positions.insertMany(
    fresh.map((p) => ({
      trip_id: trip.id,
      bus_id: trip.bus_id,
      lat: p.lat,
      lng: p.lng,
      speed_kph: p.speedKph ?? 0,
      heading_deg: p.headingDeg ?? 0,
      accuracy_m: p.accuracyM ?? null,
      source: p.source ?? 'device',
      recorded_at: p.recordedAt,
    })),
  );

  // Accumulate distance.
  let added = 0;
  let prev =
    trip.last_lat != null && trip.last_lng != null
      ? { lat: trip.last_lat, lng: trip.last_lng }
      : null;
  for (const p of fresh) {
    if (prev) added += haversine(prev, p);
    prev = p;
  }
  const last = fresh[fresh.length - 1]!;

  const updatedTrip = (await tripRepo.update(trip.id, {
    last_lat: last.lat,
    last_lng: last.lng,
    last_speed_kph: last.speedKph ?? 0,
    last_position_at: last.recordedAt,
    distance_m: trip.distance_m + added,
  })) as Trip;

  const payload = {
    tripId: trip.id,
    busId: trip.bus_id,
    lat: last.lat,
    lng: last.lng,
    speedKph: last.speedKph ?? 0,
    headingDeg: last.headingDeg ?? 0,
    recordedAt: last.recordedAt,
  };
  emit.toBus(trip.bus_id, 'bus:position', payload);
  emit.toDispatch(trip.school_id, 'bus:position', payload);

  // Run the geofence engine over every fresh position (matters for offline batches
  // that contain a leave-then-return sequence). Context is loaded once.
  const ctx = await loadContext(updatedTrip);
  if (ctx) {
    const state = { ...updatedTrip.engine_state };
    const before = JSON.stringify(state);
    for (const p of fresh) {
      await evaluateAt(
        updatedTrip,
        ctx,
        { lat: p.lat, lng: p.lng, speedKph: p.speedKph ?? 0 },
        state,
      );
    }
    if (JSON.stringify(state) !== before) await persistState(updatedTrip.id, state);
  }

  return { accepted: fresh.length, rejected, last };
}

/** Fail-safe: close trips that have had no position update for a long time. */
export async function reapStaleTrips(maxIdleMinutes = 30): Promise<number> {
  const stale = (await db<Trip>('trips')
    .where({ status: 'active' })
    .where((b) => {
      b.where(
        'last_position_at',
        '<',
        db.raw(`now() - interval '${maxIdleMinutes} minutes'`),
      ).orWhere((b2) =>
        b2
          .whereNull('last_position_at')
          .andWhere('started_at', '<', db.raw(`now() - interval '${maxIdleMinutes} minutes'`)),
      );
    })) as Trip[];

  for (const t of stale) {
    await tripRepo.update(t.id, { status: 'completed', ended_at: db.fn.now() as never });
    await tripEvents.record({
      trip_id: t.id,
      school_id: t.school_id,
      type: 'trip_ended',
      stop_id: null,
      student_id: null,
      lat: t.last_lat,
      lng: t.last_lng,
      payload: { reason: 'auto-closed (stale)' },
      dedupe_key: 'trip_ended',
    });
    emit.toDispatch(t.school_id, 'trip:ended', { tripId: t.id, reason: 'stale' });
  }
  if (stale.length) logger.warn({ count: stale.length }, 'auto-closed stale trips');
  return stale.length;
}

// ── helpers ──────────────────────────────────────────────────
async function requireDriverTrip(tripId: string, driverId: string): Promise<Trip> {
  const trip = (await tripRepo.findById(tripId)) as Trip | undefined;
  if (!trip) throw notFound('Trip not found');
  if (trip.driver_id !== driverId) throw forbidden('Not your trip');
  if (trip.status !== 'active') throw badRequest('Trip is not active');
  return trip;
}

async function defaultRouteForBus(busId: string): Promise<string | null> {
  const row = await db('students')
    .where({ bus_id: busId })
    .whereNotNull('route_id')
    .select('route_id')
    .first();
  return (row?.route_id as string) ?? null;
}

async function guardiansForTrip(busId: string): Promise<string[]> {
  const students = await db('students').where({ bus_id: busId }).select('id');
  const ids = new Set<string>();
  for (const s of students) {
    for (const g of await guardianships.guardianIdsForStudent(s.id as string)) ids.add(g);
  }
  return [...ids];
}
