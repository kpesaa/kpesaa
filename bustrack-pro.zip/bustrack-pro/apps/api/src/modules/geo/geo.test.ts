import { describe, expect, it } from 'vitest';
import {
  bearing,
  distanceToPolyline,
  distanceToSegment,
  etaMinutes,
  haversine,
  isWithin,
  polylineLength,
} from './geo';

describe('haversine', () => {
  it('is zero for identical points', () => {
    expect(haversine({ lat: 5.05, lng: 7.91 }, { lat: 5.05, lng: 7.91 })).toBe(0);
  });

  it('matches a known distance (Uyo ~ 1 deg lat ≈ 111 km)', () => {
    const d = haversine({ lat: 5, lng: 7.9 }, { lat: 6, lng: 7.9 });
    expect(d).toBeGreaterThan(110_000);
    expect(d).toBeLessThan(112_000);
  });

  it('~155 m between two seeded points', () => {
    const d = haversine({ lat: 5.0521, lng: 7.9201 }, { lat: 5.0508, lng: 7.9216 });
    expect(d).toBeGreaterThan(180);
    expect(d).toBeLessThan(230);
  });
});

describe('bearing', () => {
  it('points north', () => {
    expect(bearing({ lat: 5, lng: 7 }, { lat: 6, lng: 7 })).toBeCloseTo(0, 0);
  });
  it('points east', () => {
    expect(bearing({ lat: 5, lng: 7 }, { lat: 5, lng: 8 })).toBeCloseTo(90, 0);
  });
});

describe('distanceToSegment / distanceToPolyline', () => {
  const a = { lat: 5.0, lng: 7.9 };
  const b = { lat: 5.0, lng: 7.91 };

  it('is ~0 for a point on the segment', () => {
    expect(distanceToSegment({ lat: 5.0, lng: 7.905 }, a, b)).toBeLessThan(1);
  });

  it('measures perpendicular offset', () => {
    const off = distanceToSegment({ lat: 5.001, lng: 7.905 }, a, b);
    expect(off).toBeGreaterThan(100);
    expect(off).toBeLessThan(120);
  });

  it('clamps to segment ends', () => {
    const past = distanceToSegment({ lat: 5.0, lng: 7.92 }, a, b);
    expect(past).toBeCloseTo(haversine({ lat: 5.0, lng: 7.92 }, b), -1);
  });

  it('polyline picks the nearest segment', () => {
    const line = [
      { lat: 5.0, lng: 7.9 },
      { lat: 5.0, lng: 7.91 },
      { lat: 5.01, lng: 7.91 },
    ];
    expect(distanceToPolyline({ lat: 5.005, lng: 7.9101 }, line)).toBeLessThan(20);
    expect(distanceToPolyline({ lat: 5.0, lng: 7.905 }, [])).toBe(Number.POSITIVE_INFINITY);
  });
});

describe('polylineLength', () => {
  it('sums segment distances', () => {
    const line = [
      { lat: 5.0, lng: 7.9 },
      { lat: 5.0, lng: 7.91 },
      { lat: 5.0, lng: 7.92 },
    ];
    const total = polylineLength(line);
    expect(total).toBeGreaterThan(2100);
    expect(total).toBeLessThan(2300);
  });
});

describe('isWithin / etaMinutes', () => {
  it('isWithin respects the radius', () => {
    const bus = { lat: 5.0521, lng: 7.9201 };
    const stop = { lat: 5.052, lng: 7.9203 };
    expect(isWithin(bus, stop, 150)).toBe(true);
    expect(isWithin(bus, { lat: 5.06, lng: 7.93 }, 150)).toBe(false);
  });

  it('etaMinutes uses a sensible floor speed', () => {
    expect(etaMinutes(1000, 0)).toBe(3); // falls back to 20 km/h
    expect(etaMinutes(2000, 40)).toBe(3);
    expect(etaMinutes(0, 30)).toBe(0);
  });
});
