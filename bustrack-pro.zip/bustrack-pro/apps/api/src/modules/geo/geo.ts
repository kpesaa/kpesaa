export interface LatLng {
  lat: number;
  lng: number;
}

const R = 6_371_008.8; // mean Earth radius, metres
const toRad = (d: number) => (d * Math.PI) / 180;

/** Great-circle distance between two points, in metres. */
export function haversine(a: LatLng, b: LatLng): number {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Initial bearing from a to b, degrees clockwise from north. */
export function bearing(a: LatLng, b: LatLng): number {
  const y = Math.sin(toRad(b.lng - a.lng)) * Math.cos(toRad(b.lat));
  const x =
    Math.cos(toRad(a.lat)) * Math.sin(toRad(b.lat)) -
    Math.sin(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.cos(toRad(b.lng - a.lng));
  return (Math.atan2(y, x) * (180 / Math.PI) + 360) % 360;
}

/**
 * Local equirectangular projection to metres around a reference point.
 * Accurate enough for the short distances involved in route-deviation checks.
 */
function toXY(p: LatLng, ref: LatLng): [number, number] {
  const x = toRad(p.lng - ref.lng) * Math.cos(toRad(ref.lat)) * R;
  const y = toRad(p.lat - ref.lat) * R;
  return [x, y];
}

/** Perpendicular distance (metres) from point p to segment a→b. */
export function distanceToSegment(p: LatLng, a: LatLng, b: LatLng): number {
  const [px, py] = toXY(p, a);
  const [bx, by] = toXY(b, a);
  const len2 = bx * bx + by * by;
  if (len2 === 0) return haversine(p, a);
  let t = (px * bx + py * by) / len2;
  t = Math.max(0, Math.min(1, t));
  const cx = bx * t;
  const cy = by * t;
  return Math.hypot(px - cx, py - cy);
}

/** Smallest distance (metres) from point p to a polyline. Infinity if <2 points. */
export function distanceToPolyline(p: LatLng, line: LatLng[]): number {
  if (line.length < 2) return Number.POSITIVE_INFINITY;
  let min = Number.POSITIVE_INFINITY;
  for (let i = 0; i < line.length - 1; i++) {
    const d = distanceToSegment(p, line[i]!, line[i + 1]!);
    if (d < min) min = d;
  }
  return min;
}

/** Total length of a polyline, metres. */
export function polylineLength(line: LatLng[]): number {
  let sum = 0;
  for (let i = 0; i < line.length - 1; i++) sum += haversine(line[i]!, line[i + 1]!);
  return sum;
}

export function isWithin(a: LatLng, b: LatLng, radiusM: number): boolean {
  return haversine(a, b) <= radiusM;
}

/** Rough ETA in minutes from distance and current speed (falls back to 20 km/h). */
export function etaMinutes(distanceM: number, speedKph: number): number {
  const kph = speedKph > 3 ? speedKph : 20;
  return Math.max(0, Math.round((distanceM / 1000 / kph) * 60));
}
