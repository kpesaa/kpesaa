import { createServer } from 'node:http';
import { createApp } from './app';
import { env } from './config/env';
import { closeDb, db } from './db/knex';
import { logger } from './lib/logger';
import { initEmail } from './modules/notifications/channels/email';
import { initWebPush } from './modules/notifications/channels/webpush';
import { reapStaleTrips } from './modules/tracking/service';
import { initRealtime } from './realtime/io';

async function main() {
  // Fail fast if the database is unreachable / not migrated.
  await db.raw('select 1');
  const migrated = await db.migrate.currentVersion();
  if (migrated === 'none') {
    logger.warn('Database has no migrations applied — run `npm run db:migrate`');
  }

  await initEmail();
  initWebPush();

  const app = createApp();
  const server = createServer(app);
  await initRealtime(server);

  server.listen(env.API_PORT, () => {
    logger.info(`BusTrack API listening on :${env.API_PORT} (${env.NODE_ENV})`);
  });

  // Housekeeping: auto-close trips that stopped reporting.
  const reaper = setInterval(
    () => {
      reapStaleTrips().catch((err) => logger.error(err, 'reapStaleTrips failed'));
    },
    5 * 60 * 1000,
  );

  const shutdown = async (signal: string) => {
    logger.info(`${signal} received, shutting down`);
    clearInterval(reaper);
    server.close();
    await closeDb();
    process.exit(0);
  };
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
}

main().catch((err) => {
  logger.error(err, 'Fatal startup error');
  process.exit(1);
});
