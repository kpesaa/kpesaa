import type { AccessClaims } from '../modules/auth/tokens';

declare global {
  namespace Express {
    interface Request {
      auth?: AccessClaims;
      id?: string;
    }
  }
}
