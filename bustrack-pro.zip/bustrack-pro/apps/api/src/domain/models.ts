import type { Role } from './common';

/** Row shapes as returned by knex (snake_case columns). */

export interface School {
  id: string;
  name: string;
  slug: string;
  timezone: string;
  address: string | null;
  lat: number;
  lng: number;
  radius_m: number;
  contact_phone: string | null;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface User {
  id: string;
  school_id: string | null;
  name: string;
  email: string;
  phone: string | null;
  password_hash: string;
  role: Role;
  status: 'active' | 'invited' | 'disabled';
  failed_login_attempts: number;
  locked_until: string | null;
  last_login_at: string | null;
  created_at: string;
  updated_at: string;
}

export type PublicUser = Omit<User, 'password_hash' | 'failed_login_attempts' | 'locked_until'>;

export interface Bus {
  id: string;
  school_id: string;
  plate_number: string;
  label: string | null;
  model: string | null;
  capacity: number;
  driver_id: string | null;
  status: 'active' | 'inactive' | 'maintenance';
  created_at: string;
  updated_at: string;
}

export interface Route {
  id: string;
  school_id: string;
  name: string;
  description: string | null;
  path: [number, number][];
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Stop {
  id: string;
  route_id: string;
  school_id: string;
  name: string;
  kind: 'pickup' | 'dropoff' | 'both';
  lat: number;
  lng: number;
  radius_m: number;
  sequence: number;
  address: string | null;
  scheduled_time: string | null;
  created_at: string;
  updated_at: string;
}

export interface Student {
  id: string;
  school_id: string;
  first_name: string;
  last_name: string;
  grade: string | null;
  photo_url: string | null;
  route_id: string | null;
  bus_id: string | null;
  pickup_stop_id: string | null;
  dropoff_stop_id: string | null;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface Guardianship {
  id: string;
  student_id: string;
  guardian_id: string;
  relationship: string;
  is_primary: boolean;
  notify: boolean;
  created_at: string;
}

export interface Trip {
  id: string;
  school_id: string;
  bus_id: string;
  driver_id: string;
  route_id: string | null;
  direction: 'to_school' | 'from_school' | 'custom';
  status: 'scheduled' | 'active' | 'completed' | 'cancelled';
  started_at: string | null;
  ended_at: string | null;
  distance_m: number;
  last_lat: number | null;
  last_lng: number | null;
  last_speed_kph: number;
  last_position_at: string | null;
  engine_state: {
    left_school?: boolean;
    deviation_strikes?: number;
    deviation_active?: boolean;
  };
  created_at: string;
  updated_at: string;
}

export interface TripPosition {
  id: string;
  trip_id: string;
  bus_id: string;
  lat: number;
  lng: number;
  speed_kph: number;
  heading_deg: number;
  accuracy_m: number | null;
  source: 'device' | 'batch' | 'sim';
  recorded_at: string;
  received_at: string;
}

export type TripEventType =
  | 'trip_started'
  | 'departed_school'
  | 'approaching_stop'
  | 'arrived_stop'
  | 'arrived_school'
  | 'route_deviation'
  | 'emergency'
  | 'delay'
  | 'trip_ended';

export interface TripEvent {
  id: string;
  trip_id: string;
  school_id: string;
  type: TripEventType;
  stop_id: string | null;
  student_id: string | null;
  lat: number | null;
  lng: number | null;
  payload: Record<string, unknown>;
  dedupe_key: string | null;
  created_at: string;
}

export interface Notification {
  id: string;
  school_id: string;
  user_id: string;
  trip_id: string | null;
  event_id: string | null;
  student_id: string | null;
  type: string;
  title: string;
  body: string;
  data: Record<string, unknown>;
  read_at: string | null;
  created_at: string;
}

export interface PushSubscription {
  id: string;
  user_id: string;
  endpoint: string;
  p256dh: string;
  auth: string;
  user_agent: string | null;
  created_at: string;
  last_used_at: string | null;
}

export interface NotificationPreferences {
  user_id: string;
  in_app_enabled: boolean;
  email_enabled: boolean;
  web_push_enabled: boolean;
  sms_enabled: boolean;
  quiet_hours_start: string | null;
  quiet_hours_end: string | null;
  updated_at: string;
}
