import { z } from 'zod';
import { ROLES, latitude, longitude } from './common';

// ── auth ─────────────────────────────────────────────────────
export const loginDto = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});
export const refreshDto = z.object({ refreshToken: z.string().min(1) });
export const changePasswordDto = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8).max(200),
});

// ── schools ──────────────────────────────────────────────────
export const schoolCreateDto = z.object({
  name: z.string().min(2).max(160),
  slug: z
    .string()
    .min(2)
    .max(80)
    .regex(/^[a-z0-9-]+$/, 'lowercase letters, numbers and dashes only'),
  timezone: z.string().max(64).default('Africa/Lagos'),
  address: z.string().max(500).optional(),
  lat: latitude,
  lng: longitude,
  radius_m: z.number().int().min(50).max(2000).default(250),
  contact_phone: z.string().max(32).optional(),
  active: z.boolean().default(true),
});
export const schoolUpdateDto = schoolCreateDto.partial();

// ── users (staff / drivers / parents) ────────────────────────
export const userCreateDto = z.object({
  name: z.string().min(2).max(160),
  email: z.string().email(),
  phone: z.string().max(32).optional(),
  role: z.enum(ROLES),
  password: z.string().min(8).max(200).optional(),
  status: z.enum(['active', 'invited', 'disabled']).default('active'),
});
export const userUpdateDto = z.object({
  name: z.string().min(2).max(160).optional(),
  phone: z.string().max(32).nullable().optional(),
  role: z.enum(ROLES).optional(),
  status: z.enum(['active', 'invited', 'disabled']).optional(),
  password: z.string().min(8).max(200).optional(),
});

// ── buses ────────────────────────────────────────────────────
export const busCreateDto = z.object({
  plate_number: z.string().min(2).max(32),
  label: z.string().max(80).optional(),
  model: z.string().max(120).optional(),
  capacity: z.number().int().min(1).max(120).default(30),
  driver_id: z.string().uuid().nullable().optional(),
  status: z.enum(['active', 'inactive', 'maintenance']).default('active'),
});
export const busUpdateDto = busCreateDto.partial();

// ── routes + stops ───────────────────────────────────────────
export const routeCreateDto = z.object({
  name: z.string().min(2).max(120),
  description: z.string().max(1000).optional(),
  path: z.array(z.tuple([latitude, longitude])).default([]),
  active: z.boolean().default(true),
});
export const routeUpdateDto = routeCreateDto.partial();

export const stopCreateDto = z.object({
  route_id: z.string().uuid(),
  name: z.string().min(2).max(160),
  kind: z.enum(['pickup', 'dropoff', 'both']).default('both'),
  lat: latitude,
  lng: longitude,
  radius_m: z.number().int().min(30).max(1000).default(150),
  sequence: z.number().int().min(0).default(0),
  address: z.string().max(500).optional(),
  scheduled_time: z
    .string()
    .regex(/^\d{2}:\d{2}(:\d{2})?$/)
    .optional(),
});
export const stopUpdateDto = stopCreateDto.partial().omit({ route_id: true });

// ── students ─────────────────────────────────────────────────
export const studentCreateDto = z.object({
  first_name: z.string().min(1).max(80),
  last_name: z.string().min(1).max(80),
  grade: z.string().max(40).optional(),
  photo_url: z.string().url().max(1000).optional(),
  route_id: z.string().uuid().nullable().optional(),
  bus_id: z.string().uuid().nullable().optional(),
  pickup_stop_id: z.string().uuid().nullable().optional(),
  dropoff_stop_id: z.string().uuid().nullable().optional(),
  status: z.enum(['active', 'inactive']).default('active'),
  guardian_ids: z.array(z.string().uuid()).max(6).optional(),
});
export const studentUpdateDto = studentCreateDto.partial();

// ── trips (driver) ───────────────────────────────────────────
export const startTripDto = z.object({
  bus_id: z.string().uuid(),
  route_id: z.string().uuid().nullable().optional(),
  direction: z.enum(['to_school', 'from_school', 'custom']).default('to_school'),
});
export const positionDto = z.object({
  lat: latitude,
  lng: longitude,
  speedKph: z.number().min(0).max(300).optional(),
  headingDeg: z.number().min(0).max(360).optional(),
  accuracyM: z.number().min(0).optional(),
  recordedAt: z.string().datetime(),
  source: z.enum(['device', 'batch', 'sim']).optional(),
});
export const positionsBatchDto = z.object({
  positions: z.array(positionDto).min(1).max(500),
});
export const emergencyDto = z.object({ note: z.string().max(500).optional() });

// ── push + preferences ───────────────────────────────────────
export const pushSubscribeDto = z.object({
  endpoint: z.string().url(),
  keys: z.object({ p256dh: z.string().min(1), auth: z.string().min(1) }),
});
export const prefsUpdateDto = z.object({
  in_app_enabled: z.boolean().optional(),
  email_enabled: z.boolean().optional(),
  web_push_enabled: z.boolean().optional(),
  sms_enabled: z.boolean().optional(),
  quiet_hours_start: z
    .string()
    .regex(/^\d{2}:\d{2}(:\d{2})?$/)
    .nullable()
    .optional(),
  quiet_hours_end: z
    .string()
    .regex(/^\d{2}:\d{2}(:\d{2})?$/)
    .nullable()
    .optional(),
});
