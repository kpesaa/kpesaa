import { z } from 'zod';

export const ROLES = ['super_admin', 'admin', 'dispatcher', 'driver', 'parent'] as const;
export type Role = (typeof ROLES)[number];

export const uuid = z.string().uuid();

export const latitude = z.number().min(-90).max(90);
export const longitude = z.number().min(-180).max(180);

export const coordinate = z.object({ lat: latitude, lng: longitude });
export type Coordinate = z.infer<typeof coordinate>;

export const pagination = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(200).default(25),
  q: z.string().trim().max(200).optional(),
});
export type Pagination = z.infer<typeof pagination>;

export function paginate<T>(rows: T[], total: number, p: Pagination) {
  return {
    data: rows,
    pagination: {
      page: p.page,
      pageSize: p.pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / p.pageSize)),
    },
  };
}

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public details?: unknown,
  ) {
    super(message);
    this.name = 'HttpError';
  }
}

export const badRequest = (m: string, d?: unknown) => new HttpError(400, m, d);
export const unauthorized = (m = 'Authentication required') => new HttpError(401, m);
export const forbidden = (m = 'You do not have access to this resource') => new HttpError(403, m);
export const notFound = (m = 'Not found') => new HttpError(404, m);
export const conflict = (m: string) => new HttpError(409, m);
