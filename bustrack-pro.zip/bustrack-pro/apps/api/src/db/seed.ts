import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import { logger } from '../lib/logger';
import { db } from './knex';

const SCHOOL = { lat: 5.0478, lng: 7.9137 };

// A believable Ring-Road loop around Uyo, Akwa Ibom.
const RING_ROAD_PATH: [number, number][] = [
  [5.0478, 7.9137],
  [5.0489, 7.9146],
  [5.05, 7.9158],
  [5.0511, 7.9171],
  [5.0518, 7.9186],
  [5.0521, 7.9201],
  [5.0516, 7.9212],
  [5.0508, 7.9216],
  [5.0499, 7.9209],
  [5.0491, 7.9198],
  [5.0485, 7.918],
  [5.0481, 7.9158],
  [5.0478, 7.9137],
];

async function seed() {
  logger.info('Seeding demo data…');
  await db.transaction(async (trx) => {
    // Wipe (respecting FKs).
    for (const t of [
      'audit_logs',
      'notification_deliveries',
      'notifications',
      'notification_preferences',
      'push_subscriptions',
      'trip_events',
      'trip_positions',
      'trips',
      'guardianships',
      'students',
      'stops',
      'routes',
      'buses',
      'refresh_tokens',
      'users',
      'schools',
    ]) {
      await trx(t).del();
    }

    const hash = (p: string) => bcrypt.hashSync(p, 10);
    const id = () => randomUUID();

    const schoolId = id();
    await trx('schools').insert({
      id: schoolId,
      name: 'Graceland International Primary School',
      slug: 'graceland-uyo',
      timezone: 'Africa/Lagos',
      address: 'Ring Road, Uyo, Akwa Ibom State',
      lat: SCHOOL.lat,
      lng: SCHOOL.lng,
      radius_m: 250,
      contact_phone: '+2348030000000',
    });

    const superAdminId = id();
    const adminId = id();
    const dispatcherId = id();
    await trx('users').insert([
      {
        id: superAdminId,
        school_id: null,
        name: 'Platform Owner',
        email: 'owner@bustrack.local',
        password_hash: hash('owner12345'),
        role: 'super_admin',
        status: 'active',
      },
      {
        id: adminId,
        school_id: schoolId,
        name: 'Mrs. Ngozi Okafor',
        email: 'admin@graceland.edu.ng',
        password_hash: hash('admin12345'),
        role: 'admin',
        status: 'active',
        phone: '+2348031111111',
      },
      {
        id: dispatcherId,
        school_id: schoolId,
        name: 'Mr. Paul Effiong',
        email: 'dispatch@graceland.edu.ng',
        password_hash: hash('dispatch12345'),
        role: 'dispatcher',
        status: 'active',
      },
    ]);

    const drivers = [
      ['Mr. Emmanuel Etim', 'driver1@graceland.edu.ng', '+2348032222221'],
      ['Mr. Sunday Okon', 'driver2@graceland.edu.ng', '+2348032222222'],
      ['Mr. Chukwudi Eze', 'driver3@graceland.edu.ng', '+2348032222223'],
    ].map(([name, email, phone]) => ({
      id: id(),
      school_id: schoolId,
      name,
      email,
      phone,
      password_hash: hash('driver12345'),
      role: 'driver' as const,
      status: 'active' as const,
    }));
    await trx('users').insert(drivers);

    const parents = [
      'Mrs. Amaka Nwachukwu',
      'Mr. Biodun Adeleke',
      'Mrs. Fatima Lawal',
      'Mr. Emeka Obi',
      'Mrs. Grace Udoh',
      'Mr. Kelechi Eze',
    ].map((name, i) => ({
      id: id(),
      school_id: schoolId,
      name,
      email: `parent${i + 1}@example.com`,
      phone: `+23480900000${i + 1}${i + 1}`,
      password_hash: hash('parent12345'),
      role: 'parent' as const,
      status: 'active' as const,
    }));
    await trx('users').insert(parents);

    await trx('notification_preferences').insert(
      [
        superAdminId,
        adminId,
        dispatcherId,
        ...drivers.map((d) => d.id),
        ...parents.map((p) => p.id),
      ].map((uid) => ({ user_id: uid })),
    );

    const buses = [
      ['AKW-001-GS', 'Bus 1', 'Toyota HiAce', drivers[0]!.id],
      ['AKW-002-GS', 'Bus 2', 'Ford Transit', drivers[1]!.id],
      ['AKW-003-GS', 'Bus 3', 'Nissan Urvan', drivers[2]!.id],
    ].map(([plate_number, label, model, driver_id]) => ({
      id: id(),
      school_id: schoolId,
      plate_number,
      label,
      model,
      capacity: 30,
      driver_id,
      status: 'active' as const,
    }));
    await trx('buses').insert(buses);

    const routeId = id();
    await trx('routes').insert({
      id: routeId,
      school_id: schoolId,
      name: 'Ring Road Route',
      description: 'Loop covering Ring Road and Aka Road neighbourhoods',
      path: JSON.stringify(RING_ROAD_PATH),
      active: true,
    });

    const stops = [
      ['Ring Road Junction', 5.0521, 7.9201, 'pickup'],
      ['Aka Road Stop', 5.0508, 7.9216, 'pickup'],
      ['Stadium Road Stop', 5.0491, 7.9198, 'both'],
    ].map(([name, lat, lng, kind], i) => ({
      id: id(),
      route_id: routeId,
      school_id: schoolId,
      name,
      kind,
      lat,
      lng,
      radius_m: 150,
      sequence: i + 1,
      address: `${name}, Uyo`,
    }));
    await trx('stops').insert(stops);

    const students = [
      ['Chisom', 'Nwachukwu', 'Primary 4', 0, 0],
      ['Tunde', 'Adeleke', 'Primary 3', 0, 1],
      ['Aisha', 'Lawal', 'Primary 5', 1, 2],
      ['David', 'Obi', 'Primary 2', 1, 0],
      ['Blessing', 'Udoh', 'Primary 6', 2, 1],
      ['Ifeanyi', 'Eze', 'Primary 1', 2, 2],
    ].map(([first, last, grade, busIdx, stopIdx], i) => ({
      id: id(),
      school_id: schoolId,
      first_name: first,
      last_name: last,
      grade,
      route_id: routeId,
      bus_id: buses[busIdx as number]!.id,
      pickup_stop_id: stops[stopIdx as number]!.id,
      dropoff_stop_id: stops[stopIdx as number]!.id,
      status: 'active' as const,
      _parentIdx: i,
    }));
    await trx('students').insert(students.map(({ _parentIdx, ...s }) => s));

    await trx('guardianships').insert(
      students.map((s) => ({
        id: id(),
        student_id: s.id,
        guardian_id: parents[s._parentIdx]!.id,
        relationship: 'parent',
        is_primary: true,
        notify: true,
      })),
    );

    logger.info(
      {
        school: 'graceland-uyo',
        drivers: drivers.length,
        parents: parents.length,
        buses: buses.length,
      },
      'Seed complete',
    );
  });

  await db.destroy();
}

seed().catch((err) => {
  logger.error(err, 'Seed failed');
  process.exit(1);
});
