import knexFactory, { type Knex } from 'knex';
import { env } from '../config/env';

export const knexConfig: Knex.Config = {
  client: 'pg',
  connection: env.databaseUrl,
  pool: { min: 0, max: 10 },
  migrations: {
    directory: `${__dirname}/migrations`,
    extension: 'ts',
    loadExtensions: ['.ts', '.js'],
    tableName: 'knex_migrations',
  },
};

export const db: Knex = knexFactory(knexConfig);

export async function closeDb(): Promise<void> {
  await db.destroy();
}
