import { logger } from '../lib/logger';
/**
 * Programmatic migration runner so .ts migration files work under tsx without
 * the knex CLI needing its own TS loader.
 *
 *   tsx src/db/migrate.ts latest
 *   tsx src/db/migrate.ts rollback
 *   tsx src/db/migrate.ts status
 *   tsx src/db/migrate.ts reset      (rollback all, then latest)
 */
import { db } from './knex';

async function main() {
  const cmd = process.argv[2] ?? 'latest';
  try {
    if (cmd === 'latest') {
      const [batch, files] = await db.migrate.latest();
      logger.info(files.length ? `Ran batch ${batch}: ${files.join(', ')}` : 'Already up to date');
    } else if (cmd === 'rollback') {
      const [batch, files] = await db.migrate.rollback();
      logger.info(
        files.length ? `Rolled back batch ${batch}: ${files.join(', ')}` : 'Nothing to roll back',
      );
    } else if (cmd === 'reset') {
      await db.migrate.rollback(undefined, true);
      const [batch, files] = await db.migrate.latest();
      logger.info(`Reset complete — batch ${batch}: ${files.join(', ')}`);
    } else if (cmd === 'status') {
      const current = await db.migrate.currentVersion();
      const list = await db.migrate.list();
      logger.info({ current, completed: list[0], pending: list[1] }, 'Migration status');
    } else {
      throw new Error(`Unknown command "${cmd}"`);
    }
  } catch (err) {
    logger.error(err, 'Migration failed');
    process.exitCode = 1;
  } finally {
    await db.destroy();
  }
}

void main();
