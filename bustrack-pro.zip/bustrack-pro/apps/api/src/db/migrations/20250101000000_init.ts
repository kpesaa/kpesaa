import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.raw('CREATE EXTENSION IF NOT EXISTS "pgcrypto"');

  const uuidPk = (t: Knex.CreateTableBuilder) =>
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
  const stamps = (t: Knex.CreateTableBuilder) => {
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.timestamp('updated_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
  };

  await knex.schema.createTable('schools', (t) => {
    uuidPk(t);
    t.string('name', 160).notNullable();
    t.string('slug', 80).notNullable().unique();
    t.string('timezone', 64).notNullable().defaultTo('Africa/Lagos');
    t.text('address');
    t.double('lat').notNullable();
    t.double('lng').notNullable();
    t.integer('radius_m').notNullable().defaultTo(250);
    t.string('contact_phone', 32);
    t.boolean('active').notNullable().defaultTo(true);
    stamps(t);
  });

  await knex.schema.createTable('users', (t) => {
    uuidPk(t);
    t.uuid('school_id').references('id').inTable('schools').onDelete('CASCADE');
    t.string('name', 160).notNullable();
    t.string('email', 190).notNullable();
    t.string('phone', 32);
    t.text('password_hash').notNullable();
    t.enu('role', ['super_admin', 'admin', 'dispatcher', 'driver', 'parent'], {
      useNative: true,
      enumName: 'user_role',
    }).notNullable();
    t.enu('status', ['active', 'invited', 'disabled'], {
      useNative: true,
      enumName: 'user_status',
    })
      .notNullable()
      .defaultTo('active');
    t.integer('failed_login_attempts').notNullable().defaultTo(0);
    t.timestamp('locked_until', { useTz: true });
    t.timestamp('last_login_at', { useTz: true });
    stamps(t);
    t.unique(['email']);
    t.index(['school_id', 'role']);
  });

  await knex.schema.createTable('refresh_tokens', (t) => {
    uuidPk(t);
    t.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    t.string('token_hash', 128).notNullable().unique();
    t.timestamp('expires_at', { useTz: true }).notNullable();
    t.timestamp('revoked_at', { useTz: true });
    t.string('user_agent', 300);
    t.string('ip', 64);
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['user_id']);
  });

  await knex.schema.createTable('buses', (t) => {
    uuidPk(t);
    t.uuid('school_id').notNullable().references('id').inTable('schools').onDelete('CASCADE');
    t.string('plate_number', 32).notNullable();
    t.string('label', 80);
    t.string('model', 120);
    t.integer('capacity').notNullable().defaultTo(30);
    t.uuid('driver_id').references('id').inTable('users').onDelete('SET NULL');
    t.enu('status', ['active', 'inactive', 'maintenance'], {
      useNative: true,
      enumName: 'bus_status',
    })
      .notNullable()
      .defaultTo('active');
    stamps(t);
    t.unique(['school_id', 'plate_number']);
  });

  await knex.schema.createTable('routes', (t) => {
    uuidPk(t);
    t.uuid('school_id').notNullable().references('id').inTable('schools').onDelete('CASCADE');
    t.string('name', 120).notNullable();
    t.text('description');
    // Ordered polyline as [[lat, lng], ...]
    t.jsonb('path').notNullable().defaultTo('[]');
    t.boolean('active').notNullable().defaultTo(true);
    stamps(t);
    t.index(['school_id']);
  });

  await knex.schema.createTable('stops', (t) => {
    uuidPk(t);
    t.uuid('route_id').notNullable().references('id').inTable('routes').onDelete('CASCADE');
    t.uuid('school_id').notNullable().references('id').inTable('schools').onDelete('CASCADE');
    t.string('name', 160).notNullable();
    t.enu('kind', ['pickup', 'dropoff', 'both'], { useNative: true, enumName: 'stop_kind' })
      .notNullable()
      .defaultTo('both');
    t.double('lat').notNullable();
    t.double('lng').notNullable();
    t.integer('radius_m').notNullable().defaultTo(150);
    t.integer('sequence').notNullable().defaultTo(0);
    t.text('address');
    t.time('scheduled_time');
    stamps(t);
    t.index(['route_id', 'sequence']);
  });

  await knex.schema.createTable('students', (t) => {
    uuidPk(t);
    t.uuid('school_id').notNullable().references('id').inTable('schools').onDelete('CASCADE');
    t.string('first_name', 80).notNullable();
    t.string('last_name', 80).notNullable();
    t.string('grade', 40);
    t.text('photo_url');
    t.uuid('route_id').references('id').inTable('routes').onDelete('SET NULL');
    t.uuid('bus_id').references('id').inTable('buses').onDelete('SET NULL');
    t.uuid('pickup_stop_id').references('id').inTable('stops').onDelete('SET NULL');
    t.uuid('dropoff_stop_id').references('id').inTable('stops').onDelete('SET NULL');
    t.enu('status', ['active', 'inactive'], { useNative: true, enumName: 'student_status' })
      .notNullable()
      .defaultTo('active');
    stamps(t);
    t.index(['school_id']);
    t.index(['bus_id']);
  });

  await knex.schema.createTable('guardianships', (t) => {
    uuidPk(t);
    t.uuid('student_id').notNullable().references('id').inTable('students').onDelete('CASCADE');
    t.uuid('guardian_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    t.string('relationship', 40).notNullable().defaultTo('parent');
    t.boolean('is_primary').notNullable().defaultTo(false);
    t.boolean('notify').notNullable().defaultTo(true);
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.unique(['student_id', 'guardian_id']);
    t.index(['guardian_id']);
  });

  await knex.schema.createTable('trips', (t) => {
    uuidPk(t);
    t.uuid('school_id').notNullable().references('id').inTable('schools').onDelete('CASCADE');
    t.uuid('bus_id').notNullable().references('id').inTable('buses').onDelete('CASCADE');
    t.uuid('driver_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    t.uuid('route_id').references('id').inTable('routes').onDelete('SET NULL');
    t.enu('direction', ['to_school', 'from_school', 'custom'], {
      useNative: true,
      enumName: 'trip_direction',
    })
      .notNullable()
      .defaultTo('to_school');
    t.enu('status', ['scheduled', 'active', 'completed', 'cancelled'], {
      useNative: true,
      enumName: 'trip_status',
    })
      .notNullable()
      .defaultTo('active');
    t.timestamp('started_at', { useTz: true });
    t.timestamp('ended_at', { useTz: true });
    t.double('distance_m').notNullable().defaultTo(0);
    t.double('last_lat');
    t.double('last_lng');
    t.double('last_speed_kph').notNullable().defaultTo(0);
    t.timestamp('last_position_at', { useTz: true });
    // Geofence-engine bookkeeping (left_school flag, deviation strike count, ...).
    t.jsonb('engine_state').notNullable().defaultTo('{}');
    stamps(t);
    t.index(['school_id', 'status']);
    t.index(['bus_id', 'status']);
  });
  // At most one active trip per bus.
  await knex.raw(
    `CREATE UNIQUE INDEX trips_one_active_per_bus ON trips (bus_id) WHERE status = 'active'`,
  );

  await knex.schema.createTable('trip_positions', (t) => {
    uuidPk(t);
    t.uuid('trip_id').notNullable().references('id').inTable('trips').onDelete('CASCADE');
    t.uuid('bus_id').notNullable().references('id').inTable('buses').onDelete('CASCADE');
    t.double('lat').notNullable();
    t.double('lng').notNullable();
    t.double('speed_kph').notNullable().defaultTo(0);
    t.double('heading_deg').notNullable().defaultTo(0);
    t.double('accuracy_m');
    t.enu('source', ['device', 'batch', 'sim'], { useNative: true, enumName: 'position_source' })
      .notNullable()
      .defaultTo('device');
    t.timestamp('recorded_at', { useTz: true }).notNullable();
    t.timestamp('received_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['trip_id', 'recorded_at']);
  });

  await knex.schema.createTable('trip_events', (t) => {
    uuidPk(t);
    t.uuid('trip_id').notNullable().references('id').inTable('trips').onDelete('CASCADE');
    t.uuid('school_id').notNullable().references('id').inTable('schools').onDelete('CASCADE');
    t.string('type', 40).notNullable();
    t.uuid('stop_id').references('id').inTable('stops').onDelete('SET NULL');
    t.uuid('student_id').references('id').inTable('students').onDelete('SET NULL');
    t.double('lat');
    t.double('lng');
    t.jsonb('payload').notNullable().defaultTo('{}');
    t.string('dedupe_key', 200);
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.unique(['trip_id', 'dedupe_key']);
    t.index(['trip_id', 'created_at']);
  });

  await knex.schema.createTable('notifications', (t) => {
    uuidPk(t);
    t.uuid('school_id').notNullable().references('id').inTable('schools').onDelete('CASCADE');
    t.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    t.uuid('trip_id').references('id').inTable('trips').onDelete('SET NULL');
    t.uuid('event_id').references('id').inTable('trip_events').onDelete('SET NULL');
    t.uuid('student_id').references('id').inTable('students').onDelete('SET NULL');
    t.string('type', 40).notNullable();
    t.string('title', 200).notNullable();
    t.text('body').notNullable();
    t.jsonb('data').notNullable().defaultTo('{}');
    t.timestamp('read_at', { useTz: true });
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['user_id', 'created_at']);
  });

  await knex.schema.createTable('notification_deliveries', (t) => {
    uuidPk(t);
    t.uuid('notification_id')
      .notNullable()
      .references('id')
      .inTable('notifications')
      .onDelete('CASCADE');
    t.enu('channel', ['in_app', 'email', 'web_push', 'sms'], {
      useNative: true,
      enumName: 'delivery_channel',
    }).notNullable();
    t.enu('status', ['pending', 'sent', 'failed', 'skipped'], {
      useNative: true,
      enumName: 'delivery_status',
    })
      .notNullable()
      .defaultTo('pending');
    t.text('error');
    t.timestamp('sent_at', { useTz: true });
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['notification_id']);
  });

  await knex.schema.createTable('push_subscriptions', (t) => {
    uuidPk(t);
    t.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    t.text('endpoint').notNullable().unique();
    t.string('p256dh', 256).notNullable();
    t.string('auth', 256).notNullable();
    t.string('user_agent', 300);
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.timestamp('last_used_at', { useTz: true });
    t.index(['user_id']);
  });

  await knex.schema.createTable('notification_preferences', (t) => {
    t.uuid('user_id').primary().references('id').inTable('users').onDelete('CASCADE');
    t.boolean('in_app_enabled').notNullable().defaultTo(true);
    t.boolean('email_enabled').notNullable().defaultTo(true);
    t.boolean('web_push_enabled').notNullable().defaultTo(true);
    t.boolean('sms_enabled').notNullable().defaultTo(false);
    t.time('quiet_hours_start');
    t.time('quiet_hours_end');
    t.timestamp('updated_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('audit_logs', (t) => {
    uuidPk(t);
    t.uuid('school_id').references('id').inTable('schools').onDelete('SET NULL');
    t.uuid('actor_id').references('id').inTable('users').onDelete('SET NULL');
    t.string('action', 60).notNullable();
    t.string('entity', 60).notNullable();
    t.string('entity_id', 64);
    t.jsonb('meta').notNullable().defaultTo('{}');
    t.string('ip', 64);
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['school_id', 'created_at']);
  });
}

export async function down(knex: Knex): Promise<void> {
  const tables = [
    'audit_logs',
    'notification_preferences',
    'push_subscriptions',
    'notification_deliveries',
    'notifications',
    'trip_events',
    'trip_positions',
    'trips',
    'guardianships',
    'students',
    'stops',
    'routes',
    'buses',
    'refresh_tokens',
    'users',
    'schools',
  ];
  for (const table of tables) {
    await knex.schema.dropTableIfExists(table);
  }
  for (const e of [
    'user_role',
    'user_status',
    'bus_status',
    'stop_kind',
    'student_status',
    'trip_direction',
    'trip_status',
    'position_source',
    'delivery_channel',
    'delivery_status',
  ]) {
    await knex.raw(`DROP TYPE IF EXISTS ${e}`);
  }
}
