import type { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('child_handovers', (t) => {
    t.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    t.uuid('school_id').notNullable().references('id').inTable('schools');
    t.uuid('trip_id').notNullable().references('id').inTable('trips').onDelete('CASCADE');
    t.uuid('student_id').notNullable().references('id').inTable('students');
    t.uuid('requested_by').notNullable().references('id').inTable('users');
    t.string('code_hash', 64).notNullable();
    t.text('code_ciphertext').notNullable();
    t.string('status', 20).notNullable().defaultTo('pending');
    t.integer('failed_attempts').notNullable().defaultTo(0);
    t.timestamp('expires_at', { useTz: true }).notNullable();
    t.uuid('authorised_by').references('id').inTable('users');
    t.string('receiver_name', 100);
    t.string('receiver_relationship', 80);
    t.timestamp('authorised_at', { useTz: true });
    t.uuid('verified_by').references('id').inTable('users');
    t.timestamp('verified_at', { useTz: true });
    t.timestamp('created_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.timestamp('updated_at', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.unique(['trip_id', 'student_id']);
    t.index(['school_id', 'created_at']);
  });
  await knex.raw("ALTER TABLE child_handovers ADD CONSTRAINT handover_status CHECK (status IN ('pending','authorised','verified','revoked','locked'))");
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('child_handovers');
}
