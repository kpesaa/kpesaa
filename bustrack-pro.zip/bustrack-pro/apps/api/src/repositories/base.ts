import { randomUUID } from 'node:crypto';
import type { Knex } from 'knex';
import { db } from '../db/knex';
import type { Pagination } from '../domain/common';

export type Scope = Record<string, string | null>;

interface ListOpts {
  searchColumns?: string[];
  orderBy?: [string, 'asc' | 'desc'];
}

/**
 * Generic data-access for entities that have `id` + `created_at` + `updated_at`.
 * Entities without `updated_at` (join tables, logs) get bespoke repositories.
 */
export function crudRepo<Row extends { id: string }>(
  table: string,
  defaultOrder: [string, 'asc' | 'desc'] = ['created_at', 'desc'],
) {
  // Internal query builder is intentionally loose; the exported methods are typed.
  const t = (trx?: Knex): Knex.QueryBuilder => (trx ?? db)(table);

  return {
    table,
    query: t,

    findById(id: string, scope?: Scope): Promise<Row | undefined> {
      const q = t().where('id', id);
      if (scope) q.andWhere(scope);
      return q.first() as Promise<Row | undefined>;
    },

    findOne(where: Partial<Row>): Promise<Row | undefined> {
      return t()
        .where(where as Record<string, unknown>)
        .first() as Promise<Row | undefined>;
    },

    async list(where: Scope, p: Pagination, opts: ListOpts = {}) {
      const base = t().where(where);
      if (p.q && opts.searchColumns?.length) {
        base.andWhere((b) => {
          for (const col of opts.searchColumns!) b.orWhereILike(col, `%${p.q}%`);
        });
      }
      const countRow = (await base.clone().count({ c: '*' }).first()) as { c: string } | undefined;
      const [orderCol, orderDir] = opts.orderBy ?? defaultOrder;
      const rows = (await base
        .clone()
        .orderBy(orderCol, orderDir)
        .limit(p.pageSize)
        .offset((p.page - 1) * p.pageSize)) as Row[];
      return { rows, total: Number(countRow?.c ?? 0) };
    },

    async create(data: Partial<Row>, trx?: Knex): Promise<Row> {
      const row = { id: randomUUID(), ...data };
      const [created] = await t(trx).insert(row).returning('*');
      return created as Row;
    },

    async update(id: string, data: Partial<Row>, scope?: Scope): Promise<Row | undefined> {
      const q = t().where('id', id);
      if (scope) q.andWhere(scope);
      const [updated] = await q.update({ ...data, updated_at: db.fn.now() }).returning('*');
      return updated as Row | undefined;
    },

    async remove(id: string, scope?: Scope): Promise<boolean> {
      const q = t().where('id', id);
      if (scope) q.andWhere(scope);
      return (await q.del()) > 0;
    },
  };
}

export type CrudRepo<Row extends { id: string }> = ReturnType<typeof crudRepo<Row>>;
