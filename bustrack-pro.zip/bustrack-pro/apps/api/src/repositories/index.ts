import { randomUUID } from 'node:crypto';
import type { Knex } from 'knex';
import { db } from '../db/knex';
import type {
  Bus,
  Guardianship,
  Notification,
  NotificationPreferences,
  PushSubscription,
  Route,
  School,
  Stop,
  Student,
  Trip,
  TripEvent,
  TripPosition,
  User,
} from '../domain/models';
import { crudRepo } from './base';

export const schools = crudRepo<School>('schools', ['name', 'asc']);
export const users = crudRepo<User>('users', ['created_at', 'desc']);
export const buses = crudRepo<Bus>('buses', ['plate_number', 'asc']);
export const routes = crudRepo<Route>('routes', ['name', 'asc']);
export const stops = crudRepo<Stop>('stops', ['sequence', 'asc']);
export const students = crudRepo<Student>('students', ['last_name', 'asc']);
export const trips = crudRepo<Trip>('trips', ['created_at', 'desc']);

// ── users extras ─────────────────────────────────────────────
export const userRepo = {
  ...users,
  byEmail: (email: string): Promise<User | undefined> =>
    db<User>('users').whereRaw('lower(email) = lower(?)', [email]).first(),
  touchLogin: (id: string) =>
    db('users')
      .where({ id })
      .update({ last_login_at: db.fn.now(), failed_login_attempts: 0, locked_until: null }),
  bumpFailed: (id: string, lockUntil: Date | null) =>
    db('users')
      .where({ id })
      .increment('failed_login_attempts', 1)
      .update({ locked_until: lockUntil }),
};

// ── guardianships ────────────────────────────────────────────
export const guardianships = {
  forStudent: (studentId: string) =>
    db<Guardianship>('guardianships').where({ student_id: studentId }),
  forGuardian: (guardianId: string) =>
    db<Guardianship>('guardianships').where({ guardian_id: guardianId }),
  async set(studentId: string, guardianIds: string[], trx?: Knex): Promise<void> {
    const q = trx ?? db;
    await q('guardianships').where({ student_id: studentId }).del();
    if (guardianIds.length) {
      await q('guardianships').insert(
        guardianIds.map((gid, i) => ({
          id: randomUUID(),
          student_id: studentId,
          guardian_id: gid,
          is_primary: i === 0,
        })),
      );
    }
  },
  studentIdsForGuardian: async (guardianId: string): Promise<string[]> => {
    const rows = await db<Guardianship>('guardianships')
      .where({ guardian_id: guardianId, notify: true })
      .select('student_id');
    return rows.map((r) => r.student_id);
  },
  guardianIdsForStudent: async (studentId: string): Promise<string[]> => {
    const rows = await db<Guardianship>('guardianships')
      .where({ student_id: studentId, notify: true })
      .select('guardian_id');
    return rows.map((r) => r.guardian_id);
  },
};

// ── trips extras ─────────────────────────────────────────────
export const tripRepo = {
  ...trips,
  activeForBus: (busId: string): Promise<Trip | undefined> =>
    db<Trip>('trips').where({ bus_id: busId, status: 'active' }).first(),
  activeForDriver: (driverId: string): Promise<Trip | undefined> =>
    db<Trip>('trips').where({ driver_id: driverId, status: 'active' }).first(),
  activeForSchool: (schoolId: string): Promise<Trip[]> =>
    db<Trip>('trips').where({ school_id: schoolId, status: 'active' }),
  allActive: (): Promise<Trip[]> => db<Trip>('trips').where({ status: 'active' }),
};

// ── positions ────────────────────────────────────────────────
export const positions = {
  async insertMany(rows: Omit<TripPosition, 'id' | 'received_at'>[]): Promise<void> {
    if (!rows.length) return;
    await db('trip_positions').insert(rows.map((r) => ({ id: randomUUID(), ...r })));
  },
  forTrip: (tripId: string): Promise<TripPosition[]> =>
    db<TripPosition>('trip_positions').where({ trip_id: tripId }).orderBy('recorded_at', 'asc'),
};

// ── trip events ──────────────────────────────────────────────
export const tripEvents = {
  /** Insert an event, ignoring duplicates on (trip_id, dedupe_key). Returns the row or null if deduped. */
  async record(ev: Omit<TripEvent, 'id' | 'created_at'>): Promise<TripEvent | null> {
    const [row] = await db('trip_events')
      .insert({ id: randomUUID(), ...ev, payload: JSON.stringify(ev.payload ?? {}) })
      .onConflict(['trip_id', 'dedupe_key'])
      .ignore()
      .returning('*');
    return (row as TripEvent) ?? null;
  },
  forTrip: (tripId: string): Promise<TripEvent[]> =>
    db<TripEvent>('trip_events').where({ trip_id: tripId }).orderBy('created_at', 'asc'),
};

// ── notifications ────────────────────────────────────────────
export const notifications = {
  async create(n: Omit<Notification, 'id' | 'created_at' | 'read_at'>): Promise<Notification> {
    const [row] = await db('notifications')
      .insert({ id: randomUUID(), ...n, data: JSON.stringify(n.data ?? {}) })
      .returning('*');
    return row as Notification;
  },
  listForUser: (userId: string, limit = 50): Promise<Notification[]> =>
    db<Notification>('notifications')
      .where({ user_id: userId })
      .orderBy('created_at', 'desc')
      .limit(limit),
  unreadCount: async (userId: string): Promise<number> => {
    const row = (await db('notifications')
      .where({ user_id: userId })
      .whereNull('read_at')
      .count({ c: '*' })
      .first()) as { c: string } | undefined;
    return Number(row?.c ?? 0);
  },
  markRead: (userId: string, id: string) =>
    db('notifications').where({ id, user_id: userId }).update({ read_at: db.fn.now() }),
  markAllRead: (userId: string) =>
    db('notifications')
      .where({ user_id: userId })
      .whereNull('read_at')
      .update({ read_at: db.fn.now() }),
  addDelivery: (notificationId: string, channel: string, status: string, error?: string) =>
    db('notification_deliveries').insert({
      id: randomUUID(),
      notification_id: notificationId,
      channel,
      status,
      error: error ?? null,
      sent_at: status === 'sent' ? db.fn.now() : null,
    }),
};

// ── push subscriptions ───────────────────────────────────────
export const pushSubs = {
  forUser: (userId: string): Promise<PushSubscription[]> =>
    db<PushSubscription>('push_subscriptions').where({ user_id: userId }),
  async upsert(sub: Omit<PushSubscription, 'id' | 'created_at' | 'last_used_at'>): Promise<void> {
    await db('push_subscriptions')
      .insert({ id: randomUUID(), ...sub })
      .onConflict('endpoint')
      .merge({
        p256dh: sub.p256dh,
        auth: sub.auth,
        user_agent: sub.user_agent,
        last_used_at: db.fn.now(),
      });
  },
  removeByEndpoint: (endpoint: string) => db('push_subscriptions').where({ endpoint }).del(),
};

// ── notification preferences ─────────────────────────────────
export const prefs = {
  async get(userId: string): Promise<NotificationPreferences> {
    let row = await db<NotificationPreferences>('notification_preferences')
      .where({ user_id: userId })
      .first();
    if (!row) {
      [row] = await db('notification_preferences').insert({ user_id: userId }).returning('*');
    }
    return row as NotificationPreferences;
  },
  update: (userId: string, patch: Partial<NotificationPreferences>) =>
    db('notification_preferences')
      .insert({ user_id: userId, ...patch })
      .onConflict('user_id')
      .merge({ ...patch, updated_at: db.fn.now() }),
};

// ── audit ────────────────────────────────────────────────────
export const audit = {
  log: (entry: {
    school_id: string | null;
    actor_id: string | null;
    action: string;
    entity: string;
    entity_id?: string;
    meta?: Record<string, unknown>;
    ip?: string;
  }) =>
    db('audit_logs')
      .insert({
        id: randomUUID(),
        school_id: entry.school_id,
        actor_id: entry.actor_id,
        action: entry.action,
        entity: entry.entity,
        entity_id: entry.entity_id ?? null,
        meta: JSON.stringify(entry.meta ?? {}),
        ip: entry.ip ?? null,
      })
      .catch(() => undefined),
};

export const refreshTokens = {
  create: (row: {
    user_id: string;
    token_hash: string;
    expires_at: Date;
    user_agent?: string;
    ip?: string;
  }) =>
    db('refresh_tokens').insert({
      id: randomUUID(),
      user_id: row.user_id,
      token_hash: row.token_hash,
      expires_at: row.expires_at,
      user_agent: row.user_agent ?? null,
      ip: row.ip ?? null,
    }),
  findValid: (tokenHash: string) =>
    db('refresh_tokens')
      .where({ token_hash: tokenHash })
      .whereNull('revoked_at')
      .where('expires_at', '>', db.fn.now())
      .first(),
  revoke: (tokenHash: string) =>
    db('refresh_tokens').where({ token_hash: tokenHash }).update({ revoked_at: db.fn.now() }),
  revokeAllForUser: (userId: string) =>
    db('refresh_tokens')
      .where({ user_id: userId })
      .whereNull('revoked_at')
      .update({ revoked_at: db.fn.now() }),
};
