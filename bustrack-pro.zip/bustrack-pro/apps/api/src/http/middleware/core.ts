import { randomUUID } from 'node:crypto';
import type { NextFunction, Request, RequestHandler, Response } from 'express';
import { ZodError, type ZodTypeAny } from 'zod';
import { HttpError, forbidden, unauthorized } from '../../domain/common';
import type { Role } from '../../domain/common';
import { logger } from '../../lib/logger';
import { verifyAccessToken } from '../../modules/auth/tokens';

/** Wrap an async handler so rejected promises reach the error middleware. */
export const wrap =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => {
    fn(req, res, next).catch(next);
  };

export const requestId: RequestHandler = (req, _res, next) => {
  req.id = (req.headers['x-request-id'] as string) || randomUUID();
  next();
};

/** Parse the bearer token if present; does not reject. */
export const authenticate: RequestHandler = (req, _res, next) => {
  const header = req.headers.authorization;
  if (header?.startsWith('Bearer ')) {
    try {
      req.auth = verifyAccessToken(header.slice(7));
    } catch {
      /* leave unauthenticated; requireAuth will 401 */
    }
  }
  next();
};

export const requireAuth: RequestHandler = (req, _res, next) => {
  if (!req.auth) return next(unauthorized());
  next();
};

export const requireRole =
  (...roles: Role[]): RequestHandler =>
  (req, _res, next) => {
    if (!req.auth) return next(unauthorized());
    if (!roles.includes(req.auth.role)) return next(forbidden());
    next();
  };

/**
 * Resolve the school the request operates on:
 *  - super_admin may pass ?schoolId / body.schoolId to act on any school
 *  - everyone else is pinned to their own school
 */
export function resolveSchoolId(req: Request): string {
  if (!req.auth) throw unauthorized();
  if (req.auth.role === 'super_admin') {
    const sid =
      (req.query.schoolId as string) ||
      (req.body && (req.body as Record<string, string>).schoolId) ||
      req.auth.schoolId;
    if (!sid) throw new HttpError(400, 'super_admin must specify schoolId');
    return sid;
  }
  if (!req.auth.schoolId) throw forbidden('Your account is not attached to a school');
  return req.auth.schoolId;
}

type Schemas = { body?: ZodTypeAny; query?: ZodTypeAny; params?: ZodTypeAny };

export const validate =
  (schemas: Schemas): RequestHandler =>
  (req, _res, next) => {
    try {
      if (schemas.params) req.params = schemas.params.parse(req.params);
      if (schemas.query) Object.assign(req.query, schemas.query.parse(req.query));
      if (schemas.body) req.body = schemas.body.parse(req.body);
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        next(new HttpError(400, 'Validation failed', err.flatten()));
      } else {
        next(err);
      }
    }
  };

export const notFoundHandler: RequestHandler = (_req, res) => {
  res.status(404).json({ error: 'Route not found' });
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction): void {
  if (err instanceof HttpError) {
    if (err.status >= 500) logger.error({ err, reqId: req.id }, err.message);
    res.status(err.status).json({ error: err.message, details: err.details });
    return;
  }
  if (err instanceof ZodError) {
    res.status(400).json({ error: 'Validation failed', details: err.flatten() });
    return;
  }
  const e = err as { code?: string; message?: string };
  if (e.code === '23505') {
    res.status(409).json({ error: 'That record already exists' });
    return;
  }
  if (e.code === '23503') {
    res.status(409).json({ error: 'Referenced record does not exist or is still in use' });
    return;
  }
  logger.error({ err, reqId: req.id }, 'Unhandled error');
  res.status(500).json({ error: 'Internal server error' });
}
