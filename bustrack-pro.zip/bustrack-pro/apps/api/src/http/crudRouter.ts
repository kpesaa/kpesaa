import { Router } from 'express';
import type { ZodTypeAny } from 'zod';
import { type Role, notFound, pagination } from '../domain/common';
import { audit } from '../repositories';
import type { CrudRepo } from '../repositories/base';
import { requireRole, resolveSchoolId, validate, wrap } from './middleware/core';

interface Options<Row extends { id: string }> {
  entity: string;
  repo: CrudRepo<Row>;
  createSchema: ZodTypeAny;
  updateSchema: ZodTypeAny;
  /** Roles allowed to write. Reads are allowed for any of writeRoles + readRoles. */
  writeRoles: Role[];
  readRoles?: Role[];
  searchColumns?: string[];
  /** Transform validated input before persisting (e.g. camel→snake). */
  toRow?: (input: Record<string, unknown>, schoolId: string) => Record<string, unknown>;
  /** Shape a row for the response. */
  present?: (row: Row) => unknown;
  validateRow?: (row: Record<string, unknown>, schoolId: string) => Promise<void>;
}

/** Standard school-scoped CRUD router. */
export function crudRouter<Row extends { id: string }>(o: Options<Row>): Router {
  const r = Router();
  const readRoles = [...new Set([...o.writeRoles, ...(o.readRoles ?? [])])];
  const present = o.present ?? ((row: Row) => row);
  const toRow =
    o.toRow ??
    ((input: Record<string, unknown>, schoolId: string) => ({ ...input, school_id: schoolId }));

  r.get(
    '/',
    requireRole(...readRoles),
    validate({ query: pagination }),
    wrap(async (req, res) => {
      const schoolId = resolveSchoolId(req);
      const { rows, total } = await o.repo.list({ school_id: schoolId }, req.query as never, {
        searchColumns: o.searchColumns,
      });
      res.json({
        data: rows.map(present),
        pagination: {
          page: Number(req.query.page ?? 1),
          pageSize: Number(req.query.pageSize ?? 25),
          total,
          totalPages: Math.max(1, Math.ceil(total / Number(req.query.pageSize ?? 25))),
        },
      });
    }),
  );

  r.get(
    '/:id',
    requireRole(...readRoles),
    wrap(async (req, res) => {
      const schoolId = resolveSchoolId(req);
      const row = await o.repo.findById(req.params.id!, { school_id: schoolId });
      if (!row) throw notFound(`${o.entity} not found`);
      res.json(present(row));
    }),
  );

  r.post(
    '/',
    requireRole(...o.writeRoles),
    validate({ body: o.createSchema }),
    wrap(async (req, res) => {
      const schoolId = resolveSchoolId(req);
      const data = toRow(req.body, schoolId);
      await o.validateRow?.(data, schoolId);
      const row = await o.repo.create(data as never);
      await audit.log({
        school_id: schoolId,
        actor_id: req.auth!.sub,
        action: 'create',
        entity: o.entity,
        entity_id: row.id,
        ip: req.ip,
      });
      res.status(201).json(present(row));
    }),
  );

  r.patch(
    '/:id',
    requireRole(...o.writeRoles),
    validate({ body: o.updateSchema }),
    wrap(async (req, res) => {
      const schoolId = resolveSchoolId(req);
      const existing = await o.repo.findById(req.params.id!, { school_id: schoolId });
      if (!existing) throw notFound(`${o.entity} not found`);
      const { school_id: _ignored, ...patch } = toRow(req.body, schoolId);
      await o.validateRow?.({ ...existing, ...patch }, schoolId);
      const row = await o.repo.update(req.params.id!, patch as never, { school_id: schoolId });
      await audit.log({
        school_id: schoolId,
        actor_id: req.auth!.sub,
        action: 'update',
        entity: o.entity,
        entity_id: req.params.id,
        ip: req.ip,
      });
      res.json(present(row!));
    }),
  );

  r.delete(
    '/:id',
    requireRole(...o.writeRoles),
    wrap(async (req, res) => {
      const schoolId = resolveSchoolId(req);
      const ok = await o.repo.remove(req.params.id!, { school_id: schoolId });
      if (!ok) throw notFound(`${o.entity} not found`);
      await audit.log({
        school_id: schoolId,
        actor_id: req.auth!.sub,
        action: 'delete',
        entity: o.entity,
        entity_id: req.params.id,
        ip: req.ip,
      });
      res.status(204).end();
    }),
  );

  return r;
}
