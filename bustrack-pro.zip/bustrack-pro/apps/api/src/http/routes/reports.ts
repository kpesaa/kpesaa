import { Router } from 'express';
import { db } from '../../db/knex';
import { requireRole, resolveSchoolId, wrap } from '../middleware/core';

const router = Router();
router.use(requireRole('admin', 'super_admin', 'dispatcher'));

router.get(
  '/summary',
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const [buses, busesOnTrip, students, tripsToday, notifs, agg] = await Promise.all([
      db('buses').where({ school_id: schoolId }).count({ c: '*' }).first(),
      db('trips').where({ school_id: schoolId, status: 'active' }).count({ c: '*' }).first(),
      db('students').where({ school_id: schoolId, status: 'active' }).count({ c: '*' }).first(),
      db('trips')
        .where({ school_id: schoolId })
        .andWhereRaw('created_at::date = current_date')
        .count({ c: '*' })
        .first(),
      db('notifications')
        .where({ school_id: schoolId })
        .andWhereRaw("created_at > now() - interval '7 days'")
        .count({ c: '*' })
        .first(),
      db('trips')
        .where({ school_id: schoolId, status: 'completed' })
        .select(
          db.raw('count(*)::int as total'),
          db.raw(
            'coalesce(avg(extract(epoch from (ended_at - started_at)) / 60), 0)::numeric(10,1) as avg_minutes',
          ),
          db.raw('coalesce(sum(distance_m), 0)::bigint as total_distance_m'),
        )
        .first(),
    ]);
    res.json({
      buses: Number((buses as { c: string }).c),
      busesOnTrip: Number((busesOnTrip as { c: string }).c),
      students: Number((students as { c: string }).c),
      tripsToday: Number((tripsToday as { c: string }).c),
      notifications7d: Number((notifs as { c: string }).c),
      completedTrips: Number((agg as { total: number }).total),
      avgTripMinutes: Number((agg as { avg_minutes: string }).avg_minutes),
      totalDistanceKm: Math.round(
        Number((agg as { total_distance_m: string }).total_distance_m) / 1000,
      ),
    });
  }),
);

router.get(
  '/trips',
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const from = (req.query.from as string) || null;
    const to = (req.query.to as string) || null;
    const q = db('trips as t')
      .join('buses as b', 'b.id', 't.bus_id')
      .join('users as d', 'd.id', 't.driver_id')
      .leftJoin('routes as r', 'r.id', 't.route_id')
      .where('t.school_id', schoolId)
      .where('t.status', 'completed');
    if (from) q.andWhere('t.started_at', '>=', from);
    if (to) q.andWhere('t.started_at', '<', to);
    const rows = await q
      .orderBy('t.started_at', 'desc')
      .limit(2000)
      .select(
        't.id',
        'b.plate_number',
        'b.label as bus_label',
        'd.name as driver_name',
        'r.name as route_name',
        't.direction',
        't.started_at',
        't.ended_at',
        db.raw(
          'round((extract(epoch from (t.ended_at - t.started_at)) / 60)::numeric, 1) as duration_minutes',
        ),
        db.raw('round((t.distance_m / 1000)::numeric, 2) as distance_km'),
        db.raw('(select count(*) from trip_positions tp where tp.trip_id = t.id) as gps_points'),
        db.raw(
          "(select count(*) from trip_events te where te.trip_id = t.id and te.type = 'route_deviation') as deviations",
        ),
      );

    if (req.query.format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="trips.csv"');
      res.send(toCsv(rows));
      return;
    }
    res.json({ data: rows, total: rows.length });
  }),
);

function toCsv(rows: Record<string, unknown>[]): string {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]!);
  const esc = (v: unknown) => {
    if (v == null) return '';
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.join(','), ...rows.map((r) => headers.map((h) => esc(r[h])).join(','))].join(
    '\n',
  );
}

export default router;
