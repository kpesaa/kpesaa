import { Router } from 'express';
import { env } from '../../config/env';
import rateLimit from 'express-rate-limit';
import { changePasswordDto, loginDto, refreshDto } from '../../domain/dto';
import { changePassword, login, logout, refresh, toPublicUser } from '../../modules/auth/service';
import { userRepo } from '../../repositories';
import { requireAuth, validate, wrap } from '../middleware/core';

const router = Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  skip: () => env.isTest,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts, please wait a few minutes' },
});

const ctx = (req: import('express').Request) => ({
  userAgent: req.headers['user-agent'],
  ip: req.ip,
});

router.post(
  '/login',
  loginLimiter,
  validate({ body: loginDto }),
  wrap(async (req, res) => {
    const result = await login(req.body.email, req.body.password, ctx(req));
    res.json(result);
  }),
);

router.post(
  '/refresh',
  validate({ body: refreshDto }),
  wrap(async (req, res) => {
    res.json(await refresh(req.body.refreshToken, ctx(req)));
  }),
);

router.post(
  '/logout',
  validate({ body: refreshDto.partial() }),
  wrap(async (req, res) => {
    await logout(req.body.refreshToken ?? '');
    res.status(204).end();
  }),
);

router.get(
  '/me',
  requireAuth,
  wrap(async (req, res) => {
    const user = await userRepo.findById(req.auth!.sub);
    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }
    res.json(toPublicUser(user));
  }),
);

router.post(
  '/change-password',
  requireAuth,
  validate({ body: changePasswordDto }),
  wrap(async (req, res) => {
    await changePassword(req.auth!.sub, req.body.currentPassword, req.body.newPassword);
    res.status(204).end();
  }),
);

export default router;
