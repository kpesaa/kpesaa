import { Router } from 'express';
import { db } from '../../db/knex';
import { notFound, pagination } from '../../domain/common';
import { routeCreateDto, routeUpdateDto, stopCreateDto, stopUpdateDto } from '../../domain/dto';
import { polylineLength } from '../../modules/geo/geo';
import { routes, stops } from '../../repositories';
import { requireRole, resolveSchoolId, validate, wrap } from '../middleware/core';

const router = Router();
const READ = ['admin', 'super_admin', 'dispatcher', 'driver'] as const;
const WRITE = ['admin', 'super_admin'] as const;

function present<T extends { path?: unknown }>(route: T) {
  const path = (route.path as [number, number][] | undefined) ?? [];
  return {
    ...route,
    length_m: Math.round(polylineLength(path.map(([lat, lng]) => ({ lat, lng })))),
  };
}

router.get(
  '/',
  requireRole(...READ),
  validate({ query: pagination }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const { rows, total } = await routes.list({ school_id: schoolId }, req.query as never, {
      searchColumns: ['name'],
    });
    const stopRows = rows.length
      ? await db('stops')
          .where({ school_id: schoolId })
          .whereIn(
            'route_id',
            rows.map((r) => r.id),
          )
          .orderBy('sequence', 'asc')
      : [];
    const stopsByRoute = new Map<string, unknown[]>();
    for (const s of stopRows) {
      const list = stopsByRoute.get(s.route_id) ?? [];
      list.push(s);
      stopsByRoute.set(s.route_id, list);
    }
    const pageSize = Number(req.query.pageSize ?? 25);
    res.json({
      data: rows.map((r) => ({ ...present(r), stops: stopsByRoute.get(r.id) ?? [] })),
      pagination: {
        total,
        page: Number(req.query.page ?? 1),
        pageSize,
        totalPages: Math.max(1, Math.ceil(total / pageSize)),
      },
    });
  }),
);

router.get(
  '/:id',
  requireRole(...READ),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const route = await routes.findById(req.params.id!, { school_id: schoolId });
    if (!route) throw notFound('Route not found');
    const stopRows = await db('stops').where({ route_id: route.id }).orderBy('sequence', 'asc');
    res.json({ ...present(route), stops: stopRows });
  }),
);

router.post(
  '/',
  requireRole(...WRITE),
  validate({ body: routeCreateDto }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const route = await routes.create({
      school_id: schoolId,
      name: req.body.name,
      description: req.body.description ?? null,
      path: JSON.stringify(req.body.path),
      active: req.body.active,
    } as never);
    res.status(201).json(present(route));
  }),
);

router.patch(
  '/:id',
  requireRole(...WRITE),
  validate({ body: routeUpdateDto }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const patch: Record<string, unknown> = {};
    for (const k of ['name', 'description', 'active'] as const) {
      if (req.body[k] !== undefined) patch[k] = req.body[k];
    }
    if (req.body.path !== undefined) patch.path = JSON.stringify(req.body.path);
    const route = await routes.update(req.params.id!, patch as never, { school_id: schoolId });
    if (!route) throw notFound('Route not found');
    res.json(present(route));
  }),
);

router.delete(
  '/:id',
  requireRole(...WRITE),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const ok = await routes.remove(req.params.id!, { school_id: schoolId });
    if (!ok) throw notFound('Route not found');
    res.status(204).end();
  }),
);

// ── stops (nested under route) ───────────────────────────────
router.post(
  '/:id/stops',
  requireRole(...WRITE),
  validate({ body: stopCreateDto.omit({ route_id: true }) }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const route = await routes.findById(req.params.id!, { school_id: schoolId });
    if (!route) throw notFound('Route not found');
    const stop = await stops.create({
      route_id: route.id,
      school_id: schoolId,
      ...req.body,
    } as never);
    res.status(201).json(stop);
  }),
);

router.patch(
  '/:routeId/stops/:stopId',
  requireRole(...WRITE),
  validate({ body: stopUpdateDto }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const stop = await stops.update(req.params.stopId!, req.body as never, {
      school_id: schoolId,
      route_id: req.params.routeId!,
    });
    if (!stop) throw notFound('Stop not found');
    res.json(stop);
  }),
);

router.delete(
  '/:routeId/stops/:stopId',
  requireRole(...WRITE),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const ok = await stops.remove(req.params.stopId!, {
      school_id: schoolId,
      route_id: req.params.routeId!,
    });
    if (!ok) throw notFound('Stop not found');
    res.status(204).end();
  }),
);

export default router;
