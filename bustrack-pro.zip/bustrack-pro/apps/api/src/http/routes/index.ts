import { Router } from 'express';
import authRoutes from './auth';
import handoverRoutes from './handover';
import busesRoutes from './buses';
import meRoutes from './me';
import reportsRoutes from './reports';
import routesRoutes from './routes';
import schoolsRoutes from './schools';
import studentsRoutes from './students';
import tripsRoutes from './trips';
import usersRoutes from './users';

export const api = Router();

api.use('/auth', authRoutes);
api.use('/handovers', handoverRoutes);
api.use('/me', meRoutes);
api.use('/schools', schoolsRoutes);
api.use('/users', usersRoutes);
api.use('/buses', busesRoutes);
api.use('/routes', routesRoutes);
api.use('/students', studentsRoutes);
api.use('/trips', tripsRoutes);
api.use('/reports', reportsRoutes);
