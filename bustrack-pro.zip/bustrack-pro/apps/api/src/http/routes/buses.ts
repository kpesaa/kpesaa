import type { Router } from 'express';
import { db } from '../../db/knex';
import { badRequest } from '../../domain/common';
import { busCreateDto, busUpdateDto } from '../../domain/dto';
import type { Bus } from '../../domain/models';
import { buses } from '../../repositories';
import { crudRouter } from '../crudRouter';

const router: Router = crudRouter<Bus>({
  entity: 'bus',
  validateRow: async (data, schoolId) => {
    if (data.driver_id && !(await db('users').where({ id: data.driver_id, school_id: schoolId, role: 'driver', status: 'active' }).first())) {
      throw badRequest('Assigned driver must be active and belong to this school');
    }
  },
  repo: buses,
  createSchema: busCreateDto,
  updateSchema: busUpdateDto,
  writeRoles: ['admin', 'super_admin'],
  readRoles: ['dispatcher'],
  searchColumns: ['plate_number', 'label', 'model'],
});

export default router;
