import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { authorise, issueCode, myHandovers, revoke, roster, schoolHandovers, verify } from '../../modules/handover/service';
import { requireAuth, requireRole, resolveSchoolId, validate, wrap } from '../middleware/core';

const router = Router();
router.use(requireAuth);
const id = z.object({ id: z.string().uuid() });
const trip = z.object({ tripId: z.string().uuid() });
router.get('/mine', requireRole('parent'), wrap(async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json(await myHandovers(req.auth!.sub, resolveSchoolId(req)));
}));
router.get('/school', requireRole('admin', 'dispatcher', 'super_admin'), wrap(async (req, res) => {
  res.json(await schoolHandovers(resolveSchoolId(req)));
}));
router.get('/trips/:tripId', requireRole('driver'), validate({ params: trip }), wrap(async (req, res) => {
  res.json(await roster(req.params.tripId!, req.auth!.sub));
}));
router.post('/trips/:tripId/request', requireRole('driver'), validate({ params: trip,
  body: z.object({ studentId: z.string().uuid() }) }), wrap(async (req, res) => {
  res.status(201).json(await issueCode(req.params.tripId!, req.body.studentId, req.auth!.sub));
}));
router.post('/:id/authorise', requireRole('parent'), validate({ params: id,
  body: z.object({ receiverName: z.string().trim().min(2).max(100),
    relationship: z.string().trim().min(2).max(80) }) }), wrap(async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json(await authorise(req.params.id!, req.auth!.sub, resolveSchoolId(req), req.body.receiverName, req.body.relationship));
}));
router.post('/:id/revoke', requireRole('parent'), validate({ params: id }), wrap(async (req, res) => {
  res.json(await revoke(req.params.id!, req.auth!.sub, resolveSchoolId(req)));
}));
router.post('/:id/verify', requireRole('driver'), rateLimit({ windowMs: 60_000, limit: 20,
  keyGenerator: (req) => req.auth!.sub, standardHeaders: 'draft-7', legacyHeaders: false }),
  validate({ params: id, body: z.object({ code: z.string().regex(/^\d{6}$/), receiverConfirmed: z.literal(true) }) }),
  wrap(async (req, res) => { res.json(await verify(req.params.id!, req.auth!.sub, req.body.code)); }));
export default router;
