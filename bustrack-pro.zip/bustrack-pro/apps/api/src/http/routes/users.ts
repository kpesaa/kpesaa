import { randomBytes } from 'node:crypto';
import { Router } from 'express';
import { badRequest, forbidden, notFound, pagination } from '../../domain/common';
import { userCreateDto, userUpdateDto } from '../../domain/dto';
import { hashPassword, toPublicUser } from '../../modules/auth/service';
import { audit, prefs, userRepo, users } from '../../repositories';
import { refreshTokens } from '../../repositories';
import { requireRole, resolveSchoolId, validate, wrap } from '../middleware/core';

const router = Router();
router.use(requireRole('admin', 'super_admin', 'dispatcher'));

const assignableRoles = new Set(['admin', 'dispatcher', 'driver', 'parent']);

router.get(
  '/',
  validate({ query: pagination }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const role = req.query.role as string | undefined;
    const where: Record<string, string> = { school_id: schoolId };
    if (role) where.role = role;
    const { rows, total } = await users.list(where as never, req.query as never, {
      searchColumns: ['name', 'email', 'phone'],
    });
    res.json({
      data: rows.map(toPublicUser),
      pagination: {
        total,
        page: Number(req.query.page ?? 1),
        pageSize: Number(req.query.pageSize ?? 25),
        totalPages: Math.max(1, Math.ceil(total / Number(req.query.pageSize ?? 25))),
      },
    });
  }),
);

router.get(
  '/:id',
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const u = await userRepo.findById(req.params.id!, { school_id: schoolId });
    if (!u) throw notFound('User not found');
    res.json(toPublicUser(u));
  }),
);

router.post(
  '/',
  requireRole('admin', 'super_admin'),
  validate({ body: userCreateDto }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    if (!assignableRoles.has(req.body.role)) throw forbidden('That role cannot be assigned here');
    const existing = await userRepo.byEmail(req.body.email);
    if (existing) throw badRequest('A user with that email already exists');

    const tempPassword = req.body.password ?? randomBytes(9).toString('base64url');
    const user = await users.create({
      school_id: schoolId,
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone ?? null,
      role: req.body.role,
      status: req.body.status,
      password_hash: await hashPassword(tempPassword),
    } as never);
    await prefs.get(user.id);
    await audit.log({
      school_id: schoolId,
      actor_id: req.auth!.sub,
      action: 'create',
      entity: 'user',
      entity_id: user.id,
      ip: req.ip,
    });
    res.status(201).json({
      user: toPublicUser(user),
      // Surfaced once so the admin can pass it on; not stored anywhere in cleartext.
      tempPassword: req.body.password ? undefined : tempPassword,
    });
  }),
);

router.patch(
  '/:id',
  requireRole('admin', 'super_admin'),
  validate({ body: userUpdateDto }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const existing = await userRepo.findById(req.params.id!, { school_id: schoolId });
    if (!existing) throw notFound('User not found');
    if (existing.role === 'super_admin') throw forbidden();

    const patch: Record<string, unknown> = {};
    for (const k of ['name', 'phone', 'role', 'status'] as const) {
      if (req.body[k] !== undefined) patch[k] = req.body[k];
    }
    if (patch.role && !assignableRoles.has(patch.role as string)) throw forbidden('Invalid role');
    if (req.body.password) {
      patch.password_hash = await hashPassword(req.body.password);
      await refreshTokens.revokeAllForUser(existing.id);
    }
    const updated = await users.update(existing.id, patch as never, { school_id: schoolId });
    await audit.log({
      school_id: schoolId,
      actor_id: req.auth!.sub,
      action: 'update',
      entity: 'user',
      entity_id: existing.id,
      ip: req.ip,
    });
    res.json(toPublicUser(updated!));
  }),
);

router.delete(
  '/:id',
  requireRole('admin', 'super_admin'),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    if (req.params.id === req.auth!.sub) throw badRequest('You cannot delete your own account');
    const ok = await users.remove(req.params.id!, { school_id: schoolId });
    if (!ok) throw notFound('User not found');
    await audit.log({
      school_id: schoolId,
      actor_id: req.auth!.sub,
      action: 'delete',
      entity: 'user',
      entity_id: req.params.id,
      ip: req.ip,
    });
    res.status(204).end();
  }),
);

export default router;
