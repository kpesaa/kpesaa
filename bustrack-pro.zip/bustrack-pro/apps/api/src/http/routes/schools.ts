import { randomUUID } from 'node:crypto';
import { Router } from 'express';
import { z } from 'zod';
import { db } from '../../db/knex';
import { notFound, pagination } from '../../domain/common';
import { schoolCreateDto, schoolUpdateDto } from '../../domain/dto';
import { hashPassword } from '../../modules/auth/service';
import { prefs, schools } from '../../repositories';
import { requireRole, validate, wrap } from '../middleware/core';

const schoolAdminDto = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8),
});

const router = Router();
router.use(requireRole('super_admin'));

router.get(
  '/',
  validate({ query: pagination }),
  wrap(async (req, res) => {
    const { rows, total } = await schools.list({}, req.query as never, {
      searchColumns: ['name', 'slug'],
    });
    const pageSize = Number(req.query.pageSize ?? 25);
    res.json({
      data: rows,
      pagination: {
        total,
        page: Number(req.query.page ?? 1),
        pageSize,
        totalPages: Math.max(1, Math.ceil(total / pageSize)),
      },
    });
  }),
);

router.get(
  '/:id',
  wrap(async (req, res) => {
    const s = await schools.findById(req.params.id!);
    if (!s) throw notFound('School not found');
    res.json(s);
  }),
);

router.post(
  '/',
  validate({ body: schoolCreateDto }),
  wrap(async (req, res) => {
    const school = await schools.create(req.body);
    res.status(201).json(school);
  }),
);

router.patch(
  '/:id',
  validate({ body: schoolUpdateDto }),
  wrap(async (req, res) => {
    const s = await schools.update(req.params.id!, req.body);
    if (!s) throw notFound('School not found');
    res.json(s);
  }),
);

router.delete(
  '/:id',
  wrap(async (req, res) => {
    const ok = await schools.remove(req.params.id!);
    if (!ok) throw notFound('School not found');
    res.status(204).end();
  }),
);

/** Bootstrap a school with its first admin account in one call. */
router.post(
  '/:id/admins',
  validate({ body: schoolAdminDto }),
  wrap(async (req, res) => {
    const school = await schools.findById(req.params.id!);
    if (!school) throw notFound('School not found');
    const [user] = await db('users')
      .insert({
        id: randomUUID(),
        school_id: school.id,
        name: req.body.name,
        email: req.body.email,
        password_hash: await hashPassword(req.body.password),
        role: 'admin',
        status: 'active',
      })
      .returning('*');
    await prefs.get(user.id);
    res.status(201).json({ id: user.id, email: user.email, role: user.role });
  }),
);

export default router;
