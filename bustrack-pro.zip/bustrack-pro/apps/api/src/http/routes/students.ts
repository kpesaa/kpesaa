import { Router } from 'express';
import { db } from '../../db/knex';
import { badRequest, notFound, pagination } from '../../domain/common';
import { studentCreateDto, studentUpdateDto } from '../../domain/dto';
import { audit, guardianships, students } from '../../repositories';
import { requireRole, resolveSchoolId, validate, wrap } from '../middleware/core';

async function validateLinks(data: Record<string, any>, schoolId: string) {
  for (const [field, table] of [['bus_id', 'buses'], ['route_id', 'routes'], ['pickup_stop_id', 'stops'], ['dropoff_stop_id', 'stops']] as const) {
    if (!data[field]) continue;
    const row = await db(table!).where({ id: data[field], school_id: schoolId }).first();
    if (!row) throw badRequest(`${field} must belong to this school`);
    if (table === 'stops' && data.route_id && row.route_id !== data.route_id) throw badRequest('Pickup and drop-off stops must belong to the selected route');
  }
  if (data.guardian_ids?.length) {
    const ids = [...new Set(data.guardian_ids)];
    const valid = await db('users').where({ school_id: schoolId, role: 'parent', status: 'active' }).whereIn('id', ids as string[]);
    if (valid.length !== ids.length) throw badRequest('Guardians must be active parent accounts in this school');
  }
}

const router = Router();
const READ = ['admin', 'super_admin', 'dispatcher'] as const;
const WRITE = ['admin', 'super_admin'] as const;

async function withGuardians(studentId: string) {
  return db('guardianships as g')
    .join('users as u', 'u.id', 'g.guardian_id')
    .where('g.student_id', studentId)
    .select('u.id', 'u.name', 'u.email', 'u.phone', 'g.relationship', 'g.is_primary', 'g.notify');
}

/** Batch id → column lookup for a table. */
async function lookup(
  table: string,
  column: string,
  ids: (string | null)[],
): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  const unique = [...new Set(ids.filter(Boolean) as string[])];
  if (!unique.length) return map;
  const rows = await db(table).whereIn('id', unique).select('id', column);
  for (const r of rows) map.set(r.id, r[column]);
  return map;
}

/** Batch-load { id, name } guardians for a set of students. */
async function guardiansByStudent(
  studentIds: string[],
): Promise<Map<string, { id: string; name: string }[]>> {
  const map = new Map<string, { id: string; name: string }[]>();
  if (!studentIds.length) return map;
  const rows = await db('guardianships as g')
    .join('users as u', 'u.id', 'g.guardian_id')
    .whereIn('g.student_id', studentIds)
    .orderBy('g.is_primary', 'desc')
    .select('g.student_id', 'u.id', 'u.name');
  for (const r of rows) {
    const list = map.get(r.student_id) ?? [];
    list.push({ id: r.id, name: r.name });
    map.set(r.student_id, list);
  }
  return map;
}

router.get(
  '/',
  requireRole(...READ),
  validate({ query: pagination }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const where: Record<string, string> = { school_id: schoolId };
    if (req.query.bus_id) where.bus_id = req.query.bus_id as string;
    if (req.query.route_id) where.route_id = req.query.route_id as string;
    const { rows, total } = await students.list(where as never, req.query as never, {
      searchColumns: ['first_name', 'last_name', 'grade'],
    });
    const [guardians, buses, routes] = await Promise.all([
      guardiansByStudent(rows.map((r) => r.id)),
      lookup(
        'buses',
        'plate_number',
        rows.map((r) => r.bus_id),
      ),
      lookup(
        'routes',
        'name',
        rows.map((r) => r.route_id),
      ),
    ]);
    res.json({
      data: rows.map((r) => ({
        ...r,
        guardians: guardians.get(r.id) ?? [],
        plate_number: r.bus_id ? (buses.get(r.bus_id) ?? null) : null,
        route_name: r.route_id ? (routes.get(r.route_id) ?? null) : null,
      })),
      pagination: {
        total,
        page: Number(req.query.page ?? 1),
        pageSize: Number(req.query.pageSize ?? 25),
        totalPages: Math.max(1, Math.ceil(total / Number(req.query.pageSize ?? 25))),
      },
    });
  }),
);

router.get(
  '/:id',
  requireRole(...READ),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const student = await students.findById(req.params.id!, { school_id: schoolId });
    if (!student) throw notFound('Student not found');
    res.json({ ...student, guardians: await withGuardians(student.id) });
  }),
);

router.post(
  '/',
  requireRole(...WRITE),
  validate({ body: studentCreateDto }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    await validateLinks(req.body, schoolId);
    const { guardian_ids, ...data } = req.body;
    const student = await db.transaction(async (trx) => {
      const created = await students.create({ ...data, school_id: schoolId } as never, trx);
      if (guardian_ids?.length) await guardianships.set(created.id, guardian_ids, trx);
      return created;
    });
    await audit.log({
      school_id: schoolId,
      actor_id: req.auth!.sub,
      action: 'create',
      entity: 'student',
      entity_id: student.id,
      ip: req.ip,
    });
    res.status(201).json({ ...student, guardians: await withGuardians(student.id) });
  }),
);

router.patch(
  '/:id',
  requireRole(...WRITE),
  validate({ body: studentUpdateDto }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const existing = await students.findById(req.params.id!, { school_id: schoolId });
    if (!existing) throw notFound('Student not found');
    await validateLinks({ ...existing, ...req.body }, schoolId);
    const { guardian_ids, ...data } = req.body;
    const student =
      data && Object.keys(data).length
        ? await students.update(existing.id, data as never, { school_id: schoolId })
        : existing;
    if (guardian_ids) await guardianships.set(existing.id, guardian_ids);
    res.json({ ...student, guardians: await withGuardians(existing.id) });
  }),
);

router.delete(
  '/:id',
  requireRole(...WRITE),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const ok = await students.remove(req.params.id!, { school_id: schoolId });
    if (!ok) throw notFound('Student not found');
    res.status(204).end();
  }),
);

export default router;
