import { Router } from 'express';
import { db } from '../../db/knex';
import { badRequest, notFound, pagination } from '../../domain/common';
import { emergencyDto, positionDto, positionsBatchDto, startTripDto } from '../../domain/dto';
import {
  endTrip,
  ingestPositions,
  markArrivedSchool,
  markDepartedSchool,
  raiseEmergency,
  startTrip,
} from '../../modules/tracking/service';
import { positions, tripEvents, tripRepo } from '../../repositories';
import { requireRole, resolveSchoolId, validate, wrap } from '../middleware/core';

const router = Router();
const DISPATCH = ['admin', 'super_admin', 'dispatcher'] as const;

// ── driver actions ───────────────────────────────────────────
router.post(
  '/',
  requireRole('driver'),
  validate({ body: startTripDto }),
  wrap(async (req, res) => {
    const trip = await startTrip({
      schoolId: req.auth!.schoolId!,
      driverId: req.auth!.sub,
      busId: req.body.bus_id,
      routeId: req.body.route_id ?? null,
      direction: req.body.direction,
    });
    res.status(201).json(trip);
  }),
);

router.post(
  '/:id/positions',
  requireRole('driver'),
  validate({ body: positionsBatchDto }),
  wrap(async (req, res) => {
    const result = await ingestPositions(req.params.id!, req.auth!.sub, req.body.positions);
    res.json(result);
  }),
);

// Convenience single-position endpoint (device live stream).
router.post(
  '/:id/position',
  requireRole('driver'),
  validate({ body: positionDto }),
  wrap(async (req, res) => {
    const result = await ingestPositions(req.params.id!, req.auth!.sub, [req.body]);
    res.json(result);
  }),
);

router.post(
  '/:id/depart',
  requireRole('driver'),
  wrap(async (req, res) => {
    await markDepartedSchool(req.params.id!, req.auth!.sub);
    res.status(204).end();
  }),
);

router.post(
  '/:id/arrive',
  requireRole('driver'),
  wrap(async (req, res) => {
    await markArrivedSchool(req.params.id!, req.auth!.sub);
    res.status(204).end();
  }),
);

router.post(
  '/:id/emergency',
  requireRole('driver'),
  validate({ body: emergencyDto }),
  wrap(async (req, res) => {
    await raiseEmergency(req.params.id!, req.auth!.sub, req.body.note);
    res.status(202).json({ ok: true });
  }),
);

router.post(
  '/:id/end',
  requireRole('driver'),
  wrap(async (req, res) => {
    const trip = await endTrip(req.params.id!, req.auth!.sub);
    res.json(trip);
  }),
);

// ── dispatch / admin views ───────────────────────────────────
router.get(
  '/',
  requireRole(...DISPATCH),
  validate({ query: pagination }),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const status = req.query.status as string | undefined;
    const where: Record<string, string> = { 't.school_id': schoolId };
    if (status) where['t.status'] = status;
    const p = req.query as unknown as { page: number; pageSize: number };
    const base = db('trips as t')
      .join('buses as b', 'b.id', 't.bus_id')
      .join('users as d', 'd.id', 't.driver_id')
      .leftJoin('routes as r', 'r.id', 't.route_id')
      .where(where);
    const countRow = (await base.clone().count({ c: '*' }).first()) as { c: string };
    const rows = await base
      .clone()
      .orderBy('t.created_at', 'desc')
      .limit(p.pageSize)
      .offset((p.page - 1) * p.pageSize)
      .select(
        't.*',
        'b.plate_number',
        'b.label as bus_label',
        'd.name as driver_name',
        'r.name as route_name',
        db.raw(
          '(select count(*) from trip_positions tp where tp.trip_id = t.id) as position_count',
        ),
      );
    res.json({
      data: rows,
      pagination: {
        total: Number(countRow.c),
        page: p.page,
        pageSize: p.pageSize,
        totalPages: Math.max(1, Math.ceil(Number(countRow.c) / p.pageSize)),
      },
    });
  }),
);

router.get(
  '/active',
  requireRole(...DISPATCH),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const rows = await db('trips as t')
      .join('buses as b', 'b.id', 't.bus_id')
      .join('users as d', 'd.id', 't.driver_id')
      .leftJoin('routes as r', 'r.id', 't.route_id')
      .where({ 't.school_id': schoolId, 't.status': 'active' })
      .select(
        't.*',
        'b.plate_number',
        'b.label as bus_label',
        'd.name as driver_name',
        'r.name as route_name',
      );
    res.json(rows);
  }),
);

router.get(
  '/:id',
  requireRole(...DISPATCH),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const trip = await tripRepo.findById(req.params.id!, { school_id: schoolId });
    if (!trip) throw notFound('Trip not found');
    const [events, track] = await Promise.all([
      tripEvents.forTrip(trip.id),
      positions.forTrip(trip.id),
    ]);
    res.json({ ...trip, events, track });
  }),
);

router.get(
  '/:id/track',
  requireRole(...DISPATCH, 'driver'),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const trip = await tripRepo.findById(req.params.id!, { school_id: schoolId });
    if (!trip) throw notFound('Trip not found');
    res.json(await positions.forTrip(trip.id));
  }),
);

router.post(
  '/:id/cancel',
  requireRole('admin', 'super_admin'),
  wrap(async (req, res) => {
    const schoolId = resolveSchoolId(req);
    const trip = await tripRepo.findById(req.params.id!, { school_id: schoolId });
    if (!trip) throw notFound('Trip not found');
    if (trip.status !== 'active') throw badRequest('Only active trips can be cancelled');
    const updated = await tripRepo.update(trip.id, {
      status: 'cancelled',
      ended_at: db.fn.now() as never,
    });
    res.json(updated);
  }),
);

export default router;
