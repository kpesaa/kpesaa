import { Router } from 'express';
import { env } from '../../config/env';
import { db } from '../../db/knex';
import { notFound } from '../../domain/common';
import { prefsUpdateDto, pushSubscribeDto } from '../../domain/dto';
import { notifications, prefs, pushSubs, schools, tripRepo } from '../../repositories';
import { requireAuth, requireRole, resolveSchoolId, validate, wrap } from '../middleware/core';

const router = Router();
router.use(requireAuth);

// ── my school ────────────────────────────────────────────────
router.get(
  '/school',
  wrap(async (req, res) => {
    if (!req.auth!.schoolId) {
      res.json(null);
      return;
    }
    const school = await schools.findById(resolveSchoolId(req));
    if (!school) throw notFound('School not found');
    res.json(school);
  }),
);

// ── notifications ────────────────────────────────────────────
router.get(
  '/notifications',
  wrap(async (req, res) => {
    const limit = Math.min(Number(req.query.limit ?? 50), 200);
    res.json(await notifications.listForUser(req.auth!.sub, limit));
  }),
);

router.get(
  '/notifications/unread-count',
  wrap(async (req, res) => {
    res.json({ count: await notifications.unreadCount(req.auth!.sub) });
  }),
);

router.post(
  '/notifications/:id/read',
  wrap(async (req, res) => {
    await notifications.markRead(req.auth!.sub, req.params.id!);
    res.status(204).end();
  }),
);

router.post(
  '/notifications/read-all',
  wrap(async (req, res) => {
    await notifications.markAllRead(req.auth!.sub);
    res.status(204).end();
  }),
);

// ── preferences ──────────────────────────────────────────────
router.get(
  '/preferences',
  wrap(async (req, res) => {
    res.json(await prefs.get(req.auth!.sub));
  }),
);

router.patch(
  '/preferences',
  validate({ body: prefsUpdateDto }),
  wrap(async (req, res) => {
    await prefs.update(req.auth!.sub, req.body);
    res.json(await prefs.get(req.auth!.sub));
  }),
);

// ── web push ─────────────────────────────────────────────────
router.get('/push/public-key', (_req, res) => {
  res.json({ key: env.VAPID_PUBLIC_KEY ?? null });
});

router.post(
  '/push/subscribe',
  validate({ body: pushSubscribeDto }),
  wrap(async (req, res) => {
    await pushSubs.upsert({
      user_id: req.auth!.sub,
      endpoint: req.body.endpoint,
      p256dh: req.body.keys.p256dh,
      auth: req.body.keys.auth,
      user_agent: req.headers['user-agent'] ?? null,
    });
    res.status(201).json({ ok: true });
  }),
);

router.post(
  '/push/unsubscribe',
  validate({ body: pushSubscribeDto.pick({ endpoint: true }) }),
  wrap(async (req, res) => {
    await pushSubs.removeByEndpoint(req.body.endpoint);
    res.status(204).end();
  }),
);

// ── parent context ───────────────────────────────────────────
router.get(
  '/children',
  requireRole('parent'),
  wrap(async (req, res) => {
    const rows = await db('guardianships as g')
      .join('students as s', 's.id', 'g.student_id')
      .leftJoin('buses as b', 'b.id', 's.bus_id')
      .leftJoin('users as d', 'd.id', 'b.driver_id')
      .leftJoin('routes as r', 'r.id', 's.route_id')
      .leftJoin('stops as ps', 'ps.id', 's.pickup_stop_id')
      .leftJoin('stops as ds', 'ds.id', 's.dropoff_stop_id')
      .where('g.guardian_id', req.auth!.sub)
      .andWhere('s.school_id', resolveSchoolId(req))
      .select(
        's.*',
        'b.plate_number',
        'b.label as bus_label',
        'b.status as bus_status',
        'd.name as driver_name',
        'd.phone as driver_phone',
        'r.name as route_name',
        'r.path as route_path',
        db.raw('row_to_json(ps.*) as pickup_stop'),
        db.raw('row_to_json(ds.*) as dropoff_stop'),
      );

    // Attach the currently-active trip (if any) for each child's bus.
    const busIds = [...new Set(rows.map((r) => r.bus_id).filter(Boolean))] as string[];
    const activeTrips = busIds.length
      ? await db('trips').whereIn('bus_id', busIds).where({ status: 'active' })
      : [];
    const byBus = new Map(activeTrips.map((t) => [t.bus_id, t]));
    res.json(
      rows.map((r) => ({ ...r, active_trip: r.bus_id ? (byBus.get(r.bus_id) ?? null) : null })),
    );
  }),
);

// ── driver context ───────────────────────────────────────────
router.get(
  '/bus',
  requireRole('driver'),
  wrap(async (req, res) => {
    const bus = await db('buses as b')
      .leftJoin('routes as r', (j) =>
        j.on(
          'r.id',
          '=',
          db.raw(
            '(select route_id from students s where s.bus_id = b.id and s.route_id is not null limit 1)',
          ),
        ),
      )
      .where('b.driver_id', req.auth!.sub)
      .select('b.*', 'r.name as route_name',
        'r.path as route_path', 'r.id as route_id')
      .first();
    if (!bus) throw notFound('No bus is assigned to your account');
    const activeTrip = await tripRepo.activeForDriver(req.auth!.sub);
    const studentCount = (await db('students')
      .where({ bus_id: bus.id, status: 'active' })
      .count({ c: '*' })
      .first()) as { c: string };
    res.json({ ...bus, active_trip: activeTrip ?? null, student_count: Number(studentCount.c) });
  }),
);

router.get(
  '/trip',
  requireRole('driver'),
  wrap(async (req, res) => {
    const trip = await tripRepo.activeForDriver(req.auth!.sub);
    res.json(trip ?? null);
  }),
);

router.get('/history', requireRole('parent'), wrap(async (req, res) => {
  const schoolId = resolveSchoolId(req);
  const busIds = await db('guardianships as g').join('students as s', 's.id', 'g.student_id')
    .where({ 'g.guardian_id': req.auth!.sub, 's.school_id': schoolId }).whereNotNull('s.bus_id').pluck('s.bus_id');
  const rows = await db('trips as t').join('buses as b', 'b.id', 't.bus_id').join('users as d', 'd.id', 't.driver_id')
    .where({ 't.school_id': schoolId }).whereIn('t.bus_id', busIds).whereNot('t.status', 'active')
    .select('t.id', 't.direction', 't.status', 't.started_at', 't.ended_at', 't.distance_m', 'b.plate_number', 'd.name as driver_name')
    .orderBy('t.started_at', 'desc').limit(100);
  res.json(rows);
}));

export default router;
