import type { Server as HttpServer } from 'node:http';
import { createAdapter } from '@socket.io/redis-adapter';
import { Redis } from 'ioredis';
import { Server, type Socket } from 'socket.io';
import { env } from '../config/env';
import { db } from '../db/knex';
import { logger } from '../lib/logger';
import { verifyAccessToken } from '../modules/auth/tokens';
import type { AccessClaims } from '../modules/auth/tokens';
import { guardianships } from '../repositories';

let io: Server | null = null;

type AuthedSocket = Socket & { data: { claims: AccessClaims } };

export async function initRealtime(httpServer: HttpServer): Promise<Server> {
  io = new Server(httpServer, {
    cors: { origin: env.corsOrigins, credentials: true },
    transports: ['websocket', 'polling'],
  });

  if (env.REDIS_URL) {
    const pub = new Redis(env.REDIS_URL);
    const sub = pub.duplicate();
    io.adapter(createAdapter(pub, sub));
    logger.info('Socket.IO Redis adapter enabled');
  }

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token as string | undefined;
    if (!token) return next(new Error('unauthorized'));
    try {
      (socket as AuthedSocket).data.claims = verifyAccessToken(token);
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', async (socket) => {
    const { claims } = (socket as AuthedSocket).data;
    socket.join(`user:${claims.sub}`);
    if (claims.schoolId) socket.join(`school:${claims.schoolId}`);

    if (claims.role === 'admin' || claims.role === 'dispatcher' || claims.role === 'super_admin') {
      socket.join(`dispatch:${claims.schoolId ?? 'all'}`);
    }

    if (claims.role === 'parent') {
      const studentIds = await guardianships.studentIdsForGuardian(claims.sub);
      for (const sid of studentIds) socket.join(`student:${sid}`);
    }

    // Clients ask to follow a specific bus's live position.
    socket.on('watch:bus', async (busId: string) => {
      try {
        if (await canWatchBus(claims, busId)) socket.join(`bus:${busId}`);
        else socket.emit('watch:denied', { message: 'You cannot view this bus' });
      } catch { socket.emit('watch:denied', { message: 'Could not authorise this bus' }); }
    });
    socket.on('unwatch:bus', (busId: string) => {
      if (typeof busId === 'string') socket.leave(`bus:${busId}`);
    });

    logger.debug({ user: claims.sub, role: claims.role }, 'socket connected');
  });

  return io;
}

export function getIo(): Server {
  if (!io) throw new Error('Realtime not initialised');
  return io;
}

// ── typed emit helpers ───────────────────────────────────────
export const emit = {
  toUser: (userId: string, event: string, payload: unknown) =>
    io?.to(`user:${userId}`).emit(event, payload),
  toSchool: (schoolId: string, event: string, payload: unknown) =>
    io?.to(`school:${schoolId}`).emit(event, payload),
  toDispatch: (schoolId: string, event: string, payload: unknown) =>
    io?.to(`dispatch:${schoolId}`).emit(event, payload),
  toBus: (busId: string, event: string, payload: unknown) =>
    io?.to(`bus:${busId}`).emit(event, payload),
  toStudentGuardians: (studentId: string, event: string, payload: unknown) =>
    io?.to(`student:${studentId}`).emit(event, payload),
};

/** Authorise every live subscription, rather than trusting a client-supplied bus ID. */
export async function canWatchBus(claims: AccessClaims, busId: string): Promise<boolean> {
  if (typeof busId !== 'string' || !/^[0-9a-f-]{36}$/i.test(busId)) return false;
  const user = await db('users').where({ id: claims.sub, status: 'active' }).first();
  const bus = await db('buses').where({ id: busId }).first();
  if (!user || !bus || user.school_id !== claims.schoolId || user.role !== claims.role) return false;
  if (claims.role === 'super_admin') return true;
  if (bus.school_id !== claims.schoolId) return false;
  if (['admin', 'dispatcher'].includes(claims.role)) return true;
  if (claims.role === 'driver') return bus.driver_id === claims.sub;
  return Boolean(await db('guardianships as g').join('students as s', 's.id', 'g.student_id')
    .where({ 'g.guardian_id': claims.sub, 's.bus_id': busId, 's.school_id': claims.schoolId, 's.status': 'active' }).first());
}
