// Present for tooling compatibility; migrations are normally run via `npm run db:migrate`
// (src/db/migrate.ts), which registers tsx so .ts migration files load correctly.
import { knexConfig } from './src/db/knex';

export default knexConfig;
