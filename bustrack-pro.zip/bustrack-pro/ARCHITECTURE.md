# Architecture

## Layers

As illustrated in Figure 3.4, the role-based React clients use HTTPS REST and
Socket.IO to communicate with the Express API. PostgreSQL stores application
records; an optional Redis adapter supports cross-instance realtime delivery.

![Figure 3.4: System architecture](docs/diagrams/figure-3-4.png)

The [design addendum](docs/DESIGN_ADDENDUM.md) contains all eight referenced
design diagrams and the delegated handover activity and sequence.

Notification channels attached to `modules/notifications`:
in-app (Socket.IO + `notifications` table), email (Nodemailer), web-push (VAPID),
SMS (adapter: `log` | Termii).

## Data model (PostgreSQL)

- **schools** — tenant. lat/lng + radius = the school geofence.
- **users** — `role ∈ {super_admin, admin, dispatcher, driver, parent}`, `school_id`
  (null only for super_admin). Failed-login counter + `locked_until`.
- **refresh_tokens** — hashed, rotated on use, revocable per-user.
- **buses** — belong to a school, optional `driver_id`.
- **routes** — `path` = ordered `[lat,lng]` polyline (jsonb).
- **stops** — belong to a route; `kind ∈ {pickup, dropoff, both}`, own radius.
- **students** — `bus_id`, `route_id`, `pickup_stop_id`, `dropoff_stop_id`.
- **guardianships** — student ⇄ parent (many-to-many), `notify` flag.
- **trips** — one **active** per bus (partial unique index). Carries
  `last_lat/lng`, `distance_m` and **`engine_state`** (jsonb) — the geofence
  engine's bookkeeping (`left_school`, deviation strikes) lives here, not in
  process memory, so an API restart resumes cleanly.
- **trip_positions** — GPS track, `(trip_id, recorded_at)` indexed.
- **trip_events** — canonical event log. `UNIQUE(trip_id, dedupe_key)` makes every
  geofence event idempotent.
- **notifications** / **notification_deliveries** — one row per recipient, plus a
  per-channel delivery record (sent / skipped / failed).
- **push_subscriptions**, **notification_preferences**, **audit_logs**.
- **child_handovers** — one lifecycle per trip/student pair. Encrypted code,
  keyed code hash, expiry, receiving adult, parent authorisation, driver
  verification and failed-attempt counter. Audit records retain past actions.

## Request / tracking flow

1. **Driver** signs in → `GET /me/bus` → **`POST /trips`** (409 if the bus already
   has an active trip). A `trip_started` event is written.
2. Driver device streams GPS: `POST /trips/:id/position` (live) or
   `POST /trips/:id/positions` (offline batch, up to 500).
3. `ingestPositions`:
   - validates & de-dupes against `last_position_at`
   - inserts `trip_positions`, accumulates `distance_m`
   - broadcasts `bus:position` to the bus room + dispatch room
   - loads the geofence context **once**, then runs `evaluateAt` for **each** fresh
     position in order
4. `evaluateAt` checks school arrival/departure, each relevant stop
   (approaching / arrived), and route deviation. New events are recorded with a
   `dedupe_key`; `ON CONFLICT DO NOTHING` guarantees once-only.
5. Each new event → `notifyUser` per recipient: writes the `notifications` row,
   emits `notification:new` over Socket.IO, then attempts email / web-push / SMS
   according to the user's `notification_preferences` and quiet hours (emergencies
   bypass quiet hours and disabled-channel preferences for configured channels).
6. `POST /trips/:id/end` completes the trip. A background reaper also auto-closes
   trips with no position for 30 minutes.

## Auth

- `POST /auth/login` → `{ accessToken (15m JWT), refreshToken (opaque, 30d), user }`.
  Refresh tokens are stored only as SHA-256 hashes.
- `POST /auth/refresh` rotates: the presented token is revoked and a new pair
  issued. Re-use of a revoked token → 401.
- 8 failed logins → 15-minute lockout. Timing is equalised for unknown emails.
- Every request: `authenticate` (parse bearer, non-fatal) → route-level
  `requireAuth` / `requireRole(...)` → `resolveSchoolId(req)` pins every query to
  the caller's school (super-admin may pass `?schoolId`).

## Realtime rooms

`user:<id>`, `school:<id>`, `dispatch:<schoolId>` (admins/dispatchers),
`student:<id>` (a parent joins the rooms of their children), `bus:<id>`
(clients `emit('watch:bus', id)`).

Bus subscriptions are validated against the current active account, school and
guardian/driver assignment before joining the room. Parent history reflects
current bus assignment; it is not boarding attendance.

## Delegated handover

Driver request → server creates a code → linked parent authorises a named adult
and shares the code privately → driver checks the adult present and submits
the code → a locked transaction records a single verified handover.

The code is not returned to drivers or administrators and is not included in
notification messages. Codes are limited to active afternoon trips, expire
after 30 minutes by default, can be revoked, and lock after five wrong attempts.
Successful verification cannot be replayed. See Figures 3.6–3.8.

## Testing

`apps/api/src/test` — Supertest against the real Express app + a dedicated
`bustrack_pro_test` database (migrated by a `tsx` pretest step, truncated per file).
Covers auth/lockout/refresh-rotation, RBAC, tenant scoping, Zod validation, the
full trip lifecycle and every geofence event type (including the leave-then-return
school-arrival case). `modules/geo/geo.test.ts` unit-tests the distance maths.

An optional test-only PGlite adapter runs the same 40 tests without an external
database server. Production retains the standard PostgreSQL driver. The
handover suite covers privacy, authorisation, expiry, revocation, lockout,
concurrency, tenant boundaries and bus-room access; see
[validation evidence](docs/VALIDATION.md).
