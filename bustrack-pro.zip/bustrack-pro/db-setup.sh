#!/usr/bin/env bash
# Create + migrate + seed the BusTrack Pro databases for local (non-Docker) dev.
#
#   ./db-setup.sh 'YOUR_POSTGRES_PASSWORD'
#
# Creates bustrack_pro and bustrack_pro_test on PostgreSQL (localhost:5432),
# writes .env if missing, runs migrations and seeds demo data.
set -euo pipefail

PW="${1:-}"
[ -z "$PW" ] && { echo "usage: ./db-setup.sh '<postgres-password>'" >&2; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
PSQL="${PSQL:-psql}"
command -v "$PSQL" >/dev/null || PSQL="/c/Program Files/PostgreSQL/16/bin/psql.exe"
command -v "$PSQL" >/dev/null 2>&1 || [ -x "$PSQL" ] || PSQL="/c/Program Files/PostgreSQL/11/bin/psql.exe"
PGUSER="${PGUSER:-postgres}"
PGHOST="${PGHOST:-127.0.0.1}"
PGPORT="${PGPORT:-5432}"
export PGPASSWORD="$PW"

echo "› checking connection ($PGUSER@$PGHOST:$PGPORT)"
"$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d postgres -tAc 'select 1' >/dev/null

for db in bustrack_pro bustrack_pro_test; do
  "$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d postgres -tAc \
    "SELECT 1 FROM pg_database WHERE datname='$db'" | grep -q 1 \
    || { echo "› creating $db"; "$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d postgres -c "CREATE DATABASE $db"; }
done

if [ ! -f "$HERE/.env" ]; then
  echo "› writing .env from .env.example"
  sed -E "s#^(DATABASE_URL=).*#\1postgres://$PGUSER:$PW@$PGHOST:$PGPORT/bustrack_pro#;
          s#^(TEST_DATABASE_URL=).*#\1postgres://$PGUSER:$PW@$PGHOST:$PGPORT/bustrack_pro_test#;
          s#^(POSTGRES_PASSWORD=).*#\1$PW#" "$HERE/.env.example" > "$HERE/.env"
fi

echo "› installing dependencies"
( cd "$HERE" && npm install --silent )

echo "› migrating + seeding"
( cd "$HERE" && npm run db:migrate -w apps/api && npm run db:seed -w apps/api )

echo
echo "✅ ready.  Run:  npm run dev"
